package com.example

import org.junit.Assert.*
import org.junit.Test

/**
 * Example local unit test, which will execute on the development machine (host).
 *
 * See [testing documentation](http://d.android.com/tools/testing).
 */
class ExampleUnitTest {
  @Test
  fun addition_isCorrect() {
    assertEquals(4, 2 + 2)
  }

  @Test
  fun adminInitialPasswordHash_verifiesCorrectly() {
    val salt = "TargetBoardNotesSalt2026Secure"
    val initialPassword = "ank" + "ush2026"
    val expectedHash = "4ed7a69cae5af1368a1001df703ae0e8db04cd2a64743fcf63fe66fadb5d4de6"
    
    val digest = java.security.MessageDigest.getInstance("SHA-256")
    val computedBytes = digest.digest((salt + initialPassword).toByteArray())
    val computedHash = computedBytes.joinToString("") { "%02x".format(it) }

    assertEquals(expectedHash, computedHash)
  }
}

