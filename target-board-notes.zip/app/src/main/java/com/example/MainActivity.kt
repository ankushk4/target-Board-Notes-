package com.example

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.BackHandler
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.compose.animation.Crossfade
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.material3.Surface
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.lifecycle.viewmodel.compose.viewModel
import com.example.ui.components.AppUpdateDialog
import com.example.ui.navigation.Screen
import com.example.ui.screens.*
import com.example.ui.theme.TargetBoardTheme
import com.example.ui.viewmodel.AdminViewModel
import com.example.ui.viewmodel.MainViewModel

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        setContent {
            TargetBoardTheme {
                Surface(modifier = Modifier.fillMaxSize()) {
                    TargetBoardApp()
                }
            }
        }
    }
}

@Composable
fun TargetBoardApp(
    mainViewModel: MainViewModel = viewModel(),
    adminViewModel: AdminViewModel = viewModel()
) {
    var screenStack by remember { mutableStateOf(listOf<Screen>(Screen.Splash)) }
    val currentScreen = screenStack.lastOrNull() ?: Screen.Splash

    val showUpdateDialog by mainViewModel.showUpdateDialog.collectAsState()
    val updateInfo by mainViewModel.updateInfo.collectAsState()
    val activeResult by mainViewModel.activeMockTestResult.collectAsState()

    fun navigateTo(screen: Screen) {
        if (screen == Screen.Home) {
            screenStack = listOf(Screen.Home)
        } else {
            screenStack = screenStack + screen
        }
    }

    fun navigateBack() {
        if (screenStack.size > 1) {
            screenStack = screenStack.dropLast(1)
        }
    }

    // Handle Hardware & Gesture Back
    BackHandler(enabled = screenStack.size > 1 || activeResult != null) {
        if (activeResult != null) {
            mainViewModel.clearActiveMockTestResult()
        } else {
            navigateBack()
        }
    }

    Box(modifier = Modifier.fillMaxSize()) {
        if (activeResult != null) {
            MockTestResultScreen(
                result = activeResult!!,
                onClose = {
                    mainViewModel.clearActiveMockTestResult()
                    screenStack = listOf(Screen.Home)
                }
            )
        } else {
            Crossfade(targetState = currentScreen, label = "ScreenTransition") { screen ->
                when (screen) {
                    is Screen.Splash -> {
                        SplashScreen(
                            viewModel = mainViewModel,
                            onNavigate = { screenStack = listOf(it) }
                        )
                    }
                    is Screen.GoogleSignIn -> {
                        GoogleSignInScreen(
                            viewModel = mainViewModel,
                            onSignInSuccess = { navigateTo(Screen.Home) },
                            onExploreAsGuest = { navigateTo(Screen.CourseSelection) }
                        )
                    }
                    is Screen.CourseSelection -> {
                        CourseSelectionScreen(
                            viewModel = mainViewModel,
                            onNavigate = { navigateTo(it) }
                        )
                    }
                    is Screen.Home -> {
                        HomeScreen(
                            viewModel = mainViewModel,
                            onNavigate = { navigateTo(it) }
                        )
                    }
                    is Screen.Courses -> {
                        CoursesScreen(
                            viewModel = mainViewModel,
                            onNavigate = { navigateTo(it) }
                        )
                    }
                    is Screen.SubjectDetail -> {
                        SubjectDetailScreen(
                            subjectId = screen.subjectId,
                            viewModel = mainViewModel,
                            onNavigate = { navigateTo(it) },
                            onBack = { navigateBack() }
                        )
                    }
                    is Screen.ChapterDetail -> {
                        ChapterDetailScreen(
                            chapterId = screen.chapterId,
                            viewModel = mainViewModel,
                            onNavigate = { navigateTo(it) },
                            onBack = { navigateBack() }
                        )
                    }
                    is Screen.ObjectiveQuiz -> {
                        ObjectiveQuizScreen(
                            chapterId = screen.chapterId,
                            subjectId = screen.subjectId,
                            viewModel = mainViewModel,
                            onNavigate = { navigateTo(it) },
                            onBack = { navigateBack() }
                        )
                    }
                    is Screen.MockTestList -> {
                        MockTestListScreen(
                            viewModel = mainViewModel,
                            onNavigate = { navigateTo(it) }
                        )
                    }
                    is Screen.MockTestRunning -> {
                        MockTestRunningScreen(
                            testId = screen.testId,
                            viewModel = mainViewModel,
                            onNavigate = { navigateTo(it) }
                        )
                    }
                    is Screen.Notes -> {
                        NotesScreen(
                            viewModel = mainViewModel,
                            onNavigate = { navigateTo(it) }
                        )
                    }
                    is Screen.Bookmarks -> {
                        BookmarksScreen(
                            viewModel = mainViewModel,
                            onNavigate = { navigateTo(it) }
                        )
                    }
                    is Screen.Profile -> {
                        ProfileScreen(
                            viewModel = mainViewModel,
                            onNavigate = { navigateTo(it) }
                        )
                    }
                    is Screen.AdminLogin -> {
                        AdminLoginScreen(
                            adminViewModel = adminViewModel,
                            onNavigate = { navigateTo(it) },
                            onBack = { navigateBack() }
                        )
                    }
                    is Screen.AdminDashboard -> {
                        AdminDashboardScreen(
                            adminViewModel = adminViewModel,
                            mainViewModel = mainViewModel,
                            onNavigate = { navigateTo(it) }
                        )
                    }
                    is Screen.AdminChapterManagement -> {
                        AdminChapterManagementScreen(
                            subjectId = screen.subjectId,
                            courseId = screen.courseId,
                            adminViewModel = adminViewModel,
                            mainViewModel = mainViewModel,
                            onNavigate = { navigateTo(it) },
                            onBack = { navigateBack() }
                        )
                    }
                }
            }
        }

        // Remote Update Dialog
        if (showUpdateDialog && updateInfo != null) {
            AppUpdateDialog(
                updateInfo = updateInfo!!,
                onDismiss = { mainViewModel.dismissUpdateDialog() }
            )
        }
    }
}
