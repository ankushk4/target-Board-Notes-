package com.example.ui.screens

import android.content.Intent
import androidx.compose.foundation.*
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material.icons.outlined.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.R
import com.example.data.model.Bookmark
import com.example.ui.components.*
import com.example.ui.navigation.Screen
import com.example.ui.theme.*
import com.example.ui.viewmodel.MainViewModel

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun BookmarksScreen(
    viewModel: MainViewModel,
    onNavigate: (Screen) -> Unit
) {
    val selectedCourseId by viewModel.selectedCourseId.collectAsState()
    val currentCourse = viewModel.repository.getCourseById(selectedCourseId) ?: viewModel.repository.getAllCourses().first()
    val bookmarks by viewModel.currentBookmarks.collectAsState()

    Scaffold(
        topBar = {
            TargetBoardTopBar(
                title = "सहेजे गए नोट्स (${currentCourse.title})",
                subtitle = "ऑफलाइन त्वरित अध्ययन के लिए",
                canNavigateBack = true,
                onNavigateBack = { onNavigate(Screen.Home) }
            )
        },
        bottomBar = {
            TargetBoardBottomBar(
                currentRoute = Screen.Bookmarks.route,
                onNavigate = onNavigate
            )
        }
    ) { innerPadding ->
        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(innerPadding)
                .background(MaterialTheme.colorScheme.background)
                .padding(16.dp)
        ) {
            if (bookmarks.isEmpty()) {
                Box(
                    modifier = Modifier.fillMaxSize(),
                    contentAlignment = Alignment.Center
                ) {
                    Column(horizontalAlignment = Alignment.CenterHorizontally) {
                        Icon(
                            imageVector = Icons.Outlined.BookmarkBorder,
                            contentDescription = null,
                            tint = RoyalBluePrimary,
                            modifier = Modifier.size(64.dp)
                        )
                        Spacer(modifier = Modifier.height(12.dp))
                        Text(
                            text = "इस कोर्स में कोई बुकमार्क नहीं है",
                            style = MaterialTheme.typography.titleMedium.copy(fontWeight = FontWeight.Bold)
                        )
                        Text(
                            text = "${currentCourse.title} के किसी भी अध्याय पर बुकमार्क आइकन दबाकर यहाँ सहेजें।",
                            style = MaterialTheme.typography.bodySmall.copy(color = TextSecondary)
                        )
                    }
                }
            } else {
                LazyColumn(verticalArrangement = Arrangement.spacedBy(10.dp)) {
                    item {
                        Text(
                            text = "${currentCourse.title} के कुल ${bookmarks.size} अध्याय सुरक्षित हैं",
                            style = MaterialTheme.typography.titleSmall.copy(
                                fontWeight = FontWeight.Bold,
                                color = TextSecondary
                            )
                        )
                    }

                    items(bookmarks) { bookmark ->
                        Card(
                            modifier = Modifier
                                .fillMaxWidth()
                                .clickable { onNavigate(Screen.ChapterDetail(bookmark.chapterId)) }
                                .testTag("bookmark_card_${bookmark.chapterId}"),
                            shape = RoundedCornerShape(12.dp),
                            colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
                            elevation = CardDefaults.cardElevation(defaultElevation = 2.dp)
                        ) {
                            Row(
                                modifier = Modifier
                                    .padding(14.dp)
                                    .fillMaxWidth(),
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                Box(
                                    modifier = Modifier
                                        .size(40.dp)
                                        .clip(CircleShape)
                                        .background(AmberContainer),
                                    contentAlignment = Alignment.Center
                                ) {
                                    Icon(
                                        imageVector = Icons.Default.Bookmark,
                                        contentDescription = null,
                                        tint = BiharBoardGold
                                    )
                                }

                                Spacer(modifier = Modifier.width(12.dp))

                                Column(modifier = Modifier.weight(1f)) {
                                    Text(
                                        text = bookmark.chapterTitle,
                                        style = MaterialTheme.typography.titleMedium.copy(fontWeight = FontWeight.Bold)
                                    )
                                    Text(
                                        text = bookmark.subjectName,
                                        style = MaterialTheme.typography.bodySmall.copy(color = TextSecondary)
                                    )
                                }

                                IconButton(
                                    onClick = {
                                        val dummyCh = com.example.data.model.Chapter(
                                            id = bookmark.chapterId,
                                            subjectId = "",
                                            courseId = bookmark.courseId,
                                            chapterNumber = 1,
                                            title = bookmark.chapterTitle,
                                            hindiTitle = bookmark.chapterTitle
                                        )
                                        viewModel.toggleBookmark(dummyCh, true)
                                    }
                                ) {
                                    Icon(
                                        imageVector = Icons.Default.Delete,
                                        contentDescription = "हटाएं",
                                        tint = TextMuted
                                    )
                                }
                            }
                        }
                    }
                }
            }
        }
    }
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun ProfileScreen(
    viewModel: MainViewModel,
    onNavigate: (Screen) -> Unit
) {
    val context = LocalContext.current
    val studentProfile by viewModel.studentProfile.collectAsState()
    val selectedCourseId by viewModel.selectedCourseId.collectAsState()
    val currentCourse = viewModel.repository.getCourseById(selectedCourseId) ?: viewModel.repository.getAllCourses().first()
    val bookmarks by viewModel.currentBookmarks.collectAsState()
    val currentUser by viewModel.currentUser.collectAsState()

    val appLanguage by viewModel.appLanguage.collectAsState()
    var showAboutDialog by remember { mutableStateOf(false) }
    var showContactDialog by remember { mutableStateOf(false) }
    var showPrivacyDialog by remember { mutableStateOf(false) }
    var showLanguageDialog by remember { mutableStateOf(false) }

    Scaffold(
        topBar = {
            TargetBoardTopBar(
                title = "विद्यार्थी प्रोफाइल एवं सेटिंग्स",
                subtitle = "लक्ष्य: बिहार बोर्ड परीक्षा 2026–2027",
                actions = {
                    IconButton(
                        onClick = { onNavigate(Screen.AdminLogin) },
                        modifier = Modifier.testTag("profile_admin_login_btn")
                    ) {
                        Icon(
                            imageVector = Icons.Default.AdminPanelSettings,
                            contentDescription = "एडमिन",
                            tint = BiharBoardGold
                        )
                    }
                }
            )
        },
        bottomBar = {
            TargetBoardBottomBar(
                currentRoute = Screen.Profile.route,
                onNavigate = onNavigate
            )
        }
    ) { innerPadding ->
        LazyColumn(
            modifier = Modifier
                .fillMaxSize()
                .padding(innerPadding)
                .background(MaterialTheme.colorScheme.background)
                .padding(16.dp),
            verticalArrangement = Arrangement.spacedBy(14.dp)
        ) {
            // Student Card
            item {
                Card(
                    modifier = Modifier.fillMaxWidth(),
                    shape = RoundedCornerShape(16.dp),
                    colors = CardDefaults.cardColors(containerColor = RoyalBluePrimary),
                    elevation = CardDefaults.cardElevation(defaultElevation = 3.dp)
                ) {
                    Column(modifier = Modifier.padding(18.dp)) {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Image(
                                painter = painterResource(id = R.drawable.ic_target_board_logo),
                                contentDescription = "Logo",
                                modifier = Modifier
                                    .size(56.dp)
                                    .clip(CircleShape)
                                    .background(Color.White)
                                    .padding(2.dp),
                                contentScale = ContentScale.Fit
                            )
                            Spacer(modifier = Modifier.width(14.dp))
                            Column {
                                Text(
                                    text = studentProfile.name,
                                    style = MaterialTheme.typography.titleLarge.copy(
                                        color = Color.White,
                                        fontWeight = FontWeight.Bold
                                    )
                                )
                                Text(
                                    text = "वर्तमान पाठ्यक्रम: ${currentCourse.title}",
                                    style = MaterialTheme.typography.bodySmall.copy(
                                        color = BiharBoardGold,
                                        fontWeight = FontWeight.Bold
                                    )
                                )
                                Text(
                                    text = "सत्र: 2026–2027 • 100% Free Education",
                                    style = MaterialTheme.typography.bodySmall.copy(
                                        color = Color.White.copy(alpha = 0.85f)
                                    )
                                )
                            }
                        }

                        Spacer(modifier = Modifier.height(16.dp))

                        // Stats Grid
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceAround
                        ) {
                            ProfileStatItem("अध्ययन स्ट्रीक", "${studentProfile.streakDays} दिन 🔥")
                            ProfileStatItem("हल किए प्रश्न", "${studentProfile.solvedQuestionsCount} Qs")
                            ProfileStatItem("मॉक टेस्ट", "${studentProfile.testsCompletedCount} टेस्ट")
                        }
                    }
                }
            }

            // Firebase Cloud Account & Synchronization
            item {
                Card(
                    modifier = Modifier.fillMaxWidth(),
                    shape = RoundedCornerShape(14.dp),
                    colors = CardDefaults.cardColors(
                        containerColor = if (currentUser != null) EmeraldContainer.copy(alpha = 0.5f) else AmberContainer.copy(alpha = 0.4f)
                    ),
                    border = BorderStroke(1.dp, if (currentUser != null) EmeraldAccent.copy(alpha = 0.5f) else AmberAccent.copy(alpha = 0.5f))
                ) {
                    Column(modifier = Modifier.padding(16.dp)) {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Icon(
                                imageVector = if (currentUser != null) Icons.Default.CloudDone else Icons.Default.CloudOff,
                                contentDescription = null,
                                tint = if (currentUser != null) EmeraldAccent else AmberAccent,
                                modifier = Modifier.size(24.dp)
                            )
                            Spacer(modifier = Modifier.width(10.dp))
                            Column(modifier = Modifier.weight(1f)) {
                                Text(
                                    text = if (currentUser != null) "Firebase क्लाउड खाता कनेक्टेड" else "Google साइन-इन (क्लाउड सिंक हेतु)",
                                    style = MaterialTheme.typography.titleSmall.copy(
                                        fontWeight = FontWeight.Bold,
                                        color = if (currentUser != null) EmeraldAccent else AmberAccent
                                    )
                                )
                                Text(
                                    text = currentUser?.email ?: "साइन-इन करके सभी डिवाइस पर अपने नोट्स सिंक करें",
                                    style = MaterialTheme.typography.bodySmall.copy(color = TextSecondary)
                                )
                            }
                        }

                        Spacer(modifier = Modifier.height(10.dp))

                        if (currentUser != null) {
                            OutlinedButton(
                                onClick = { viewModel.authRepository.signOut() },
                                modifier = Modifier.fillMaxWidth(),
                                shape = RoundedCornerShape(8.dp),
                                border = BorderStroke(1.dp, Color(0xFFE11D48))
                            ) {
                                Icon(imageVector = Icons.Default.Logout, contentDescription = null, tint = Color(0xFFE11D48), modifier = Modifier.size(18.dp))
                                Spacer(modifier = Modifier.width(8.dp))
                                Text("साइन आउट करें (Sign Out)", color = Color(0xFFE11D48), fontWeight = FontWeight.Bold)
                            }
                        } else {
                            Button(
                                onClick = { onNavigate(Screen.GoogleSignIn) },
                                modifier = Modifier.fillMaxWidth(),
                                shape = RoundedCornerShape(8.dp),
                                colors = ButtonDefaults.buttonColors(containerColor = RoyalBluePrimary)
                            ) {
                                Icon(imageVector = Icons.Default.AccountCircle, contentDescription = null, modifier = Modifier.size(18.dp))
                                Spacer(modifier = Modifier.width(8.dp))
                                Text("Google से साइन इन करें", fontWeight = FontWeight.Bold)
                            }
                        }
                    }
                }
            }

            // Course Management
            item {
                Text(
                    text = "पाठ्यक्रम सेटिंग्स (Course Settings)",
                    style = MaterialTheme.typography.titleMedium.copy(
                        fontWeight = FontWeight.Bold,
                        color = MaterialTheme.colorScheme.onBackground
                    )
                )
            }

            item {
                Card(
                    modifier = Modifier.fillMaxWidth(),
                    shape = RoundedCornerShape(14.dp),
                    colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface)
                ) {
                    Column {
                        ProfileMenuRow(
                            icon = Icons.Default.SwapHoriz,
                            title = "पाठ्यक्रम बदलें (Change Course)",
                            subtitle = "वर्तमान: ${currentCourse.hindiTitle} • 10th / 12th Arts / 12th Science",
                            iconColor = EmeraldAccent,
                            onClick = { onNavigate(Screen.CourseSelection) }
                        )

                        Divider(color = OutlineLight.copy(alpha = 0.5f))

                        ProfileMenuRow(
                            icon = Icons.Default.Translate,
                            title = if (appLanguage == "en") "App Language (भाषा)" else "एप्लिकेशन भाषा (App Language)",
                            subtitle = if (appLanguage == "en") "Current: English (टैप करके हिंदी चुनें)" else "वर्तमान: हिंदी (टैप करके English चुनें)",
                            iconColor = RoyalBluePrimary,
                            onClick = { showLanguageDialog = true }
                        )
                    }
                }
            }

            // Quick Actions & Utilities
            item {
                Text(
                    text = "अध्ययन एवं ऐप सुविधाएं",
                    style = MaterialTheme.typography.titleMedium.copy(
                        fontWeight = FontWeight.Bold,
                        color = MaterialTheme.colorScheme.onBackground
                    )
                )
            }

            item {
                Card(
                    modifier = Modifier.fillMaxWidth(),
                    shape = RoundedCornerShape(14.dp),
                    colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface)
                ) {
                    Column {
                        ProfileMenuRow(
                            icon = Icons.Default.Bookmark,
                            title = "सहेजे गए बुकमार्क (${bookmarks.size})",
                            subtitle = "ऑफलाइन पढ़ने के लिए सहेजे गए अध्याय",
                            iconColor = BiharBoardGold,
                            onClick = { onNavigate(Screen.Bookmarks) }
                        )

                        Divider(color = OutlineLight.copy(alpha = 0.5f))

                        ProfileMenuRow(
                            icon = Icons.Default.SystemUpdate,
                            title = "ऐप अपडेट जांचें (Check Updates)",
                            subtitle = "नवीनतम संस्करण 2.0 और नोट्स की जांच करें",
                            iconColor = RoyalBluePrimary,
                            onClick = { viewModel.checkForAppUpdates() }
                        )

                        Divider(color = OutlineLight.copy(alpha = 0.5f))

                        ProfileMenuRow(
                            icon = Icons.Default.Share,
                            title = "मित्रों के साथ शेयर करें (Share App)",
                            subtitle = "बिहार बोर्ड के अन्य विद्यार्थियों की सहायता करें",
                            iconColor = EmeraldAccent,
                            onClick = {
                                val shareIntent = Intent(Intent.ACTION_SEND).apply {
                                    type = "text/plain"
                                    putExtra(
                                        Intent.EXTRA_TEXT,
                                        "प्रिय मित्रों, बिहार बोर्ड परीक्षा 2026–2027 की तैयारी के लिए 'TARGET BOARD NOTES' ऐप डाउनलोड करें। यहाँ 10th & 12th के सम्पूर्ण हस्तलिखित नोट्स, VVI ऑब्जेक्टिव व मॉक टेस्ट 100% नि:शुल्क हैं!"
                                    )
                                }
                                context.startActivity(Intent.createChooser(shareIntent, "Share Target Board Notes"))
                            }
                        )

                        Divider(color = OutlineLight.copy(alpha = 0.5f))

                        ProfileMenuRow(
                            icon = Icons.Default.AdminPanelSettings,
                            title = "प्रशासक लॉगिन (Admin Portal)",
                            subtitle = "सुरक्षित एडमिन एक्सेस • सामग्री प्रबंधन",
                            iconColor = AmberAccent,
                            onClick = { onNavigate(Screen.AdminLogin) }
                        )
                    }
                }
            }

            // Support & Info Section
            item {
                Text(
                    text = "सहायता एवं कानूनी जानकारी",
                    style = MaterialTheme.typography.titleMedium.copy(
                        fontWeight = FontWeight.Bold,
                        color = MaterialTheme.colorScheme.onBackground
                    )
                )
            }

            item {
                Card(
                    modifier = Modifier.fillMaxWidth(),
                    shape = RoundedCornerShape(14.dp),
                    colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface)
                ) {
                    Column {
                        ProfileMenuRow(
                            icon = Icons.Default.Info,
                            title = "हमारे बारे में (About Us)",
                            subtitle = "TARGET BOARD NOTES मिशन एवं दृष्टि",
                            iconColor = RoyalBluePrimary,
                            onClick = { showAboutDialog = true }
                        )

                        Divider(color = OutlineLight.copy(alpha = 0.5f))

                        ProfileMenuRow(
                            icon = Icons.Default.SupportAgent,
                            title = "संपर्क सूत्र (Contact Us)",
                            subtitle = "TARGET BOARD सपोर्ट डेस्क",
                            iconColor = EmeraldAccent,
                            onClick = { showContactDialog = true }
                        )

                        Divider(color = OutlineLight.copy(alpha = 0.5f))

                        ProfileMenuRow(
                            icon = Icons.Default.Policy,
                            title = "गोपनीयता नीति (Privacy Policy)",
                            subtitle = "छात्रों के डेटा की संपूर्ण सुरक्षा व नीतियां",
                            iconColor = TextMuted,
                            onClick = { showPrivacyDialog = true }
                        )
                    }
                }
            }

            // Footer
            item {
                Column(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(vertical = 12.dp),
                    horizontalAlignment = Alignment.CenterHorizontally
                ) {
                    Text(
                        text = "TARGET BOARD NOTES v1.0",
                        style = MaterialTheme.typography.labelMedium.copy(
                            fontWeight = FontWeight.Bold,
                            color = TextMuted
                        )
                    )
                    Text(
                        text = "Study Smart • Score High • सत्र 2026–2027",
                        style = MaterialTheme.typography.bodySmall.copy(color = TextMuted, fontSize = 11.sp)
                    )
                }
            }
        }

        // About Us Dialog (No personal names)
        if (showAboutDialog) {
            AlertDialog(
                onDismissRequest = { showAboutDialog = false },
                icon = {
                    Image(
                        painter = painterResource(id = R.drawable.ic_target_board_logo),
                        contentDescription = null,
                        modifier = Modifier
                            .size(60.dp)
                            .clip(CircleShape)
                    )
                },
                title = { Text("About TARGET BOARD NOTES", fontWeight = FontWeight.Bold) },
                text = {
                    Column {
                        Text(
                            text = "TARGET BOARD NOTES शैक्षणिक सत्र 2026–2027 के लिए बिहार विद्यालय परीक्षा समिति (BSEB) के कक्षा 10वीं और 12वीं (आर्ट्स एवं साइंस) के विद्यार्थियों हेतु विकसित एक सम्पूर्ण डिजिटल शैक्षणिक मंच है।",
                            style = MaterialTheme.typography.bodyMedium
                        )
                        Spacer(modifier = Modifier.height(8.dp))
                        Text(
                            text = "• ध्येय: बिहार बोर्ड के प्रत्येक छात्र तक गुणवत्तापूर्ण एवं निःशुल्क शिक्षा पहुंचाना।\n• सभी नोट्स, हस्तलिखित पीडीएफ, प्रश्न बैंक एवं ऑनलाइन मॉक टेस्ट सदैव 100% नि:शुल्क रहेंगे।\n• आदर्श वाक्य: Study Smart • Score High",
                            style = MaterialTheme.typography.bodySmall.copy(color = RoyalBlueDark)
                        )
                    }
                },
                confirmButton = {
                    TextButton(onClick = { showAboutDialog = false }) {
                        Text("ठीक है")
                    }
                }
            )
        }

        // Contact Us Dialog
        if (showContactDialog) {
            AlertDialog(
                onDismissRequest = { showContactDialog = false },
                icon = { Icon(imageVector = Icons.Default.Email, contentDescription = null, tint = EmeraldAccent) },
                title = { Text("संपर्क सूत्र (Contact Us)", fontWeight = FontWeight.Bold) },
                text = {
                    Column {
                        Text("TARGET BOARD NOTES सपोर्ट डेस्क", fontWeight = FontWeight.Bold)
                        Spacer(modifier = Modifier.height(4.dp))
                        Text("ईमेल: support@targetboardnotes.in")
                        Text("टेलीग्राम चैनल: @TargetBoardNotesOfficial")
                        Text("वेबसाइट: https://targetboardnotes.biharboard.ac.in")
                        Text("स्थान: पटना, बिहार - 800001")
                        Spacer(modifier = Modifier.height(8.dp))
                        Text("किसी भी तकनीकी समस्या या अध्ययन सामग्री सुझाव के लिए 24 घंटे में सहायता उपलब्ध है।", color = TextSecondary, fontSize = 12.sp)
                    }
                },
                confirmButton = {
                    TextButton(onClick = { showContactDialog = false }) {
                        Text("बंद करें")
                    }
                }
            )
        }

        // Privacy Policy Dialog
        if (showPrivacyDialog) {
            AlertDialog(
                onDismissRequest = { showPrivacyDialog = false },
                icon = { Icon(imageVector = Icons.Default.Shield, contentDescription = null, tint = RoyalBluePrimary) },
                title = { Text("गोपनीयता नीति (Privacy Policy)", fontWeight = FontWeight.Bold) },
                text = {
                    Text(
                        text = "TARGET BOARD NOTES विद्यार्थियों के गोपनीयता अधिकारों का पूर्ण सम्मान करता है। ऐप किसी भी प्रकार का संवेदनशील व्यक्तिगत डेटा एकत्र या साझा नहीं करता। अध्ययन प्रगति, बुकमार्क तथा टेस्ट स्कोर डिवाइस पर सुरक्षित रहते हैं।",
                        style = MaterialTheme.typography.bodySmall
                    )
                },
                confirmButton = {
                    TextButton(onClick = { showPrivacyDialog = false }) {
                        Text("सहमत हैं")
                    }
                }
            )
        }

        // Language Selection Dialog (Hindi & English only)
        if (showLanguageDialog) {
            AlertDialog(
                onDismissRequest = { showLanguageDialog = false },
                icon = { Icon(imageVector = Icons.Default.Translate, contentDescription = null, tint = RoyalBluePrimary) },
                title = { Text("भाषा चुनें (Select Language)", fontWeight = FontWeight.Bold) },
                text = {
                    Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                        Text(
                            text = "TARGET BOARD NOTES ऐप में अपनी पसंदीदा अध्ययन भाषा चुनें:",
                            style = MaterialTheme.typography.bodySmall.copy(color = TextSecondary)
                        )
                        Spacer(modifier = Modifier.height(4.dp))

                        // Hindi Option
                        Surface(
                            shape = RoundedCornerShape(10.dp),
                            color = if (appLanguage == "hi") RoyalBlueContainer else MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.5f),
                            border = if (appLanguage == "hi") BorderStroke(1.5.dp, RoyalBluePrimary) else null,
                            modifier = Modifier
                                .fillMaxWidth()
                                .clickable {
                                    viewModel.setAppLanguage("hi")
                                    showLanguageDialog = false
                                }
                        ) {
                            Row(
                                modifier = Modifier.padding(12.dp),
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                RadioButton(
                                    selected = appLanguage == "hi",
                                    onClick = {
                                        viewModel.setAppLanguage("hi")
                                        showLanguageDialog = false
                                    }
                                )
                                Spacer(modifier = Modifier.width(8.dp))
                                Column {
                                    Text("हिंदी (Hindi)", fontWeight = FontWeight.Bold)
                                    Text("बिहार बोर्ड मुख्य अध्ययन माध्यम", fontSize = 11.sp, color = TextSecondary)
                                }
                            }
                        }

                        // English Option
                        Surface(
                            shape = RoundedCornerShape(10.dp),
                            color = if (appLanguage == "en") RoyalBlueContainer else MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.5f),
                            border = if (appLanguage == "en") BorderStroke(1.5.dp, RoyalBluePrimary) else null,
                            modifier = Modifier
                                .fillMaxWidth()
                                .clickable {
                                    viewModel.setAppLanguage("en")
                                    showLanguageDialog = false
                                }
                        ) {
                            Row(
                                modifier = Modifier.padding(12.dp),
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                RadioButton(
                                    selected = appLanguage == "en",
                                    onClick = {
                                        viewModel.setAppLanguage("en")
                                        showLanguageDialog = false
                                    }
                                )
                                Spacer(modifier = Modifier.width(8.dp))
                                Column {
                                    Text("English", fontWeight = FontWeight.Bold)
                                    Text("Bihar Board English Medium", fontSize = 11.sp, color = TextSecondary)
                                }
                            }
                        }
                    }
                },
                confirmButton = {
                    TextButton(onClick = { showLanguageDialog = false }) { Text("बंद करें") }
                }
            )
        }
    }
}

@Composable
private fun ProfileStatItem(label: String, value: String) {
    Column(horizontalAlignment = Alignment.CenterHorizontally) {
        Text(
            text = value,
            style = MaterialTheme.typography.titleMedium.copy(
                color = Color.White,
                fontWeight = FontWeight.Bold
            )
        )
        Text(
            text = label,
            style = MaterialTheme.typography.bodySmall.copy(
                color = Color.White.copy(alpha = 0.85f)
            )
        )
    }
}

@Composable
private fun ProfileMenuRow(
    icon: androidx.compose.ui.graphics.vector.ImageVector,
    title: String,
    subtitle: String,
    iconColor: Color,
    onClick: () -> Unit
) {
    Surface(
        onClick = onClick,
        color = Color.Transparent,
        modifier = Modifier.fillMaxWidth()
    ) {
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .padding(horizontal = 16.dp, vertical = 14.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            Box(
                modifier = Modifier
                    .size(42.dp)
                    .clip(RoundedCornerShape(10.dp))
                    .background(iconColor.copy(alpha = 0.12f)),
                contentAlignment = Alignment.Center
            ) {
                Icon(
                    imageVector = icon,
                    contentDescription = null,
                    tint = iconColor,
                    modifier = Modifier.size(22.dp)
                )
            }
            Spacer(modifier = Modifier.width(14.dp))
            Column(modifier = Modifier.weight(1f)) {
                Text(
                    text = title,
                    style = MaterialTheme.typography.titleSmall.copy(fontWeight = FontWeight.SemiBold)
                )
                Text(
                    text = subtitle,
                    style = MaterialTheme.typography.bodySmall.copy(
                        color = MaterialTheme.colorScheme.onSurfaceVariant
                    )
                )
            }
            Icon(
                imageVector = Icons.Default.ChevronRight,
                contentDescription = null,
                tint = MaterialTheme.colorScheme.onSurfaceVariant.copy(alpha = 0.6f)
            )
        }
    }
}

