package com.example.ui.theme

import androidx.compose.ui.graphics.Color

// Target Board Notes - Royal Blue & Educational Accent Palette
val RoyalBluePrimary = Color(0xFF1E3A8A)
val RoyalBlueDark = Color(0xFF0F172A)
val RoyalBlueLight = Color(0xFF2563EB)
val RoyalBlueContainer = Color(0xFFDBEAFE)
val OnRoyalBlueContainer = Color(0xFF1E3A8A)

val EmeraldAccent = Color(0xFF059669)
val EmeraldContainer = Color(0xFFD1FAE5)
val AmberAccent = Color(0xFFD97706)
val AmberContainer = Color(0xFFFEF3C7)

val BiharBoardGold = Color(0xFFF59E0B)

val BackgroundLight = Color(0xFFF8FAFC)
val SurfaceLight = Color(0xFFFFFFFF)
val SurfaceVariantLight = Color(0xFFF1F5F9)
val OutlineLight = Color(0xFFCBD5E1)
val TextPrimary = Color(0xFF0F172A)
val TextSecondary = Color(0xFF475569)
val TextMuted = Color(0xFF64748B)

// Dark Theme Variants
val DarkBackground = Color(0xFF0B1120)
val DarkSurface = Color(0xFF131D33)
val DarkSurfaceVariant = Color(0xFF1E293B)
val DarkPrimary = Color(0xFF60A5FA)
val DarkPrimaryContainer = Color(0xFF1E3A8A)
val DarkOutline = Color(0xFF334155)
val DarkTextPrimary = Color(0xFFF8FAFC)
val DarkTextSecondary = Color(0xFF94A3B8)
