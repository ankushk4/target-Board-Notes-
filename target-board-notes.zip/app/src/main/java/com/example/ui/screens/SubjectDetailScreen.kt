package com.example.ui.screens

import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.data.model.*
import com.example.ui.components.*
import com.example.ui.navigation.Screen
import com.example.ui.theme.*
import com.example.ui.viewmodel.MainViewModel

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun SubjectDetailScreen(
    subjectId: String,
    viewModel: MainViewModel,
    onNavigate: (Screen) -> Unit,
    onBack: () -> Unit = { onNavigate(Screen.Courses) }
) {
    var subject by remember { mutableStateOf<Subject?>(null) }
    LaunchedEffect(subjectId) {
        subject = viewModel.repository.getSubjectById(subjectId)
    }
    val chaptersFlow = remember(subjectId) { viewModel.repository.getChaptersBySubject(subjectId) }
    val allChapters by chaptersFlow.collectAsState(initial = emptyList())
    val chapters = remember(allChapters) { allChapters.filter { it.isPublished } }
    val bookmarks by viewModel.bookmarks.collectAsState()
    val bookmarkedIds = remember(bookmarks) { bookmarks.map { it.chapterId }.toSet() }

    var selectedTab by remember { mutableStateOf(0) }
    val tabs = listOf("अध्याय सूची (${chapters.size})", "वस्तुनिष्ठ प्रश्न (MCQ)", "PDF फाइल्स")

    Scaffold(
        topBar = {
            TargetBoardTopBar(
                title = subject?.title ?: "विषय विवरण",
                subtitle = "अध्यायवार संपूर्ण नोट्स व प्रश्नोत्तर",
                canNavigateBack = true,
                onNavigateBack = onBack,
                actions = {
                    IconButton(
                        onClick = { onNavigate(Screen.ObjectiveQuiz(subjectId = subjectId)) },
                        modifier = Modifier.testTag("subject_start_quiz_btn")
                    ) {
                        Icon(
                            imageVector = Icons.Default.Quiz,
                            contentDescription = "Quiz",
                            tint = BiharBoardGold
                        )
                    }
                }
            )
        },
        bottomBar = {
            TargetBoardBottomBar(
                currentRoute = Screen.Courses.route,
                onNavigate = onNavigate
            )
        }
    ) { innerPadding ->
        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(innerPadding)
                .background(MaterialTheme.colorScheme.background)
        ) {
            // Subject Header Card
            Card(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(16.dp),
                shape = RoundedCornerShape(14.dp),
                colors = CardDefaults.cardColors(containerColor = RoyalBluePrimary)
            ) {
                Column(modifier = Modifier.padding(16.dp)) {
                    Text(
                        text = subject?.title ?: "",
                        style = MaterialTheme.typography.titleLarge.copy(
                            fontWeight = FontWeight.Bold,
                            color = Color.White
                        )
                    )
                    Text(
                        text = subject?.hindiTitle ?: "",
                        style = MaterialTheme.typography.bodyMedium.copy(
                            color = Color.White.copy(alpha = 0.9f)
                        )
                    )
                    Spacer(modifier = Modifier.height(10.dp))
                    Row(
                        horizontalArrangement = Arrangement.spacedBy(8.dp),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Surface(
                            shape = RoundedCornerShape(6.dp),
                            color = BiharBoardGold
                        ) {
                            Text(
                                text = "BSEB 2026-27",
                                modifier = Modifier.padding(horizontal = 6.dp, vertical = 2.dp),
                                style = MaterialTheme.typography.labelSmall.copy(
                                    color = RoyalBlueDark,
                                    fontWeight = FontWeight.Bold
                                )
                            )
                        }
                        Surface(
                            shape = RoundedCornerShape(6.dp),
                            color = EmeraldAccent
                        ) {
                            Text(
                                text = "100% नि:शुल्क",
                                modifier = Modifier.padding(horizontal = 6.dp, vertical = 2.dp),
                                style = MaterialTheme.typography.labelSmall.copy(
                                    color = Color.White,
                                    fontWeight = FontWeight.Bold
                                )
                            )
                        }
                    }
                }
            }

            // Tabs Row
            TabRow(
                selectedTabIndex = selectedTab,
                containerColor = MaterialTheme.colorScheme.surface,
                contentColor = RoyalBluePrimary
            ) {
                tabs.forEachIndexed { index, title ->
                    Tab(
                        selected = selectedTab == index,
                        onClick = { selectedTab = index },
                        text = {
                            Text(
                                text = title,
                                fontWeight = if (selectedTab == index) FontWeight.Bold else FontWeight.Normal,
                                fontSize = 13.sp
                            )
                        }
                    )
                }
            }

            LazyColumn(
                modifier = Modifier
                    .fillMaxSize()
                    .padding(16.dp),
                verticalArrangement = Arrangement.spacedBy(10.dp)
            ) {
                if (chapters.isEmpty()) {
                    item {
                        Card(
                            modifier = Modifier.fillMaxWidth(),
                            shape = RoundedCornerShape(12.dp),
                            colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface)
                        ) {
                            Column(
                                modifier = Modifier
                                    .padding(24.dp)
                                    .fillMaxWidth(),
                                horizontalAlignment = Alignment.CenterHorizontally
                            ) {
                                Icon(
                                    imageVector = Icons.Default.Info,
                                    contentDescription = null,
                                    tint = RoyalBluePrimary,
                                    modifier = Modifier.size(36.dp)
                                )
                                Spacer(modifier = Modifier.height(8.dp))
                                Text(
                                    text = "इस विषय के अध्याय शीघ्र ही जोड़े जा रहे हैं।",
                                    style = MaterialTheme.typography.bodyMedium.copy(fontWeight = FontWeight.SemiBold)
                                )
                            }
                        }
                    }
                } else {
                    items(chapters) { chapter ->
                        ChapterListItem(
                            chapter = chapter,
                            isBookmarked = bookmarkedIds.contains(chapter.id),
                            onChapterClick = { onNavigate(Screen.ChapterDetail(chapter.id)) },
                            onBookmarkClick = { viewModel.toggleBookmark(chapter, bookmarkedIds.contains(chapter.id)) },
                            onDownloadClick = { viewModel.toggleDownload(chapter.id, chapter.isDownloaded) }
                        )
                    }
                }

                // CTA to Test Knowledge
                item {
                    Spacer(modifier = Modifier.height(8.dp))
                    Button(
                        onClick = { onNavigate(Screen.ObjectiveQuiz(subjectId = subjectId)) },
                        modifier = Modifier
                            .fillMaxWidth()
                            .height(50.dp)
                            .testTag("btn_start_subject_quiz"),
                        shape = RoundedCornerShape(12.dp),
                        colors = ButtonDefaults.buttonColors(containerColor = EmeraldAccent)
                    ) {
                        Icon(imageVector = Icons.Default.Quiz, contentDescription = null)
                        Spacer(modifier = Modifier.width(8.dp))
                        Text(
                            text = "इस विषय का ऑनलाइन टेस्ट दें (Take MCQ Test)",
                            fontWeight = FontWeight.Bold,
                            fontSize = 15.sp
                        )
                    }
                }
            }
        }
    }
}
