package com.example.ui.screens

import androidx.compose.animation.*
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.itemsIndexed
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material.icons.outlined.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.data.model.*
import com.example.ui.components.*
import com.example.ui.navigation.Screen
import com.example.ui.theme.*
import com.example.ui.viewmodel.MainViewModel
import kotlinx.coroutines.launch

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun ChapterDetailScreen(
    chapterId: String,
    viewModel: MainViewModel,
    onNavigate: (Screen) -> Unit,
    onBack: () -> Unit = { onNavigate(Screen.Home) }
) {
    val coroutineScope = rememberCoroutineScope()
    var chapter by remember { mutableStateOf<Chapter?>(null) }
    val bookmarks by viewModel.bookmarks.collectAsState()
    val isBookmarked = remember(bookmarks, chapterId) {
        bookmarks.any { it.chapterId == chapterId }
    }

    val objQuestionsFlow = remember(chapterId) { viewModel.repository.getObjectiveQuestions(chapterId) }
    val objectiveQuestions by objQuestionsFlow.collectAsState(initial = emptyList())

    val subQuestionsFlow = remember(chapterId) { viewModel.repository.getSubjectiveQuestions(chapterId) }
    val subjectiveQuestions by subQuestionsFlow.collectAsState(initial = emptyList())

    LaunchedEffect(chapterId) {
        chapter = viewModel.repository.getChapterById(chapterId)
    }

    var selectedSectionTab by remember { mutableStateOf(0) }
    val sectionTabs = listOf(
        "अध्याय व्याख्या",
        "लेखक परिचय",
        "मुख्य बिंदु",
        "लघु उत्तरीय",
        "दीर्घ उत्तरीय",
        "ऑब्जेक्टिव (MCQ)",
        "PDF नोट्स"
    )

    var fontSizeDelta by remember { mutableStateOf(0) } // text zoom control
    var showDigitalReaderDialog by remember { mutableStateOf(false) }

    Scaffold(
        topBar = {
            TargetBoardTopBar(
                title = chapter?.title ?: "अध्याय विवरण",
                subtitle = "अध्याय ${chapter?.chapterNumber ?: 1} • सम्पूर्ण अध्ययन सामग्री",
                canNavigateBack = true,
                onNavigateBack = onBack,
                actions = {
                    // Font zoom control
                    IconButton(onClick = { if (fontSizeDelta > -2) fontSizeDelta -= 1 }) {
                        Text("A-", color = Color.White, fontWeight = FontWeight.Bold, fontSize = 13.sp)
                    }
                    IconButton(onClick = { if (fontSizeDelta < 4) fontSizeDelta += 1 }) {
                        Text("A+", color = Color.White, fontWeight = FontWeight.Bold, fontSize = 16.sp)
                    }

                    // Bookmark
                    IconButton(
                        onClick = {
                            chapter?.let { viewModel.toggleBookmark(it, isBookmarked) }
                        },
                        modifier = Modifier.testTag("chapter_bookmark_btn")
                    ) {
                        Icon(
                            imageVector = if (isBookmarked) Icons.Filled.Bookmark else Icons.Outlined.BookmarkBorder,
                            contentDescription = "Bookmark",
                            tint = if (isBookmarked) BiharBoardGold else Color.White
                        )
                    }

                    // Download
                    IconButton(
                        onClick = {
                            chapter?.let {
                                viewModel.toggleDownload(it.id, it.isDownloaded)
                                coroutineScope.launch {
                                    chapter = viewModel.repository.getChapterById(chapterId)
                                }
                            }
                        },
                        modifier = Modifier.testTag("chapter_download_btn")
                    ) {
                        Icon(
                            imageVector = if (chapter?.isDownloaded == true) Icons.Filled.FileDownloadDone else Icons.Outlined.Download,
                            contentDescription = "Download",
                            tint = if (chapter?.isDownloaded == true) EmeraldAccent else Color.White
                        )
                    }
                }
            )
        }
    ) { innerPadding ->
        if (chapter == null) {
            Box(
                modifier = Modifier
                    .fillMaxSize()
                    .padding(innerPadding),
                contentAlignment = Alignment.Center
            ) {
                CircularProgressIndicator(color = RoyalBluePrimary)
            }
        } else {
            val ch = chapter!!
            Column(
                modifier = Modifier
                    .fillMaxSize()
                    .padding(innerPadding)
                    .background(MaterialTheme.colorScheme.background)
            ) {
                // Section Tabs
                ScrollableTabRow(
                    selectedTabIndex = selectedSectionTab,
                    containerColor = MaterialTheme.colorScheme.surface,
                    contentColor = RoyalBluePrimary,
                    edgePadding = 12.dp
                ) {
                    sectionTabs.forEachIndexed { index, title ->
                        Tab(
                            selected = selectedSectionTab == index,
                            onClick = { selectedSectionTab = index },
                            text = {
                                Text(
                                    text = title,
                                    fontWeight = if (selectedSectionTab == index) FontWeight.Bold else FontWeight.Normal,
                                    fontSize = 13.sp
                                )
                            },
                            modifier = Modifier.testTag("chapter_tab_$index")
                        )
                    }
                }

                // Section Content
                LazyColumn(
                    modifier = Modifier
                        .fillMaxSize()
                        .padding(16.dp),
                    verticalArrangement = Arrangement.spacedBy(14.dp)
                ) {
                    when (selectedSectionTab) {
                        // Tab 0: Chapter Explanation
                        0 -> {
                            item {
                                Card(
                                    modifier = Modifier.fillMaxWidth(),
                                    shape = RoundedCornerShape(14.dp),
                                    colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
                                    elevation = CardDefaults.cardElevation(defaultElevation = 2.dp)
                                ) {
                                    Column(modifier = Modifier.padding(16.dp)) {
                                        Surface(
                                            shape = RoundedCornerShape(6.dp),
                                            color = RoyalBlueContainer
                                        ) {
                                            Text(
                                                text = "पाठ का संपूर्ण सारांश एवं व्याख्या (Chapter Explanation)",
                                                modifier = Modifier.padding(horizontal = 8.dp, vertical = 4.dp),
                                                style = MaterialTheme.typography.labelSmall.copy(
                                                    color = RoyalBluePrimary,
                                                    fontWeight = FontWeight.Bold
                                                )
                                            )
                                        }

                                        Spacer(modifier = Modifier.height(12.dp))

                                        Text(
                                            text = ch.hindiTitle,
                                            style = MaterialTheme.typography.titleLarge.copy(
                                                fontWeight = FontWeight.Bold,
                                                color = RoyalBlueDark,
                                                fontSize = (20 + fontSizeDelta).sp
                                            )
                                        )

                                        if (ch.authorName.isNotBlank()) {
                                            Spacer(modifier = Modifier.height(4.dp))
                                            Text(
                                                text = "लेखक: ${ch.authorName}",
                                                style = MaterialTheme.typography.titleSmall.copy(
                                                    color = TextSecondary,
                                                    fontWeight = FontWeight.SemiBold
                                                )
                                            )
                                        }

                                        Divider(modifier = Modifier.padding(vertical = 12.dp), color = OutlineLight)

                                        Text(
                                            text = ch.explanation,
                                            style = MaterialTheme.typography.bodyLarge.copy(
                                                lineHeight = (26 + fontSizeDelta).sp,
                                                fontSize = (15 + fontSizeDelta).sp,
                                                color = MaterialTheme.colorScheme.onSurface
                                            )
                                        )
                                    }
                                }
                            }
                        }

                        // Tab 1: Author Intro & Life History (लेखक परिचय व जीवन परिचय)
                        1 -> {
                            item {
                                Card(
                                    modifier = Modifier.fillMaxWidth(),
                                    shape = RoundedCornerShape(14.dp),
                                    colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
                                    elevation = CardDefaults.cardElevation(defaultElevation = 2.dp)
                                ) {
                                    Column(modifier = Modifier.padding(16.dp)) {
                                        Row(verticalAlignment = Alignment.CenterVertically) {
                                            Box(
                                                modifier = Modifier
                                                    .size(44.dp)
                                                    .clip(CircleShape)
                                                    .background(AmberContainer),
                                                contentAlignment = Alignment.Center
                                            ) {
                                                Icon(
                                                    imageVector = Icons.Default.Person,
                                                    contentDescription = null,
                                                    tint = AmberAccent
                                                )
                                            }
                                            Spacer(modifier = Modifier.width(12.dp))
                                            Column {
                                                Text(
                                                    text = "लेखक परिचय (Author Profile)",
                                                    style = MaterialTheme.typography.titleMedium.copy(
                                                        fontWeight = FontWeight.Bold,
                                                        color = RoyalBluePrimary
                                                    )
                                                )
                                                Text(
                                                    text = ch.authorName.ifBlank { "बिहार बोर्ड विशेषज्ञ" },
                                                    style = MaterialTheme.typography.bodyMedium.copy(
                                                        fontWeight = FontWeight.SemiBold
                                                    )
                                                )
                                            }
                                        }

                                        Spacer(modifier = Modifier.height(14.dp))

                                        Text(
                                            text = "संक्षिप्त परिचय:",
                                            style = MaterialTheme.typography.titleSmall.copy(
                                                fontWeight = FontWeight.Bold,
                                                color = RoyalBlueDark
                                            )
                                        )
                                        Spacer(modifier = Modifier.height(4.dp))
                                        Text(
                                            text = ch.authorIntro.ifBlank { "इस अध्याय के लेखक का परिचय उपलब्ध नहीं है।" },
                                            style = MaterialTheme.typography.bodyMedium.copy(
                                                lineHeight = (24 + fontSizeDelta).sp,
                                                fontSize = (14 + fontSizeDelta).sp
                                            )
                                        )

                                        Spacer(modifier = Modifier.height(14.dp))

                                        Text(
                                            text = "लेखक का विस्तृत जीवन परिचय एवं प्रमुख कृतियाँ:",
                                            style = MaterialTheme.typography.titleSmall.copy(
                                                fontWeight = FontWeight.Bold,
                                                color = RoyalBlueDark
                                            )
                                        )
                                        Spacer(modifier = Modifier.height(4.dp))
                                        Text(
                                            text = ch.authorLifeHistory.ifBlank { "विस्तृत जीवन परिचय शीघ्र अपडेट किया जा रहा है।" },
                                            style = MaterialTheme.typography.bodyMedium.copy(
                                                lineHeight = (24 + fontSizeDelta).sp,
                                                fontSize = (14 + fontSizeDelta).sp
                                            )
                                        )
                                    }
                                }
                            }
                        }

                        // Tab 2: Important Points & Definitions
                        2 -> {
                            item {
                                Card(
                                    modifier = Modifier.fillMaxWidth(),
                                    shape = RoundedCornerShape(14.dp),
                                    colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
                                    elevation = CardDefaults.cardElevation(defaultElevation = 2.dp)
                                ) {
                                    Column(modifier = Modifier.padding(16.dp)) {
                                        Text(
                                            text = "★ मुख्य बिंदु एवं स्मरणीय तथ्य (Important Points)",
                                            style = MaterialTheme.typography.titleMedium.copy(
                                                fontWeight = FontWeight.Bold,
                                                color = RoyalBluePrimary
                                            )
                                        )
                                        Spacer(modifier = Modifier.height(10.dp))

                                        ch.importantPoints.forEachIndexed { i, pt ->
                                            Row(
                                                modifier = Modifier.padding(vertical = 4.dp),
                                                verticalAlignment = Alignment.Top
                                            ) {
                                                Box(
                                                    modifier = Modifier
                                                        .size(20.dp)
                                                        .clip(CircleShape)
                                                        .background(RoyalBlueContainer),
                                                    contentAlignment = Alignment.Center
                                                ) {
                                                    Text(
                                                        text = "${i + 1}",
                                                        style = MaterialTheme.typography.labelSmall.copy(
                                                            color = RoyalBluePrimary,
                                                            fontWeight = FontWeight.Bold,
                                                            fontSize = 10.sp
                                                        )
                                                    )
                                                }
                                                Spacer(modifier = Modifier.width(8.dp))
                                                Text(
                                                    text = pt,
                                                    style = MaterialTheme.typography.bodyMedium.copy(
                                                        lineHeight = (22 + fontSizeDelta).sp,
                                                        fontSize = (14 + fontSizeDelta).sp
                                                    )
                                                )
                                            }
                                        }

                                        Spacer(modifier = Modifier.height(16.dp))
                                        Divider(color = OutlineLight)
                                        Spacer(modifier = Modifier.height(16.dp))

                                        Text(
                                            text = "★ महत्वपूर्ण परिभाषाएं एवं सूत्र (Key Definitions)",
                                            style = MaterialTheme.typography.titleMedium.copy(
                                                fontWeight = FontWeight.Bold,
                                                color = EmeraldAccent
                                            )
                                        )
                                        Spacer(modifier = Modifier.height(10.dp))

                                        ch.definitions.forEach { def ->
                                            Surface(
                                                modifier = Modifier
                                                    .fillMaxWidth()
                                                    .padding(vertical = 4.dp),
                                                shape = RoundedCornerShape(8.dp),
                                                color = EmeraldContainer.copy(alpha = 0.5f),
                                                border = BorderStroke(1.dp, EmeraldAccent.copy(alpha = 0.3f))
                                            ) {
                                                Text(
                                                    text = def,
                                                    modifier = Modifier.padding(10.dp),
                                                    style = MaterialTheme.typography.bodyMedium.copy(
                                                        lineHeight = (22 + fontSizeDelta).sp,
                                                        fontSize = (14 + fontSizeDelta).sp,
                                                        fontWeight = FontWeight.Medium
                                                    )
                                                )
                                            }
                                        }
                                    }
                                }
                            }
                        }

                        // Tab 3: Short Answer Questions (लघु उत्तरीय प्रश्न - 2 अंक)
                        3 -> {
                            val shortQuestions = subjectiveQuestions.filter { it.marks == 2 || it.questionType == "SHORT" }
                            if (shortQuestions.isEmpty()) {
                                item {
                                    EmptyNoticeCard("इस अध्याय के लघु उत्तरीय प्रश्न शीघ्र ही लोड किए जा रहे हैं।")
                                }
                            } else {
                                itemsIndexed(shortQuestions) { index, q ->
                                    SubjectiveQuestionCard(index = index + 1, question = q, fontSizeDelta = fontSizeDelta)
                                }
                            }
                        }

                        // Tab 4: Long Answer Questions (दीर्घ उत्तरीय प्रश्न - 5 अंक)
                        4 -> {
                            val longQuestions = subjectiveQuestions.filter { it.marks == 5 || it.questionType == "LONG" }
                            if (longQuestions.isEmpty()) {
                                item {
                                    EmptyNoticeCard("इस अध्याय के दीर्घ उत्तरीय प्रश्न शीघ्र ही लोड किए जा रहे हैं।")
                                }
                            } else {
                                itemsIndexed(longQuestions) { index, q ->
                                    SubjectiveQuestionCard(index = index + 1, question = q, fontSizeDelta = fontSizeDelta)
                                }
                            }
                        }

                        // Tab 5: Objective Questions (Interactive MCQ Mode)
                        5 -> {
                            if (objectiveQuestions.isEmpty()) {
                                item {
                                    EmptyNoticeCard("इस अध्याय के वस्तुनिष्ठ प्रश्न शीघ्र जोड़े जा रहे हैं।")
                                }
                            } else {
                                item {
                                    Card(
                                        modifier = Modifier.fillMaxWidth(),
                                        shape = RoundedCornerShape(12.dp),
                                        colors = CardDefaults.cardColors(containerColor = RoyalBlueContainer)
                                    ) {
                                        Row(
                                            modifier = Modifier.padding(12.dp),
                                            verticalAlignment = Alignment.CenterVertically
                                        ) {
                                            Icon(
                                                imageVector = Icons.Default.CheckCircle,
                                                contentDescription = null,
                                                tint = RoyalBluePrimary
                                            )
                                            Spacer(modifier = Modifier.width(10.dp))
                                            Text(
                                                text = "उत्तर जांचने के लिए किसी भी विकल्प पर क्लिक करें। व्याख्या सहित सही उत्तर तुरंत देखें।",
                                                style = MaterialTheme.typography.bodySmall.copy(
                                                    color = RoyalBlueDark,
                                                    fontWeight = FontWeight.SemiBold
                                                )
                                            )
                                        }
                                    }
                                }

                                itemsIndexed(objectiveQuestions) { index, q ->
                                    InteractiveObjectiveCard(index = index + 1, question = q)
                                }
                            }
                        }

                        // Tab 6: PDF Notes & Download
                        6 -> {
                            item {
                                Card(
                                    modifier = Modifier.fillMaxWidth(),
                                    shape = RoundedCornerShape(14.dp),
                                    colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
                                    elevation = CardDefaults.cardElevation(defaultElevation = 2.dp)
                                ) {
                                    Column(
                                        modifier = Modifier.padding(16.dp),
                                        horizontalAlignment = Alignment.CenterHorizontally
                                    ) {
                                        Box(
                                            modifier = Modifier
                                                .size(60.dp)
                                                .clip(CircleShape)
                                                .background(AmberContainer),
                                            contentAlignment = Alignment.Center
                                        ) {
                                            Icon(
                                                imageVector = Icons.Default.PictureAsPdf,
                                                contentDescription = "PDF",
                                                tint = AmberAccent,
                                                modifier = Modifier.size(34.dp)
                                            )
                                        }

                                        Spacer(modifier = Modifier.height(12.dp))

                                        Text(
                                            text = "${ch.title} - संपूर्ण हस्तलिखित नोट्स",
                                            style = MaterialTheme.typography.titleMedium.copy(
                                                fontWeight = FontWeight.Bold,
                                                color = RoyalBlueDark
                                            )
                                        )

                                        Text(
                                            text = "सत्र 2026–2027 • कुल पृष्ठ: ${ch.pageCount} • साइज: 4.8 MB",
                                            style = MaterialTheme.typography.bodySmall.copy(color = TextSecondary)
                                        )

                                        Spacer(modifier = Modifier.height(16.dp))

                                        Surface(
                                            shape = RoundedCornerShape(8.dp),
                                            color = if (ch.isDownloaded) EmeraldContainer else SurfaceVariantLight,
                                            border = BorderStroke(1.dp, if (ch.isDownloaded) EmeraldAccent else OutlineLight)
                                        ) {
                                            Row(
                                                modifier = Modifier.padding(horizontal = 12.dp, vertical = 6.dp),
                                                verticalAlignment = Alignment.CenterVertically
                                            ) {
                                                Icon(
                                                    imageVector = if (ch.isDownloaded) Icons.Default.CheckCircle else Icons.Default.CloudDownload,
                                                    contentDescription = null,
                                                    tint = if (ch.isDownloaded) EmeraldAccent else RoyalBluePrimary,
                                                    modifier = Modifier.size(16.dp)
                                                )
                                                Spacer(modifier = Modifier.width(6.dp))
                                                Text(
                                                    text = if (ch.isDownloaded) "यह पीडीएफ ऑफलाइन उपलब्ध है (Downloaded)" else "ऑनलाइन उपलब्ध • डाउनलोड करने योग्य",
                                                    style = MaterialTheme.typography.labelSmall.copy(
                                                        color = if (ch.isDownloaded) EmeraldAccent else RoyalBluePrimary,
                                                        fontWeight = FontWeight.Bold
                                                    )
                                                )
                                            }
                                        }

                                        Spacer(modifier = Modifier.height(16.dp))

                                        Button(
                                            onClick = {
                                                viewModel.toggleDownload(ch.id, ch.isDownloaded)
                                                coroutineScope.launch {
                                                    chapter = viewModel.repository.getChapterById(chapterId)
                                                }
                                            },
                                            modifier = Modifier
                                                .fillMaxWidth()
                                                .height(48.dp)
                                                .testTag("download_pdf_cta"),
                                            shape = RoundedCornerShape(10.dp),
                                            colors = ButtonDefaults.buttonColors(
                                                containerColor = if (ch.isDownloaded) EmeraldAccent else RoyalBluePrimary
                                            )
                                        ) {
                                            Icon(
                                                imageVector = if (ch.isDownloaded) Icons.Default.FileDownloadDone else Icons.Default.Download,
                                                contentDescription = null
                                            )
                                            Spacer(modifier = Modifier.width(8.dp))
                                            Text(
                                                text = if (ch.isDownloaded) "नोट्स डाउनलोड हो चुके हैं (Downloaded)" else "PDF नोट्स डाउनलोड करें (Free Download)",
                                                fontWeight = FontWeight.Bold
                                            )
                                        }

                                        Spacer(modifier = Modifier.height(10.dp))

                                        OutlinedButton(
                                            onClick = { showDigitalReaderDialog = true },
                                            modifier = Modifier
                                                .fillMaxWidth()
                                                .height(48.dp)
                                                .testTag("read_notes_offline_cta"),
                                            shape = RoundedCornerShape(10.dp),
                                            border = BorderStroke(1.5.dp, RoyalBluePrimary)
                                        ) {
                                            Icon(
                                                imageVector = Icons.Default.MenuBook,
                                                contentDescription = null,
                                                tint = RoyalBluePrimary
                                            )
                                            Spacer(modifier = Modifier.width(8.dp))
                                            Text(
                                                text = "ऑफलाइन डिजिटल रीडर में खोलें (Read Offline)",
                                                fontWeight = FontWeight.Bold,
                                                color = RoyalBluePrimary
                                            )
                                        }
                                    }
                                }
                            }
                        }
                    }
                }
            }
        }

        if (showDigitalReaderDialog && chapter != null) {
            OfflineNotesReaderDialog(
                chapter = chapter!!,
                onDismiss = { showDigitalReaderDialog = false }
            )
        }
    }
}

@Composable
fun EmptyNoticeCard(message: String) {
    Card(
        modifier = Modifier.fillMaxWidth(),
        shape = RoundedCornerShape(12.dp),
        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface)
    ) {
        Column(
            modifier = Modifier
                .padding(24.dp)
                .fillMaxWidth(),
            horizontalAlignment = Alignment.CenterHorizontally
        ) {
            Icon(
                imageVector = Icons.Default.MenuBook,
                contentDescription = null,
                tint = RoyalBluePrimary,
                modifier = Modifier.size(36.dp)
            )
            Spacer(modifier = Modifier.height(8.dp))
            Text(
                text = message,
                style = MaterialTheme.typography.bodyMedium.copy(color = TextSecondary)
            )
        }
    }
}

@Composable
fun SubjectiveQuestionCard(
    index: Int,
    question: SubjectiveQuestion,
    fontSizeDelta: Int = 0
) {
    var isExpanded by remember { mutableStateOf(false) }

    Card(
        modifier = Modifier
            .fillMaxWidth()
            .clickable { isExpanded = !isExpanded },
        shape = RoundedCornerShape(12.dp),
        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
        elevation = CardDefaults.cardElevation(defaultElevation = 1.dp)
    ) {
        Column(modifier = Modifier.padding(14.dp)) {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Surface(
                    shape = RoundedCornerShape(6.dp),
                    color = if (question.marks == 5) AmberContainer else RoyalBlueContainer
                ) {
                    Text(
                        text = "प्रश्न $index (${question.marks} अंक • ${if (question.marks == 5) "दीर्घ उत्तरीय" else "लघु उत्तरीय"})",
                        modifier = Modifier.padding(horizontal = 6.dp, vertical = 2.dp),
                        style = MaterialTheme.typography.labelSmall.copy(
                            color = if (question.marks == 5) AmberAccent else RoyalBluePrimary,
                            fontWeight = FontWeight.Bold,
                            fontSize = 11.sp
                        )
                    )
                }

                if (question.isPreviousYear) {
                    Surface(
                        shape = RoundedCornerShape(4.dp),
                        color = EmeraldContainer
                    ) {
                        Text(
                            text = "BSEB ${question.examYear} PYQ",
                            modifier = Modifier.padding(horizontal = 6.dp, vertical = 2.dp),
                            style = MaterialTheme.typography.labelSmall.copy(
                                color = EmeraldAccent,
                                fontWeight = FontWeight.Bold,
                                fontSize = 10.sp
                            )
                        )
                    }
                }
            }

            Spacer(modifier = Modifier.height(8.dp))

            Text(
                text = question.questionText,
                style = MaterialTheme.typography.titleSmall.copy(
                    fontWeight = FontWeight.Bold,
                    color = RoyalBlueDark,
                    fontSize = (15 + fontSizeDelta).sp
                )
            )

            Spacer(modifier = Modifier.height(6.dp))

            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Text(
                    text = if (isExpanded) "उत्तर छुपाएं ▲" else "उत्तर देखें ▼",
                    style = MaterialTheme.typography.labelMedium.copy(
                        color = RoyalBluePrimary,
                        fontWeight = FontWeight.Bold
                    )
                )
            }

            AnimatedVisibility(visible = isExpanded) {
                Column {
                    Divider(modifier = Modifier.padding(vertical = 10.dp), color = OutlineLight)
                    Text(
                        text = question.answerText,
                        style = MaterialTheme.typography.bodyMedium.copy(
                            color = MaterialTheme.colorScheme.onSurface,
                            lineHeight = (24 + fontSizeDelta).sp,
                            fontSize = (14 + fontSizeDelta).sp
                        )
                    )
                }
            }
        }
    }
}

@Composable
fun InteractiveObjectiveCard(
    index: Int,
    question: ObjectiveQuestion
) {
    var selectedOption by remember { mutableStateOf<Int?>(null) }
    val isSubmitted = selectedOption != null

    Card(
        modifier = Modifier.fillMaxWidth(),
        shape = RoundedCornerShape(12.dp),
        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
        elevation = CardDefaults.cardElevation(defaultElevation = 1.dp)
    ) {
        Column(modifier = Modifier.padding(14.dp)) {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween
            ) {
                Surface(
                    shape = RoundedCornerShape(6.dp),
                    color = RoyalBlueContainer
                ) {
                    Text(
                        text = "वस्तुनिष्ठ प्रश्न $index",
                        modifier = Modifier.padding(horizontal = 6.dp, vertical = 2.dp),
                        style = MaterialTheme.typography.labelSmall.copy(
                            color = RoyalBluePrimary,
                            fontWeight = FontWeight.Bold
                        )
                    )
                }
                if (question.isPreviousYear) {
                    Surface(
                        shape = RoundedCornerShape(4.dp),
                        color = EmeraldContainer
                    ) {
                        Text(
                            text = "BSEB ${question.examYear}",
                            modifier = Modifier.padding(horizontal = 6.dp, vertical = 2.dp),
                            style = MaterialTheme.typography.labelSmall.copy(
                                color = EmeraldAccent,
                                fontWeight = FontWeight.Bold,
                                fontSize = 10.sp
                            )
                        )
                    }
                }
            }

            Spacer(modifier = Modifier.height(10.dp))

            Text(
                text = question.questionText,
                style = MaterialTheme.typography.titleSmall.copy(
                    fontWeight = FontWeight.Bold,
                    color = MaterialTheme.colorScheme.onSurface
                )
            )

            Spacer(modifier = Modifier.height(12.dp))

            val options = listOf(
                1 to question.optionA,
                2 to question.optionB,
                3 to question.optionC,
                4 to question.optionD
            )

            options.forEach { (optNum, optText) ->
                val isSelected = selectedOption == optNum
                val isCorrect = optNum == question.correctOption

                val cardBg = when {
                    !isSubmitted -> MaterialTheme.colorScheme.surface
                    isCorrect -> EmeraldContainer
                    isSelected -> Color(0xFFFFE4E6) // light red
                    else -> MaterialTheme.colorScheme.surface
                }

                val borderCol = when {
                    !isSubmitted -> if (isSelected) RoyalBluePrimary else OutlineLight
                    isCorrect -> EmeraldAccent
                    isSelected -> Color(0xFFE11D48)
                    else -> OutlineLight
                }

                Surface(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(vertical = 4.dp)
                        .clickable { selectedOption = optNum },
                    shape = RoundedCornerShape(8.dp),
                    color = cardBg,
                    border = BorderStroke(1.dp, borderCol)
                ) {
                    Row(
                        modifier = Modifier.padding(10.dp),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Box(
                            modifier = Modifier
                                .size(24.dp)
                                .clip(CircleShape)
                                .background(
                                    when {
                                        !isSubmitted -> if (isSelected) RoyalBluePrimary else OutlineLight
                                        isCorrect -> EmeraldAccent
                                        isSelected -> Color(0xFFE11D48)
                                        else -> OutlineLight
                                    }
                                ),
                            contentAlignment = Alignment.Center
                        ) {
                            Text(
                                text = when (optNum) {
                                    1 -> "A"
                                    2 -> "B"
                                    3 -> "C"
                                    else -> "D"
                                },
                                style = MaterialTheme.typography.labelSmall.copy(
                                    color = Color.White,
                                    fontWeight = FontWeight.Bold
                                )
                            )
                        }

                        Spacer(modifier = Modifier.width(10.dp))

                        Text(
                            text = optText,
                            style = MaterialTheme.typography.bodyMedium.copy(
                                fontWeight = if (isSelected || (isSubmitted && isCorrect)) FontWeight.Bold else FontWeight.Normal,
                                color = if (isSubmitted && isCorrect) EmeraldAccent else MaterialTheme.colorScheme.onSurface
                            ),
                            modifier = Modifier.weight(1f)
                        )

                        if (isSubmitted && isCorrect) {
                            Icon(
                                imageVector = Icons.Default.CheckCircle,
                                contentDescription = "Correct",
                                tint = EmeraldAccent,
                                modifier = Modifier.size(18.dp)
                            )
                        } else if (isSubmitted && isSelected) {
                            Icon(
                                imageVector = Icons.Default.Cancel,
                                contentDescription = "Wrong",
                                tint = Color(0xFFE11D48),
                                modifier = Modifier.size(18.dp)
                            )
                        }
                    }
                }
            }

            if (isSubmitted && question.explanation.isNotBlank()) {
                Spacer(modifier = Modifier.height(8.dp))
                Surface(
                    shape = RoundedCornerShape(8.dp),
                    color = AmberContainer.copy(alpha = 0.6f),
                    border = BorderStroke(1.dp, AmberAccent.copy(alpha = 0.4f))
                ) {
                    Row(modifier = Modifier.padding(10.dp)) {
                        Icon(
                            imageVector = Icons.Default.Lightbulb,
                            contentDescription = "व्याख्या",
                            tint = AmberAccent,
                            modifier = Modifier.size(18.dp)
                        )
                        Spacer(modifier = Modifier.width(6.dp))
                        Column {
                            Text(
                                text = "स्पष्टीकरण (Explanation):",
                                style = MaterialTheme.typography.labelSmall.copy(
                                    fontWeight = FontWeight.Bold,
                                    color = AmberAccent
                                )
                            )
                            Text(
                                text = question.explanation,
                                style = MaterialTheme.typography.bodySmall.copy(color = RoyalBlueDark)
                            )
                        }
                    }
                }
            }
        }
    }
}

@Composable
fun OfflineNotesReaderDialog(
    chapter: Chapter,
    onDismiss: () -> Unit
) {
    var readerFontSize by remember { mutableStateOf(16) }
    var readingTheme by remember { mutableStateOf("paper") } // "paper", "night", "white"
    var selectedPage by remember { mutableStateOf(0) } // 0: Summary & Concepts, 1: Full Explanation, 2: Key Points & Formulas

    val pageTitles = listOf("मुख्य बिंदु व परिचय", "विस्तृत अध्याय व्याख्या", "महत्वपूर्ण परिभाषाएं")

    val bgColor = when (readingTheme) {
        "night" -> Color(0xFF1E293B)
        "paper" -> Color(0xFFFFFBEB)
        else -> Color.White
    }
    val textColor = when (readingTheme) {
        "night" -> Color(0xFFF1F5F9)
        "paper" -> Color(0xFF292524)
        else -> Color(0xFF0F172A)
    }

    androidx.compose.ui.window.Dialog(
        onDismissRequest = onDismiss,
        properties = androidx.compose.ui.window.DialogProperties(usePlatformDefaultWidth = false)
    ) {
        Surface(
            modifier = Modifier
                .fillMaxSize()
                .background(bgColor),
            color = bgColor
        ) {
            Column(modifier = Modifier.fillMaxSize()) {
                // Top Reader Header
                Surface(
                    color = if (readingTheme == "night") Color(0xFF0F172A) else RoyalBluePrimary,
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(horizontal = 14.dp, vertical = 10.dp),
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.SpaceBetween
                    ) {
                        IconButton(onClick = onDismiss) {
                            Icon(imageVector = Icons.Default.Close, contentDescription = "Close", tint = Color.White)
                        }

                        Column(horizontalAlignment = Alignment.CenterHorizontally, modifier = Modifier.weight(1f)) {
                            Text(
                                text = chapter.title,
                                style = MaterialTheme.typography.titleMedium.copy(
                                    fontWeight = FontWeight.Bold,
                                    color = Color.White,
                                    fontSize = 15.sp
                                ),
                                maxLines = 1,
                                overflow = TextOverflow.Ellipsis
                            )
                            Text(
                                text = "ऑफलाइन डिजिटल रीडर • सत्र 2026–2027",
                                style = MaterialTheme.typography.labelSmall.copy(
                                    color = Color.White.copy(alpha = 0.8f),
                                    fontSize = 11.sp
                                )
                            )
                        }

                        Row(verticalAlignment = Alignment.CenterVertically) {
                            // Zoom buttons
                            IconButton(onClick = { if (readerFontSize > 12) readerFontSize -= 2 }) {
                                Text("A-", color = Color.White, fontWeight = FontWeight.Bold, fontSize = 12.sp)
                            }
                            IconButton(onClick = { if (readerFontSize < 24) readerFontSize += 2 }) {
                                Text("A+", color = Color.White, fontWeight = FontWeight.Bold, fontSize = 15.sp)
                            }
                            // Theme toggle
                            IconButton(onClick = {
                                readingTheme = when (readingTheme) {
                                    "paper" -> "night"
                                    "night" -> "white"
                                    else -> "paper"
                                }
                            }) {
                                Icon(
                                    imageVector = if (readingTheme == "night") Icons.Default.LightMode else Icons.Default.DarkMode,
                                    contentDescription = "Theme",
                                    tint = BiharBoardGold
                                )
                            }
                        }
                    }
                }

                // Page navigation tabs
                ScrollableTabRow(
                    selectedTabIndex = selectedPage,
                    containerColor = if (readingTheme == "night") Color(0xFF334155) else Color(0xFFE2E8F0),
                    contentColor = RoyalBluePrimary,
                    edgePadding = 12.dp
                ) {
                    pageTitles.forEachIndexed { idx, title ->
                        Tab(
                            selected = selectedPage == idx,
                            onClick = { selectedPage = idx },
                            text = {
                                Text(
                                    text = title,
                                    fontWeight = if (selectedPage == idx) FontWeight.Bold else FontWeight.Normal,
                                    fontSize = 12.sp,
                                    color = if (selectedPage == idx) (if (readingTheme == "night") BiharBoardGold else RoyalBluePrimary) else TextMuted
                                )
                            }
                        )
                    }
                }

                // Reader Content Scrollable Area
                LazyColumn(
                    modifier = Modifier
                        .fillMaxSize()
                        .padding(horizontal = 20.dp, vertical = 16.dp)
                ) {
                    when (selectedPage) {
                        0 -> {
                            item {
                                Surface(
                                    shape = RoundedCornerShape(8.dp),
                                    color = if (readingTheme == "night") Color(0xFF334155) else RoyalBlueContainer,
                                    modifier = Modifier.fillMaxWidth()
                                ) {
                                    Column(modifier = Modifier.padding(14.dp)) {
                                        Text(
                                            text = "लेखक / कवि: ${chapter.authorName.ifBlank { "बिहार बोर्ड पाठ्यक्रम" }}",
                                            fontWeight = FontWeight.Bold,
                                            color = if (readingTheme == "night") Color.White else RoyalBlueDark,
                                            fontSize = (readerFontSize + 1).sp
                                        )
                                        if (chapter.authorIntro.isNotBlank()) {
                                            Spacer(modifier = Modifier.height(6.dp))
                                            Text(
                                                text = chapter.authorIntro,
                                                color = textColor,
                                                fontSize = readerFontSize.sp,
                                                lineHeight = (readerFontSize * 1.6).sp
                                            )
                                        }
                                    }
                                }

                                Spacer(modifier = Modifier.height(16.dp))

                                Text(
                                    text = "★ लेखक का जीवन परिचय एवं प्रमुख कृतियाँ:",
                                    fontWeight = FontWeight.Bold,
                                    color = if (readingTheme == "night") BiharBoardGold else RoyalBluePrimary,
                                    fontSize = (readerFontSize + 2).sp
                                )
                                Spacer(modifier = Modifier.height(8.dp))
                                Text(
                                    text = chapter.authorLifeHistory.ifBlank { "विस्तृत जीवन परिचय उपलब्ध है।" },
                                    color = textColor,
                                    fontSize = readerFontSize.sp,
                                    lineHeight = (readerFontSize * 1.6).sp
                                )
                            }
                        }
                        1 -> {
                            item {
                                Text(
                                    text = "अध्याय संपूर्ण व्याख्या (Complete Explanation):",
                                    fontWeight = FontWeight.Bold,
                                    color = if (readingTheme == "night") BiharBoardGold else RoyalBluePrimary,
                                    fontSize = (readerFontSize + 2).sp
                                )
                                Spacer(modifier = Modifier.height(10.dp))
                                Text(
                                    text = chapter.explanation,
                                    color = textColor,
                                    fontSize = readerFontSize.sp,
                                    lineHeight = (readerFontSize * 1.65).sp
                                )
                            }
                        }
                        2 -> {
                            item {
                                Text(
                                    text = "मुख्य बिंदु एवं स्मरणीय तथ्य (Important Points):",
                                    fontWeight = FontWeight.Bold,
                                    color = if (readingTheme == "night") BiharBoardGold else RoyalBluePrimary,
                                    fontSize = (readerFontSize + 2).sp
                                )
                                Spacer(modifier = Modifier.height(8.dp))
                                chapter.importantPoints.forEachIndexed { i, pt ->
                                    Row(
                                        modifier = Modifier.padding(vertical = 4.dp),
                                        verticalAlignment = Alignment.Top
                                    ) {
                                        Text(
                                            text = "• ",
                                            fontWeight = FontWeight.Bold,
                                            color = if (readingTheme == "night") BiharBoardGold else RoyalBluePrimary,
                                            fontSize = (readerFontSize + 2).sp
                                        )
                                        Text(
                                            text = pt,
                                            color = textColor,
                                            fontSize = readerFontSize.sp,
                                            lineHeight = (readerFontSize * 1.55).sp
                                        )
                                    }
                                }

                                if (chapter.definitions.isNotEmpty()) {
                                    Spacer(modifier = Modifier.height(20.dp))
                                    Text(
                                        text = "महत्वपूर्ण परिभाषाएं व शब्दावली:",
                                        fontWeight = FontWeight.Bold,
                                        color = if (readingTheme == "night") BiharBoardGold else RoyalBluePrimary,
                                        fontSize = (readerFontSize + 2).sp
                                    )
                                    Spacer(modifier = Modifier.height(8.dp))
                                    chapter.definitions.forEach { def ->
                                        Row(
                                            modifier = Modifier.padding(vertical = 4.dp),
                                            verticalAlignment = Alignment.Top
                                        ) {
                                            Text(
                                                text = "★ ",
                                                fontWeight = FontWeight.Bold,
                                                color = EmeraldAccent,
                                                fontSize = readerFontSize.sp
                                            )
                                            Text(
                                                text = def,
                                                color = textColor,
                                                fontSize = readerFontSize.sp,
                                                lineHeight = (readerFontSize * 1.55).sp
                                            )
                                        }
                                    }
                                }
                            }
                        }
                    }
                }
            }
        }
    }
}

