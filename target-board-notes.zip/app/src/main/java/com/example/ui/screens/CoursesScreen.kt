package com.example.ui.screens

import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.SwapHoriz
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.ui.components.*
import com.example.ui.navigation.Screen
import com.example.ui.theme.*
import com.example.ui.viewmodel.MainViewModel

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun CoursesScreen(
    viewModel: MainViewModel,
    onNavigate: (Screen) -> Unit
) {
    val selectedCourseId by viewModel.selectedCourseId.collectAsState()
    val courses = viewModel.repository.getAllCourses()
    val currentCourse = courses.find { it.id == selectedCourseId } ?: courses.first()
    val subjects by viewModel.currentSubjects.collectAsState()

    Scaffold(
        topBar = {
            TargetBoardTopBar(
                title = "पाठ्यक्रम: ${currentCourse.title}",
                subtitle = "बिहार बोर्ड 2026–2027 • 100% नि:शुल्क",
                canNavigateBack = true,
                onNavigateBack = { onNavigate(Screen.Home) },
                actions = {
                    TextButton(onClick = { onNavigate(Screen.CourseSelection) }) {
                        Icon(imageVector = Icons.Default.SwapHoriz, contentDescription = null, tint = BiharBoardGold)
                        Spacer(modifier = Modifier.width(4.dp))
                        Text("कोर्स बदलें", color = Color.White, fontSize = 12.sp, fontWeight = FontWeight.Bold)
                    }
                }
            )
        },
        bottomBar = {
            TargetBoardBottomBar(
                currentRoute = Screen.Courses.route,
                onNavigate = onNavigate
            )
        }
    ) { innerPadding ->
        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(innerPadding)
                .background(MaterialTheme.colorScheme.background)
        ) {
            // Course Switcher Tab Row
            ScrollableTabRow(
                selectedTabIndex = courses.indexOfFirst { it.id == selectedCourseId }.coerceAtLeast(0),
                containerColor = MaterialTheme.colorScheme.surface,
                contentColor = RoyalBluePrimary,
                edgePadding = 16.dp
            ) {
                courses.forEach { course ->
                    val isSelected = course.id == selectedCourseId
                    Tab(
                        selected = isSelected,
                        onClick = { viewModel.selectAndPersistCourse(course.id) },
                        text = {
                            Text(
                                text = course.title,
                                fontWeight = if (isSelected) FontWeight.Bold else FontWeight.Normal,
                                fontSize = 14.sp
                            )
                        },
                        modifier = Modifier.testTag("course_tab_${course.id}")
                    )
                }
            }

            LazyColumn(
                modifier = Modifier
                    .fillMaxSize()
                    .padding(horizontal = 16.dp, vertical = 12.dp)
            ) {
                // Course Overview Card
                item {
                    Card(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(bottom = 14.dp),
                        shape = RoundedCornerShape(12.dp),
                        colors = CardDefaults.cardColors(containerColor = RoyalBlueContainer)
                    ) {
                        Column(modifier = Modifier.padding(14.dp)) {
                            Row(
                                modifier = Modifier.fillMaxWidth(),
                                horizontalArrangement = Arrangement.SpaceBetween,
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                Text(
                                    text = currentCourse.hindiTitle,
                                    style = MaterialTheme.typography.titleMedium.copy(
                                        fontWeight = FontWeight.Bold,
                                        color = RoyalBluePrimary
                                    )
                                )
                                Surface(
                                    shape = RoundedCornerShape(4.dp),
                                    color = EmeraldAccent
                                ) {
                                    Text(
                                        text = currentCourse.badge,
                                        modifier = Modifier.padding(horizontal = 6.dp, vertical = 2.dp),
                                        style = MaterialTheme.typography.labelSmall.copy(
                                            color = Color.White,
                                            fontWeight = FontWeight.Bold
                                        )
                                    )
                                }
                            }
                            Spacer(modifier = Modifier.height(4.dp))
                            Text(
                                text = currentCourse.description,
                                style = MaterialTheme.typography.bodySmall.copy(color = RoyalBlueDark)
                            )
                        }
                    }
                }

                item {
                    Text(
                        text = "सभी विषय (${subjects.size})",
                        style = MaterialTheme.typography.titleMedium.copy(
                            fontWeight = FontWeight.Bold,
                            color = MaterialTheme.colorScheme.onBackground
                        ),
                        modifier = Modifier.padding(bottom = 8.dp)
                    )
                }

                items(subjects) { subject ->
                    SubjectCard(
                        subject = subject,
                        onClick = { onNavigate(Screen.SubjectDetail(subject.id)) }
                    )
                    Spacer(modifier = Modifier.height(10.dp))
                }
            }
        }
    }
}
