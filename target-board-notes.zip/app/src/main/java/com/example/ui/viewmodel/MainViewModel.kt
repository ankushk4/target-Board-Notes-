package com.example.ui.viewmodel

import android.app.Application
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import com.example.data.model.*
import com.example.data.repository.TargetBoardRepository
import kotlinx.coroutines.ExperimentalCoroutinesApi
import kotlinx.coroutines.flow.*
import kotlinx.coroutines.launch

@OptIn(ExperimentalCoroutinesApi::class)
class MainViewModel(application: Application) : AndroidViewModel(application) {

    val repository = TargetBoardRepository.getInstance(application)
    val authRepository = com.example.data.repository.FirebaseAuthRepository.getInstance(application)
    val firebaseSync = repository.firebaseSync
    private val prefs = repository.preferencesManager

    val currentUser = authRepository.currentUser
    val isAuthenticating = authRepository.isAuthenticating
    val authError = authRepository.authError

    // Persistent Course Selection (defaults to stored course or "class_10")
    private val _selectedCourseId = MutableStateFlow(prefs.getSelectedCourseId() ?: "class_10")
    val selectedCourseId: StateFlow<String> = _selectedCourseId.asStateFlow()

    private val _hasSelectedCourse = MutableStateFlow(prefs.isCourseSelected())
    val hasSelectedCourse: StateFlow<Boolean> = _hasSelectedCourse.asStateFlow()

    private val _searchQuery = MutableStateFlow("")
    val searchQuery: StateFlow<String> = _searchQuery.asStateFlow()

    private val _searchResults = MutableStateFlow<List<Chapter>>(emptyList())
    val searchResults: StateFlow<List<Chapter>> = _searchResults.asStateFlow()

    // App Language ("hi" or "en")
    private val _appLanguage = MutableStateFlow(repository.preferencesManager.getAppLanguage())
    val appLanguage: StateFlow<String> = _appLanguage.asStateFlow()

    fun setAppLanguage(lang: String) {
        val valid = if (lang.lowercase() == "en") "en" else "hi"
        repository.preferencesManager.setAppLanguage(valid)
        _appLanguage.value = valid
    }

    fun toggleLanguage() {
        val next = if (_appLanguage.value == "hi") "en" else "hi"
        setAppLanguage(next)
    }

    // Reactive streams filtered strictly by current course and publication status for students
    val currentSubjects: StateFlow<List<Subject>> = _selectedCourseId
        .flatMapLatest { courseId -> repository.getSubjectsByCourse(courseId) }
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    val currentChapters: StateFlow<List<Chapter>> = _selectedCourseId
        .flatMapLatest { courseId -> repository.getChaptersByCourse(courseId) }
        .map { list -> list.filter { it.isPublished } }
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    val currentAnnouncements: StateFlow<List<Announcement>> = _selectedCourseId
        .flatMapLatest { courseId -> repository.getAnnouncementsByCourse(courseId) }
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    val currentBookmarks: StateFlow<List<Bookmark>> = _selectedCourseId
        .flatMapLatest { courseId -> repository.getBookmarksByCourse(courseId) }
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    val currentMockTests: StateFlow<List<MockTest>> = _selectedCourseId
        .flatMapLatest { courseId -> repository.getMockTestsByCourse(courseId) }
        .map { list -> list.filter { it.isPublished } }
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    val bookmarks: StateFlow<List<Bookmark>> get() = currentBookmarks
    val allMockTests: StateFlow<List<MockTest>> get() = currentMockTests
    val announcements: StateFlow<List<Announcement>> get() = currentAnnouncements

    fun selectCourse(courseId: String) = selectAndPersistCourse(courseId)

    private val _studentProfile = MutableStateFlow(StudentProfile())
    val studentProfile: StateFlow<StudentProfile> = _studentProfile.asStateFlow()

    private val _updateInfo = MutableStateFlow<AppUpdateInfo?>(null)
    val updateInfo: StateFlow<AppUpdateInfo?> = _updateInfo.asStateFlow()

    private val _showUpdateDialog = MutableStateFlow(false)
    val showUpdateDialog: StateFlow<Boolean> = _showUpdateDialog.asStateFlow()

    private val _activeMockTestResult = MutableStateFlow<MockTestResult?>(null)
    val activeMockTestResult: StateFlow<MockTestResult?> = _activeMockTestResult.asStateFlow()

    private val _isSyncing = MutableStateFlow(false)
    val isSyncing: StateFlow<Boolean> = _isSyncing.asStateFlow()

    private val _lastSyncTimestamp = MutableStateFlow(System.currentTimeMillis())
    val lastSyncTimestamp: StateFlow<Long> = _lastSyncTimestamp.asStateFlow()

    init {
        checkForAppUpdates()
        viewModelScope.launch {
            _selectedCourseId.collect { courseId ->
                firebaseSync.startRealtimeSync(courseId)
            }
        }
    }

    fun refreshSync() {
        viewModelScope.launch {
            _isSyncing.value = true
            firebaseSync.startRealtimeSync(_selectedCourseId.value)
            kotlinx.coroutines.delay(650)
            _lastSyncTimestamp.value = System.currentTimeMillis()
            _isSyncing.value = false
        }
    }

    fun selectAndPersistCourse(courseId: String) {
        _selectedCourseId.value = courseId
        _hasSelectedCourse.value = true
        prefs.setSelectedCourseId(courseId)
        val current = _studentProfile.value
        _studentProfile.value = current.copy(selectedCourseId = courseId)
    }

    fun resetCourseSelection() {
        prefs.clearCourseSelection()
        _hasSelectedCourse.value = false
    }

    fun onSearchQueryChange(query: String) {
        _searchQuery.value = query
        if (query.isBlank()) {
            _searchResults.value = emptyList()
        } else {
            viewModelScope.launch {
                _searchResults.value = repository.searchChapters(_selectedCourseId.value, query)
            }
        }
    }

    fun toggleBookmark(chapter: Chapter, isCurrentlyBookmarked: Boolean) {
        viewModelScope.launch {
            repository.toggleBookmark(chapter, isCurrentlyBookmarked)
        }
    }

    fun toggleDownload(chapterId: String, currentStatus: Boolean) {
        viewModelScope.launch {
            repository.toggleDownloadChapter(chapterId, currentStatus)
        }
    }

    fun checkForAppUpdates() {
        viewModelScope.launch {
            val info = repository.checkForUpdates()
            _updateInfo.value = info
            if (info.latestVersionCode > info.currentVersionCode) {
                _showUpdateDialog.value = true
            }
        }
    }

    fun dismissUpdateDialog() {
        _showUpdateDialog.value = false
    }

    fun submitMockTest(
        test: MockTest,
        questions: List<ObjectiveQuestion>,
        userAnswers: Map<String, Int>,
        timeSpentSec: Long
    ) {
        var correctCount = 0
        var wrongCount = 0
        var attemptedCount = 0

        val reviewItems = questions.map { question ->
            val selected = userAnswers[question.id] ?: 0
            val isAttempted = selected != 0
            if (isAttempted) attemptedCount++
            val isCorrect = selected == question.correctOption
            if (isCorrect) correctCount++ else if (isAttempted) wrongCount++

            QuestionReviewItem(
                question = question,
                selectedOption = selected,
                isCorrect = isCorrect
            )
        }

        val totalQuestions = questions.size
        val unattempted = totalQuestions - attemptedCount
        val score = correctCount * (test.totalMarks / (if (totalQuestions > 0) totalQuestions else 1))
        val percentage = if (totalQuestions > 0) (correctCount.toFloat() / totalQuestions.toFloat()) * 100f else 0f

        val performance = when {
            percentage >= 80 -> "शानदार (Excellent! टॉपर स्तर)"
            percentage >= 60 -> "उत्तम (Good Performance)"
            percentage >= 40 -> "संतोषजनक (Satisfactory)"
            else -> "अभ्यास आवश्यक (Needs Practice)"
        }

        val result = MockTestResult(
            testId = test.id,
            testTitle = test.title,
            totalQuestions = totalQuestions,
            attempted = attemptedCount,
            correct = correctCount,
            wrong = wrongCount,
            unattempted = unattempted,
            score = score,
            percentage = percentage,
            timeTakenSeconds = timeSpentSec,
            performanceRating = performance,
            questionReviewList = reviewItems
        )

        _activeMockTestResult.value = result

        val current = _studentProfile.value
        _studentProfile.value = current.copy(
            solvedQuestionsCount = current.solvedQuestionsCount + attemptedCount,
            testsCompletedCount = current.testsCompletedCount + 1
        )
    }

    fun clearActiveMockTestResult() {
        _activeMockTestResult.value = null
    }
}
