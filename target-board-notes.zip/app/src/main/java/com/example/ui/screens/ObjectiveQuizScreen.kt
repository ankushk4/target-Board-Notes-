package com.example.ui.screens

import androidx.compose.animation.*
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.data.model.ObjectiveQuestion
import com.example.ui.components.TargetBoardTopBar
import com.example.ui.navigation.Screen
import com.example.ui.theme.*
import com.example.ui.viewmodel.MainViewModel

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun ObjectiveQuizScreen(
    chapterId: String = "",
    subjectId: String = "",
    viewModel: MainViewModel,
    onNavigate: (Screen) -> Unit,
    onBack: () -> Unit = { onNavigate(Screen.Home) }
) {
    var questions by remember { mutableStateOf<List<ObjectiveQuestion>>(emptyList()) }
    var currentIndex by remember { mutableStateOf(0) }
    var selectedOption by remember { mutableStateOf<Int?>(null) }
    var isSubmitted by remember { mutableStateOf(false) }
    var score by remember { mutableStateOf(0) }
    var isCompleted by remember { mutableStateOf(false) }

    LaunchedEffect(chapterId, subjectId) {
        if (chapterId.isNotBlank()) {
            viewModel.repository.getObjectiveQuestions(chapterId).collect {
                questions = it
            }
        } else if (subjectId.isNotBlank()) {
            questions = viewModel.repository.getObjectiveQuestionsForSubject(subjectId)
        } else {
            questions = viewModel.repository.getRandomObjectiveQuestionsByCourse(viewModel.selectedCourseId.value, 10)
        }
    }

    Scaffold(
        topBar = {
            TargetBoardTopBar(
                title = "वस्तुनिष्ठ प्रश्नोत्तरी (MCQ Quiz)",
                subtitle = "बिहार बोर्ड VVI ऑब्जेक्टिव प्रश्न",
                canNavigateBack = true,
                onNavigateBack = onBack
            )
        }
    ) { innerPadding ->
        if (questions.isEmpty()) {
            Box(
                modifier = Modifier
                    .fillMaxSize()
                    .padding(innerPadding),
                contentAlignment = Alignment.Center
            ) {
                Column(horizontalAlignment = Alignment.CenterHorizontally) {
                    CircularProgressIndicator(color = RoyalBluePrimary)
                    Spacer(modifier = Modifier.height(12.dp))
                    Text("प्रश्न लोड हो रहे हैं...", style = MaterialTheme.typography.bodyMedium)
                }
            }
        } else if (isCompleted) {
            // Quiz Completed Result Card
            Box(
                modifier = Modifier
                    .fillMaxSize()
                    .padding(innerPadding)
                    .background(MaterialTheme.colorScheme.background),
                contentAlignment = Alignment.Center
            ) {
                Card(
                    modifier = Modifier
                        .fillMaxWidth(0.92f)
                        .padding(16.dp),
                    shape = RoundedCornerShape(16.dp),
                    colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
                    elevation = CardDefaults.cardElevation(defaultElevation = 4.dp)
                ) {
                    Column(
                        modifier = Modifier.padding(24.dp),
                        horizontalAlignment = Alignment.CenterHorizontally
                    ) {
                        Box(
                            modifier = Modifier
                                .size(72.dp)
                                .clip(CircleShape)
                                .background(if (score >= questions.size / 2) EmeraldContainer else AmberContainer),
                            contentAlignment = Alignment.Center
                        ) {
                            Icon(
                                imageVector = if (score >= questions.size / 2) Icons.Default.EmojiEvents else Icons.Default.SportsScore,
                                contentDescription = null,
                                tint = if (score >= questions.size / 2) EmeraldAccent else AmberAccent,
                                modifier = Modifier.size(40.dp)
                            )
                        }

                        Spacer(modifier = Modifier.height(16.dp))

                        Text(
                            text = "क्विज समाप्त हुआ!",
                            style = MaterialTheme.typography.headlineSmall.copy(
                                fontWeight = FontWeight.Bold,
                                color = RoyalBlueDark
                            )
                        )

                        Spacer(modifier = Modifier.height(8.dp))

                        Text(
                            text = "आपका कुल प्राप्तांक",
                            style = MaterialTheme.typography.bodyMedium.copy(color = TextSecondary)
                        )

                        Text(
                            text = "$score / ${questions.size}",
                            style = MaterialTheme.typography.headlineLarge.copy(
                                fontWeight = FontWeight.Bold,
                                color = RoyalBluePrimary
                            )
                        )

                        val percent = (score.toFloat() / questions.size.toFloat()) * 100f
                        Surface(
                            shape = RoundedCornerShape(20.dp),
                            color = if (percent >= 60) EmeraldContainer else AmberContainer,
                            modifier = Modifier.padding(vertical = 8.dp)
                        ) {
                            Text(
                                text = "सटीकता: ${percent.toInt()}% • ${if (percent >= 80) "अति उत्तम (Excellent)" else if (percent >= 50) "अच्छा प्रदर्शन (Good)" else "अधिक अभ्यास आवश्यक"}",
                                modifier = Modifier.padding(horizontal = 12.dp, vertical = 6.dp),
                                style = MaterialTheme.typography.labelMedium.copy(
                                    fontWeight = FontWeight.Bold,
                                    color = if (percent >= 60) EmeraldAccent else AmberAccent
                                )
                            )
                        }

                        Spacer(modifier = Modifier.height(20.dp))

                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.spacedBy(10.dp)
                        ) {
                            OutlinedButton(
                                onClick = {
                                    currentIndex = 0
                                    score = 0
                                    selectedOption = null
                                    isSubmitted = false
                                    isCompleted = false
                                    questions = questions.shuffled()
                                },
                                modifier = Modifier.weight(1f),
                                shape = RoundedCornerShape(10.dp)
                            ) {
                                Text("पुनः प्रयास (Retry)")
                            }

                            Button(
                                onClick = { onNavigate(Screen.Home) },
                                modifier = Modifier.weight(1f),
                                shape = RoundedCornerShape(10.dp),
                                colors = ButtonDefaults.buttonColors(containerColor = RoyalBluePrimary)
                            ) {
                                Text("मुख्य पृष्ठ")
                            }
                        }
                    }
                }
            }
        } else {
            val q = questions[currentIndex]

            LazyColumn(
                modifier = Modifier
                    .fillMaxSize()
                    .padding(innerPadding)
                    .padding(16.dp),
                verticalArrangement = Arrangement.spacedBy(14.dp)
            ) {
                // Progress Header
                item {
                    Column {
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Text(
                                text = "प्रश्न ${currentIndex + 1} / ${questions.size}",
                                style = MaterialTheme.typography.titleMedium.copy(
                                    fontWeight = FontWeight.Bold,
                                    color = RoyalBluePrimary
                                )
                            )
                            Text(
                                text = "स्कोर: $score अंक",
                                style = MaterialTheme.typography.titleSmall.copy(
                                    fontWeight = FontWeight.Bold,
                                    color = EmeraldAccent
                                )
                            )
                        }

                        Spacer(modifier = Modifier.height(8.dp))

                        LinearProgressIndicator(
                            progress = { (currentIndex + 1).toFloat() / questions.size.toFloat() },
                            modifier = Modifier
                                .fillMaxWidth()
                                .height(8.dp)
                                .clip(RoundedCornerShape(4.dp)),
                            color = RoyalBluePrimary,
                            trackColor = RoyalBlueContainer
                        )
                    }
                }

                // Question Card
                item {
                    Card(
                        modifier = Modifier.fillMaxWidth(),
                        shape = RoundedCornerShape(14.dp),
                        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
                        elevation = CardDefaults.cardElevation(defaultElevation = 2.dp)
                    ) {
                        Column(modifier = Modifier.padding(16.dp)) {
                            if (q.isPreviousYear) {
                                Surface(
                                    shape = RoundedCornerShape(4.dp),
                                    color = AmberContainer,
                                    modifier = Modifier.padding(bottom = 8.dp)
                                ) {
                                    Text(
                                        text = "★ बिहार बोर्ड विगत वर्ष प्रश्न (BSEB ${q.examYear})",
                                        modifier = Modifier.padding(horizontal = 6.dp, vertical = 2.dp),
                                        style = MaterialTheme.typography.labelSmall.copy(
                                            color = AmberAccent,
                                            fontWeight = FontWeight.Bold
                                        )
                                    )
                                }
                            }

                            Text(
                                text = q.questionText,
                                style = MaterialTheme.typography.titleMedium.copy(
                                    fontWeight = FontWeight.Bold,
                                    color = RoyalBlueDark,
                                    lineHeight = 24.sp
                                )
                            )
                        }
                    }
                }

                // Options
                val options = listOf(
                    1 to q.optionA,
                    2 to q.optionB,
                    3 to q.optionC,
                    4 to q.optionD
                )

                items(options.size) { optIdx ->
                    val (optNum, optText) = options[optIdx]
                    val isSelected = selectedOption == optNum
                    val isCorrect = optNum == q.correctOption

                    val cardColor = when {
                        !isSubmitted -> if (isSelected) RoyalBlueContainer else MaterialTheme.colorScheme.surface
                        isCorrect -> EmeraldContainer
                        isSelected -> Color(0xFFFFE4E6)
                        else -> MaterialTheme.colorScheme.surface
                    }

                    val borderColor = when {
                        !isSubmitted -> if (isSelected) RoyalBluePrimary else OutlineLight
                        isCorrect -> EmeraldAccent
                        isSelected -> Color(0xFFE11D48)
                        else -> OutlineLight
                    }

                    Surface(
                        modifier = Modifier
                            .fillMaxWidth()
                            .clickable(enabled = !isSubmitted) { selectedOption = optNum }
                            .testTag("quiz_option_$optNum"),
                        shape = RoundedCornerShape(12.dp),
                        color = cardColor,
                        border = BorderStroke(1.5.dp, borderColor)
                    ) {
                        Row(
                            modifier = Modifier.padding(14.dp),
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Box(
                                modifier = Modifier
                                    .size(32.dp)
                                    .clip(CircleShape)
                                    .background(
                                        when {
                                            !isSubmitted -> if (isSelected) RoyalBluePrimary else SurfaceVariantLight
                                            isCorrect -> EmeraldAccent
                                            isSelected -> Color(0xFFE11D48)
                                            else -> SurfaceVariantLight
                                        }
                                    ),
                                contentAlignment = Alignment.Center
                            ) {
                                Text(
                                    text = when (optNum) {
                                        1 -> "A"
                                        2 -> "B"
                                        3 -> "C"
                                        else -> "D"
                                    },
                                    style = MaterialTheme.typography.labelMedium.copy(
                                        color = if (isSelected || (isSubmitted && isCorrect)) Color.White else TextPrimary,
                                        fontWeight = FontWeight.Bold
                                    )
                                )
                            }

                            Spacer(modifier = Modifier.width(12.dp))

                            Text(
                                text = optText,
                                style = MaterialTheme.typography.bodyMedium.copy(
                                    fontWeight = if (isSelected || (isSubmitted && isCorrect)) FontWeight.Bold else FontWeight.Normal,
                                    color = MaterialTheme.colorScheme.onSurface
                                ),
                                modifier = Modifier.weight(1f)
                            )

                            if (isSubmitted && isCorrect) {
                                Icon(
                                    imageVector = Icons.Default.CheckCircle,
                                    contentDescription = "Correct",
                                    tint = EmeraldAccent
                                )
                            } else if (isSubmitted && isSelected) {
                                Icon(
                                    imageVector = Icons.Default.Cancel,
                                    contentDescription = "Incorrect",
                                    tint = Color(0xFFE11D48)
                                )
                            }
                        }
                    }
                }

                // Explanation
                if (isSubmitted && q.explanation.isNotBlank()) {
                    item {
                        Card(
                            modifier = Modifier.fillMaxWidth(),
                            shape = RoundedCornerShape(12.dp),
                            colors = CardDefaults.cardColors(containerColor = AmberContainer.copy(alpha = 0.5f)),
                            border = BorderStroke(1.dp, AmberAccent.copy(alpha = 0.4f))
                        ) {
                            Column(modifier = Modifier.padding(12.dp)) {
                                Row(verticalAlignment = Alignment.CenterVertically) {
                                    Icon(
                                        imageVector = Icons.Default.Lightbulb,
                                        contentDescription = null,
                                        tint = AmberAccent,
                                        modifier = Modifier.size(20.dp)
                                    )
                                    Spacer(modifier = Modifier.width(6.dp))
                                    Text(
                                        text = "उत्तर की व्याख्या:",
                                        style = MaterialTheme.typography.titleSmall.copy(
                                            color = AmberAccent,
                                            fontWeight = FontWeight.Bold
                                        )
                                    )
                                }
                                Spacer(modifier = Modifier.height(4.dp))
                                Text(
                                    text = q.explanation,
                                    style = MaterialTheme.typography.bodyMedium.copy(color = RoyalBlueDark)
                                )
                            }
                        }
                    }
                }

                // Action Buttons (Submit / Next)
                item {
                    Spacer(modifier = Modifier.height(10.dp))
                    if (!isSubmitted) {
                        Button(
                            onClick = {
                                if (selectedOption != null) {
                                    isSubmitted = true
                                    if (selectedOption == q.correctOption) {
                                        score++
                                    }
                                }
                            },
                            enabled = selectedOption != null,
                            modifier = Modifier
                                .fillMaxWidth()
                                .height(50.dp)
                                .testTag("quiz_submit_btn"),
                            shape = RoundedCornerShape(12.dp),
                            colors = ButtonDefaults.buttonColors(containerColor = RoyalBluePrimary)
                        ) {
                            Text("उत्तर जमा करें (Submit Answer)", fontWeight = FontWeight.Bold, fontSize = 15.sp)
                        }
                    } else {
                        Button(
                            onClick = {
                                if (currentIndex + 1 < questions.size) {
                                    currentIndex++
                                    selectedOption = null
                                    isSubmitted = false
                                } else {
                                    isCompleted = true
                                }
                            },
                            modifier = Modifier
                                .fillMaxWidth()
                                .height(50.dp)
                                .testTag("quiz_next_btn"),
                            shape = RoundedCornerShape(12.dp),
                            colors = ButtonDefaults.buttonColors(containerColor = EmeraldAccent)
                        ) {
                            Text(
                                text = if (currentIndex + 1 < questions.size) "अगला प्रश्न (Next Question) ➔" else "परिणाम देखें (View Result) 🏆",
                                fontWeight = FontWeight.Bold,
                                fontSize = 15.sp
                            )
                        }
                    }
                }
            }
        }
    }
}
