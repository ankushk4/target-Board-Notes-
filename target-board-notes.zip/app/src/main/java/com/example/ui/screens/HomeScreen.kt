package com.example.ui.screens

import androidx.compose.animation.*
import androidx.compose.foundation.*
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material.icons.outlined.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.R
import com.example.data.model.*
import com.example.ui.components.*
import com.example.ui.navigation.Screen
import com.example.ui.theme.*
import com.example.ui.viewmodel.MainViewModel

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun HomeScreen(
    viewModel: MainViewModel,
    onNavigate: (Screen) -> Unit
) {
    val selectedCourseId by viewModel.selectedCourseId.collectAsState()
    val searchQuery by viewModel.searchQuery.collectAsState()
    val searchResults by viewModel.searchResults.collectAsState()
    val announcements by viewModel.currentAnnouncements.collectAsState()
    val bookmarks by viewModel.currentBookmarks.collectAsState()
    val subjects by viewModel.currentSubjects.collectAsState()
    val chapters by viewModel.currentChapters.collectAsState()

    val currentCourse = viewModel.repository.getCourseById(selectedCourseId) ?: viewModel.repository.getAllCourses().first()
    val bookmarkedIds = remember(bookmarks) { bookmarks.map { it.chapterId }.toSet() }

    val appLanguage by viewModel.appLanguage.collectAsState()
    val isSyncing by viewModel.isSyncing.collectAsState()
    var showChangeCourseConfirm by remember { mutableStateOf(false) }
    var showLanguageDialog by remember { mutableStateOf(false) }

    Scaffold(
        topBar = {
            TargetBoardTopBar(
                title = "TARGET BOARD NOTES",
                subtitle = if (appLanguage == "en") "${currentCourse.title} • 2026–2027" else "${currentCourse.hindiTitle} • सत्र 2026–2027",
                actions = {
                    // Quick Language Switcher Pill
                    TextButton(
                        onClick = { showLanguageDialog = true },
                        modifier = Modifier.testTag("home_language_toggle_btn")
                    ) {
                        Surface(
                            shape = RoundedCornerShape(12.dp),
                            color = Color.White.copy(alpha = 0.2f),
                            border = BorderStroke(1.dp, Color.White.copy(alpha = 0.6f))
                        ) {
                            Row(
                                modifier = Modifier.padding(horizontal = 8.dp, vertical = 4.dp),
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                Icon(
                                    imageVector = Icons.Default.Translate,
                                    contentDescription = "भाषा / Language",
                                    tint = Color.White,
                                    modifier = Modifier.size(14.dp)
                                )
                                Spacer(modifier = Modifier.width(4.dp))
                                Text(
                                    text = if (appLanguage == "en") "ENG" else "हिंदी",
                                    color = Color.White,
                                    fontWeight = FontWeight.Bold,
                                    fontSize = 11.sp
                                )
                            }
                        }
                    }

                    // Quick Course Switcher Button
                    TextButton(
                        onClick = { showChangeCourseConfirm = true },
                        modifier = Modifier.testTag("home_change_course_btn")
                    ) {
                        Surface(
                            shape = RoundedCornerShape(12.dp),
                            color = BiharBoardGold.copy(alpha = 0.2f),
                            border = BorderStroke(1.dp, BiharBoardGold)
                        ) {
                            Row(
                                modifier = Modifier.padding(horizontal = 8.dp, vertical = 4.dp),
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                Icon(
                                    imageVector = Icons.Default.SwapHoriz,
                                    contentDescription = null,
                                    tint = BiharBoardGold,
                                    modifier = Modifier.size(16.dp)
                                )
                                Spacer(modifier = Modifier.width(4.dp))
                                Text(
                                    text = "कोर्स बदलें",
                                    color = Color.White,
                                    fontWeight = FontWeight.Bold,
                                    fontSize = 11.sp
                                )
                            }
                        }
                    }

                    IconButton(
                        onClick = { onNavigate(Screen.Bookmarks) },
                        modifier = Modifier.testTag("home_bookmarks_button")
                    ) {
                        BadgedBox(
                            badge = {
                                if (bookmarks.isNotEmpty()) {
                                    Badge(containerColor = BiharBoardGold) {
                                        Text("${bookmarks.size}", color = RoyalBlueDark)
                                    }
                                }
                            }
                        ) {
                            Icon(
                                imageVector = Icons.Default.Bookmark,
                                contentDescription = "बुकमार्क",
                                tint = Color.White
                            )
                        }
                    }
                }
            )
        },
        bottomBar = {
            TargetBoardBottomBar(
                currentRoute = Screen.Home.route,
                onNavigate = onNavigate
            )
        }
    ) { innerPadding ->
        LazyColumn(
            modifier = Modifier
                .fillMaxSize()
                .padding(innerPadding)
                .background(MaterialTheme.colorScheme.background)
        ) {
            // 1. Branding Hero Header with Official Uploaded Logo
            item {
                Box(
                    modifier = Modifier
                        .fillMaxWidth()
                        .background(
                            Brush.verticalGradient(
                                colors = listOf(RoyalBluePrimary, RoyalBlueLight)
                            )
                        )
                        .padding(horizontal = 16.dp, vertical = 16.dp)
                ) {
                    Column {
                        Row(
                            verticalAlignment = Alignment.CenterVertically,
                            modifier = Modifier.fillMaxWidth()
                        ) {
                            // Official Uploaded Logo
                            Image(
                                painter = painterResource(id = R.drawable.ic_target_board_logo),
                                contentDescription = "Target Board Notes Official Logo",
                                modifier = Modifier
                                    .size(68.dp)
                                    .clip(CircleShape)
                                    .background(Color.White)
                                    .padding(2.dp),
                                contentScale = ContentScale.Fit
                            )

                            Spacer(modifier = Modifier.width(14.dp))

                            Column(modifier = Modifier.weight(1f)) {
                                Surface(
                                    shape = RoundedCornerShape(20.dp),
                                    color = BiharBoardGold.copy(alpha = 0.25f),
                                    border = BorderStroke(1.dp, BiharBoardGold)
                                ) {
                                    Text(
                                        text = "★ BIHAR BOARD 2026–2027 ★",
                                        modifier = Modifier.padding(horizontal = 8.dp, vertical = 2.dp),
                                        style = MaterialTheme.typography.labelSmall.copy(
                                            color = Color.White,
                                            fontWeight = FontWeight.Bold,
                                            fontSize = 9.sp
                                        )
                                    )
                                }
                                Spacer(modifier = Modifier.height(4.dp))
                                Text(
                                    text = currentCourse.hindiTitle,
                                    style = MaterialTheme.typography.titleMedium.copy(
                                        color = Color.White,
                                        fontWeight = FontWeight.Bold
                                    )
                                )
                                Text(
                                    text = "Study Smart • Score High (100% FREE)",
                                    style = MaterialTheme.typography.bodySmall.copy(
                                        color = Color.White.copy(alpha = 0.9f)
                                    )
                                )
                            }
                        }

                        Spacer(modifier = Modifier.height(14.dp))

                        // Search Bar
                        OutlinedTextField(
                            value = searchQuery,
                            onValueChange = { viewModel.onSearchQueryChange(it) },
                            modifier = Modifier
                                .fillMaxWidth()
                                .testTag("home_search_bar"),
                            placeholder = {
                                Text(
                                    "${currentCourse.title} में नोट्स या प्रश्न खोजें...",
                                    style = MaterialTheme.typography.bodyMedium.copy(color = TextMuted)
                                )
                            },
                            leadingIcon = {
                                Icon(
                                    imageVector = Icons.Default.Search,
                                    contentDescription = "Search",
                                    tint = RoyalBluePrimary
                                )
                            },
                            trailingIcon = {
                                if (searchQuery.isNotEmpty()) {
                                    IconButton(onClick = { viewModel.onSearchQueryChange("") }) {
                                        Icon(
                                            imageVector = Icons.Default.Close,
                                            contentDescription = "Clear",
                                            tint = TextMuted
                                        )
                                    }
                                }
                            },
                            shape = RoundedCornerShape(12.dp),
                            colors = OutlinedTextFieldDefaults.colors(
                                focusedContainerColor = Color.White,
                                unfocusedContainerColor = Color.White,
                                focusedBorderColor = BiharBoardGold,
                                unfocusedBorderColor = Color.White
                            ),
                            singleLine = true
                        )
                    }
                }
            }

            // Search Results Dropdown
            if (searchQuery.isNotBlank()) {
                item {
                    Column(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(16.dp)
                    ) {
                        Text(
                            text = "खोज परिणाम (${searchResults.size} मिले):",
                            style = MaterialTheme.typography.titleSmall.copy(fontWeight = FontWeight.Bold)
                        )
                        Spacer(modifier = Modifier.height(8.dp))
                        if (searchResults.isEmpty()) {
                            Text(
                                text = "इस पाठ्यक्रम में कोई परिणाम नहीं मिला। कृपया दूसरा शब्द खोजें।",
                                style = MaterialTheme.typography.bodyMedium.copy(color = TextMuted)
                            )
                        } else {
                            searchResults.forEach { ch ->
                                ChapterListItem(
                                    chapter = ch,
                                    isBookmarked = bookmarkedIds.contains(ch.id),
                                    onChapterClick = { onNavigate(Screen.ChapterDetail(ch.id)) },
                                    onBookmarkClick = { viewModel.toggleBookmark(ch, bookmarkedIds.contains(ch.id)) },
                                    onDownloadClick = { viewModel.toggleDownload(ch.id, ch.isDownloaded) }
                                )
                                Spacer(modifier = Modifier.height(8.dp))
                            }
                        }
                    }
                }
            }

            // Real-Time Synchronization & Offline Status Bar
            item {
                Card(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(horizontal = 16.dp, vertical = 6.dp)
                        .testTag("home_sync_status_card"),
                    shape = RoundedCornerShape(12.dp),
                    colors = CardDefaults.cardColors(
                        containerColor = if (isSyncing) RoyalBlueContainer.copy(alpha = 0.5f) else EmeraldContainer.copy(alpha = 0.35f)
                    ),
                    border = BorderStroke(1.dp, if (isSyncing) RoyalBluePrimary.copy(alpha = 0.5f) else EmeraldAccent.copy(alpha = 0.4f))
                ) {
                    Row(
                        modifier = Modifier
                            .padding(horizontal = 12.dp, vertical = 8.dp)
                            .fillMaxWidth(),
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.SpaceBetween
                    ) {
                        Row(
                            verticalAlignment = Alignment.CenterVertically,
                            modifier = Modifier.weight(1f)
                        ) {
                            if (isSyncing) {
                                CircularProgressIndicator(
                                    modifier = Modifier.size(16.dp),
                                    strokeWidth = 2.dp,
                                    color = RoyalBluePrimary
                                )
                            } else {
                                Icon(
                                    imageVector = Icons.Default.CloudDone,
                                    contentDescription = "Synchronized",
                                    tint = EmeraldAccent,
                                    modifier = Modifier.size(18.dp)
                                )
                            }
                            Spacer(modifier = Modifier.width(8.dp))
                            Column {
                                Text(
                                    text = if (isSyncing) "सामग्री सिंक हो रही है... (Syncing)" else "सिंक्रनाइज़्ड • ऑफलाइन तैयार (Up-to-Date)",
                                    style = MaterialTheme.typography.labelMedium.copy(
                                        fontWeight = FontWeight.Bold,
                                        color = if (isSyncing) RoyalBluePrimary else EmeraldAccent,
                                        fontSize = 12.sp
                                    )
                                )
                                Text(
                                    text = "सत्र 2026–2027: नए नोट्स व टेस्ट स्वतः सुरक्षित हैं",
                                    style = MaterialTheme.typography.labelSmall.copy(
                                        color = TextSecondary,
                                        fontSize = 10.sp
                                    )
                                )
                            }
                        }

                        IconButton(
                            onClick = { viewModel.refreshSync() },
                            modifier = Modifier
                                .size(32.dp)
                                .testTag("refresh_sync_btn")
                        ) {
                            Icon(
                                imageVector = Icons.Default.Sync,
                                contentDescription = "सिंक रीफ्रेश करें",
                                tint = if (isSyncing) RoyalBluePrimary else EmeraldAccent,
                                modifier = Modifier.size(18.dp)
                            )
                        }
                    }
                }
            }

            // 2. Announcements Ticker / Card
            if (announcements.isNotEmpty()) {
                item {
                    val latest = announcements.first()
                    Card(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(horizontal = 16.dp, vertical = 10.dp),
                        shape = RoundedCornerShape(12.dp),
                        colors = CardDefaults.cardColors(
                            containerColor = AmberContainer.copy(alpha = 0.7f)
                        ),
                        border = BorderStroke(1.dp, AmberAccent.copy(alpha = 0.4f))
                    ) {
                        Row(
                            modifier = Modifier
                                .padding(12.dp)
                                .fillMaxWidth(),
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Box(
                                modifier = Modifier
                                    .size(36.dp)
                                    .clip(CircleShape)
                                    .background(AmberAccent),
                                contentAlignment = Alignment.Center
                            ) {
                                Icon(
                                    imageVector = Icons.Default.Campaign,
                                    contentDescription = "Notice",
                                    tint = Color.White,
                                    modifier = Modifier.size(20.dp)
                                )
                            }
                            Spacer(modifier = Modifier.width(10.dp))
                            Column(modifier = Modifier.weight(1f)) {
                                Row(
                                    verticalAlignment = Alignment.CenterVertically,
                                    horizontalArrangement = Arrangement.spacedBy(6.dp)
                                ) {
                                    Surface(
                                        shape = RoundedCornerShape(4.dp),
                                        color = AmberAccent
                                    ) {
                                        Text(
                                            text = latest.tag,
                                            modifier = Modifier.padding(horizontal = 4.dp, vertical = 1.dp),
                                            style = MaterialTheme.typography.labelSmall.copy(
                                                color = Color.White,
                                                fontSize = 9.sp,
                                                fontWeight = FontWeight.Bold
                                            )
                                        )
                                    }
                                    Text(
                                        text = latest.title,
                                        style = MaterialTheme.typography.titleSmall.copy(
                                            fontWeight = FontWeight.Bold,
                                            color = RoyalBlueDark
                                        ),
                                        maxLines = 1,
                                        overflow = TextOverflow.Ellipsis
                                    )
                                }
                                Text(
                                    text = latest.content,
                                    style = MaterialTheme.typography.bodySmall.copy(
                                        color = TextSecondary,
                                        fontSize = 11.sp
                                    ),
                                    maxLines = 2,
                                    overflow = TextOverflow.Ellipsis
                                )
                            }
                        }
                    }
                }
            }

            // 3. Quick Action Highlights
            item {
                SectionHeader(title = "त्वरित अध्ययन सुविधाएं (Quick Access)")

                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(horizontal = 16.dp),
                    horizontalArrangement = Arrangement.spacedBy(10.dp)
                ) {
                    // Quick Action 1: Objective Quiz
                    Card(
                        modifier = Modifier
                            .weight(1f)
                            .clickable { onNavigate(Screen.ObjectiveQuiz()) }
                            .testTag("quick_action_quiz"),
                        shape = RoundedCornerShape(12.dp),
                        colors = CardDefaults.cardColors(containerColor = EmeraldContainer),
                        elevation = CardDefaults.cardElevation(defaultElevation = 2.dp)
                    ) {
                        Column(
                            modifier = Modifier.padding(12.dp),
                            horizontalAlignment = Alignment.CenterHorizontally
                        ) {
                            Icon(
                                imageVector = Icons.Default.Checklist,
                                contentDescription = "Quiz",
                                tint = EmeraldAccent,
                                modifier = Modifier.size(32.dp)
                            )
                            Spacer(modifier = Modifier.height(6.dp))
                            Text(
                                text = "वस्तुनिष्ठ क्विज",
                                style = MaterialTheme.typography.titleSmall.copy(
                                    fontWeight = FontWeight.Bold,
                                    color = EmeraldAccent
                                )
                            )
                            Text(
                                text = "रोजाना MCQs",
                                style = MaterialTheme.typography.labelSmall.copy(
                                    color = TextSecondary,
                                    fontSize = 10.sp
                                )
                            )
                        }
                    }

                    // Quick Action 2: Mock Tests
                    Card(
                        modifier = Modifier
                            .weight(1f)
                            .clickable { onNavigate(Screen.MockTestList) }
                            .testTag("quick_action_mock_test"),
                        shape = RoundedCornerShape(12.dp),
                        colors = CardDefaults.cardColors(containerColor = RoyalBlueContainer),
                        elevation = CardDefaults.cardElevation(defaultElevation = 2.dp)
                    ) {
                        Column(
                            modifier = Modifier.padding(12.dp),
                            horizontalAlignment = Alignment.CenterHorizontally
                        ) {
                            Icon(
                                imageVector = Icons.Default.Timer,
                                contentDescription = "Mock Test",
                                tint = RoyalBluePrimary,
                                modifier = Modifier.size(32.dp)
                            )
                            Spacer(modifier = Modifier.height(6.dp))
                            Text(
                                text = "मॉक टेस्ट",
                                style = MaterialTheme.typography.titleSmall.copy(
                                    fontWeight = FontWeight.Bold,
                                    color = RoyalBluePrimary
                                )
                            )
                            Text(
                                text = "टाइमर युक्त मॉडल पेपर",
                                style = MaterialTheme.typography.labelSmall.copy(
                                    color = TextSecondary,
                                    fontSize = 10.sp
                                )
                            )
                        }
                    }

                    // Quick Action 3: PDF Notes
                    Card(
                        modifier = Modifier
                            .weight(1f)
                            .clickable { onNavigate(Screen.Notes) }
                            .testTag("quick_action_pdf_notes"),
                        shape = RoundedCornerShape(12.dp),
                        colors = CardDefaults.cardColors(containerColor = AmberContainer),
                        elevation = CardDefaults.cardElevation(defaultElevation = 2.dp)
                    ) {
                        Column(
                            modifier = Modifier.padding(12.dp),
                            horizontalAlignment = Alignment.CenterHorizontally
                        ) {
                            Icon(
                                imageVector = Icons.Default.PictureAsPdf,
                                contentDescription = "PDF Notes",
                                tint = AmberAccent,
                                modifier = Modifier.size(32.dp)
                            )
                            Spacer(modifier = Modifier.height(6.dp))
                            Text(
                                text = "PDF नोट्स",
                                style = MaterialTheme.typography.titleSmall.copy(
                                    fontWeight = FontWeight.Bold,
                                    color = AmberAccent
                                )
                            )
                            Text(
                                text = "ऑफलाइन डाउनलोड",
                                style = MaterialTheme.typography.labelSmall.copy(
                                    color = TextSecondary,
                                    fontSize = 10.sp
                                )
                            )
                        }
                    }
                }
            }

            // 4. Subjects of currently selected course
            item {
                Spacer(modifier = Modifier.height(14.dp))
                SectionHeader(
                    title = "विषय सूची (${currentCourse.hindiTitle})",
                    actionLabel = "पूरा पाठ्यक्रम",
                    onActionClick = { onNavigate(Screen.Courses) }
                )
            }

            items(subjects.take(4)) { subject ->
                Box(modifier = Modifier.padding(horizontal = 16.dp, vertical = 4.dp)) {
                    SubjectCard(
                        subject = subject,
                        onClick = { onNavigate(Screen.SubjectDetail(subject.id)) }
                    )
                }
            }

            // 5. Latest Chapters
            item {
                Spacer(modifier = Modifier.height(14.dp))
                SectionHeader(
                    title = "अध्यायवार नोट्स एवं प्रश्नोत्तरी",
                    actionLabel = "सभी देखें",
                    onActionClick = { onNavigate(Screen.Notes) }
                )
            }

            items(chapters.take(4)) { chapter ->
                Box(modifier = Modifier.padding(horizontal = 16.dp, vertical = 4.dp)) {
                    ChapterListItem(
                        chapter = chapter,
                        isBookmarked = bookmarkedIds.contains(chapter.id),
                        onChapterClick = { onNavigate(Screen.ChapterDetail(chapter.id)) },
                        onBookmarkClick = { viewModel.toggleBookmark(chapter, bookmarkedIds.contains(chapter.id)) },
                        onDownloadClick = { viewModel.toggleDownload(chapter.id, chapter.isDownloaded) }
                    )
                }
            }

            // 6. Brand Commitment Footer (Strictly No Personal Names)
            item {
                Card(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(16.dp),
                    shape = RoundedCornerShape(14.dp),
                    colors = CardDefaults.cardColors(containerColor = RoyalBluePrimary),
                    elevation = CardDefaults.cardElevation(defaultElevation = 2.dp)
                ) {
                    Row(
                        modifier = Modifier
                            .padding(16.dp)
                            .fillMaxWidth(),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Image(
                            painter = painterResource(id = R.drawable.ic_target_board_logo),
                            contentDescription = "Target Board Notes",
                            modifier = Modifier
                                .size(46.dp)
                                .clip(CircleShape)
                                .background(Color.White)
                                .padding(2.dp)
                        )
                        Spacer(modifier = Modifier.width(12.dp))
                        Column(modifier = Modifier.weight(1f)) {
                            Text(
                                text = "TARGET BOARD NOTES",
                                style = MaterialTheme.typography.titleMedium.copy(
                                    color = Color.White,
                                    fontWeight = FontWeight.Bold
                                )
                            )
                            Text(
                                text = "बिहार बोर्ड के समस्त विद्यार्थियों को 100% निःशुल्क समर्पित",
                                style = MaterialTheme.typography.bodySmall.copy(
                                    color = Color.White.copy(alpha = 0.85f),
                                    fontSize = 11.sp
                                )
                            )
                        }
                    }
                }
                Spacer(modifier = Modifier.height(16.dp))
            }
        }
    }

    // Change Course Confirmation Dialog
    if (showChangeCourseConfirm) {
        AlertDialog(
            onDismissRequest = { showChangeCourseConfirm = false },
            icon = { Icon(imageVector = Icons.Default.SwapHoriz, contentDescription = null, tint = RoyalBluePrimary) },
            title = { Text("पाठ्यक्रम (Course) बदलें?", fontWeight = FontWeight.Bold) },
            text = {
                Text("वर्तमान में आप '${currentCourse.title}' का अध्ययन कर रहे हैं। क्या आप दूसरा पाठ्यक्रम चुनना चाहते हैं?")
            },
            confirmButton = {
                Button(
                    onClick = {
                        showChangeCourseConfirm = false
                        onNavigate(Screen.CourseSelection)
                    },
                    colors = ButtonDefaults.buttonColors(containerColor = RoyalBluePrimary)
                ) {
                    Text("हाँ, कोर्स बदलें")
                }
            },
            dismissButton = {
                TextButton(onClick = { showChangeCourseConfirm = false }) {
                    Text("रद्द करें")
                }
            }
        )
    }

    // Language Selection Dialog (Hindi & English)
    if (showLanguageDialog) {
        AlertDialog(
            onDismissRequest = { showLanguageDialog = false },
            icon = { Icon(imageVector = Icons.Default.Translate, contentDescription = null, tint = RoyalBluePrimary) },
            title = { Text("अध्ययन भाषा चुनें (Select Language)", fontWeight = FontWeight.Bold) },
            text = {
                Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                    Text(
                        text = "अपनी पसंदीदा भाषा का चयन करें (Select your preferred medium):",
                        style = MaterialTheme.typography.bodySmall.copy(color = TextSecondary)
                    )
                    Spacer(modifier = Modifier.height(4.dp))

                    // Hindi option
                    Surface(
                        shape = RoundedCornerShape(10.dp),
                        color = if (appLanguage == "hi") RoyalBlueContainer else MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.5f),
                        border = if (appLanguage == "hi") BorderStroke(1.5.dp, RoyalBluePrimary) else null,
                        modifier = Modifier
                            .fillMaxWidth()
                            .clickable {
                                viewModel.setAppLanguage("hi")
                                showLanguageDialog = false
                            }
                    ) {
                        Row(
                            modifier = Modifier.padding(12.dp),
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            RadioButton(
                                selected = appLanguage == "hi",
                                onClick = {
                                    viewModel.setAppLanguage("hi")
                                    showLanguageDialog = false
                                }
                            )
                            Spacer(modifier = Modifier.width(8.dp))
                            Column {
                                Text("हिंदी (Hindi)", fontWeight = FontWeight.Bold)
                                Text("बिहार बोर्ड हिंदी माध्यम", fontSize = 11.sp, color = TextSecondary)
                            }
                        }
                    }

                    // English option
                    Surface(
                        shape = RoundedCornerShape(10.dp),
                        color = if (appLanguage == "en") RoyalBlueContainer else MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.5f),
                        border = if (appLanguage == "en") BorderStroke(1.5.dp, RoyalBluePrimary) else null,
                        modifier = Modifier
                            .fillMaxWidth()
                            .clickable {
                                viewModel.setAppLanguage("en")
                                showLanguageDialog = false
                            }
                    ) {
                        Row(
                            modifier = Modifier.padding(12.dp),
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            RadioButton(
                                selected = appLanguage == "en",
                                onClick = {
                                    viewModel.setAppLanguage("en")
                                    showLanguageDialog = false
                                }
                            )
                            Spacer(modifier = Modifier.width(8.dp))
                            Column {
                                Text("English", fontWeight = FontWeight.Bold)
                                Text("Bihar Board English Medium", fontSize = 11.sp, color = TextSecondary)
                            }
                        }
                    }
                }
            },
            confirmButton = {
                TextButton(onClick = { showLanguageDialog = false }) { Text("ठीक है") }
            }
        )
    }
}
