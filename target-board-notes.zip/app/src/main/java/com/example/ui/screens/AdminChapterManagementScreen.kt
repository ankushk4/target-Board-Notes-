package com.example.ui.screens

import android.net.Uri
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.animation.*
import androidx.compose.foundation.*
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material.icons.outlined.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.data.model.*
import com.example.ui.components.TargetBoardTopBar
import com.example.ui.navigation.Screen
import com.example.ui.theme.*
import com.example.ui.viewmodel.AdminViewModel
import com.example.ui.viewmodel.MainViewModel

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun AdminChapterManagementScreen(
    subjectId: String,
    courseId: String,
    adminViewModel: AdminViewModel,
    mainViewModel: MainViewModel,
    onNavigate: (Screen) -> Unit,
    onBack: () -> Unit
) {
    var subject by remember { mutableStateOf<Subject?>(null) }
    LaunchedEffect(subjectId) {
        subject = adminViewModel.repository.getSubjectById(subjectId)
    }

    val chaptersFlow = remember(subjectId) { adminViewModel.getChaptersBySubject(subjectId) }
    val chapters by chaptersFlow.collectAsState(initial = emptyList())

    val course = mainViewModel.repository.getCourseById(courseId)
    val operationStatus by adminViewModel.operationStatus.collectAsState()

    var selectedTab by remember { mutableStateOf(0) }
    val tabs = listOf(
        "अध्याय (${chapters.size})",
        "विस्तृत नोट्स व PDF",
        "वस्तुनिष्ठ प्रश्न (MCQ)",
        "सब्जेक्टिव प्रश्न",
        "मॉक टेस्ट"
    )

    // Chapter Dialog States
    var showAddChapterDialog by remember { mutableStateOf(false) }
    var editingChapter by remember { mutableStateOf<Chapter?>(null) }

    // Active Chapter for Notes / PDF editor
    var activeChapterIdForNotes by remember { mutableStateOf<String?>(null) }
    LaunchedEffect(chapters) {
        if (activeChapterIdForNotes == null && chapters.isNotEmpty()) {
            activeChapterIdForNotes = chapters.first().id
        }
    }
    val activeChapter = chapters.find { it.id == activeChapterIdForNotes } ?: chapters.firstOrNull()

    // MCQ Dialog States
    var showAddMcqDialog by remember { mutableStateOf(false) }
    var editingMcq by remember { mutableStateOf<ObjectiveQuestion?>(null) }
    var filterMcqChapterId by remember { mutableStateOf<String>("ALL") }

    // Subjective Dialog States
    var showAddSubDialog by remember { mutableStateOf(false) }
    var editingSub by remember { mutableStateOf<SubjectiveQuestion?>(null) }
    var filterSubChapterId by remember { mutableStateOf<String>("ALL") }

    // Mock Test Dialog States
    var showAddTestDialog by remember { mutableStateOf(false) }
    val mockTestsFlow = remember(subjectId) { adminViewModel.getMockTestsBySubject(subjectId) }
    val mockTests by mockTestsFlow.collectAsState(initial = emptyList())

    val publishedCount = remember(chapters) { chapters.count { it.isPublished } }
    val draftCount = remember(chapters) { chapters.count { !it.isPublished } }

    Scaffold(
        topBar = {
            TargetBoardTopBar(
                title = subject?.title ?: "अध्याय व सामग्री प्रबंधन",
                subtitle = "${course?.title ?: "बिहार बोर्ड"} • सामग्री प्रबंधन प्रणाली (CMS)",
                canNavigateBack = true,
                onNavigateBack = onBack,
                actions = {
                    IconButton(
                        onClick = { showAddChapterDialog = true },
                        modifier = Modifier.testTag("admin_header_add_chapter_btn")
                    ) {
                        Icon(imageVector = Icons.Default.AddCircle, contentDescription = "Add Chapter", tint = BiharBoardGold)
                    }
                }
            )
        }
    ) { innerPadding ->
        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(innerPadding)
                .background(MaterialTheme.colorScheme.background)
        ) {
            // Operation Status Snackbar/Banner
            if (operationStatus != null) {
                Surface(
                    color = EmeraldAccent.copy(alpha = 0.15f),
                    border = BorderStroke(1.dp, EmeraldAccent),
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(horizontal = 16.dp, vertical = 6.dp),
                    shape = RoundedCornerShape(8.dp)
                ) {
                    Row(
                        modifier = Modifier.padding(horizontal = 12.dp, vertical = 8.dp),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Icon(imageVector = Icons.Default.CheckCircle, contentDescription = null, tint = EmeraldAccent, modifier = Modifier.size(18.dp))
                        Spacer(modifier = Modifier.width(8.dp))
                        Text(text = operationStatus!!, style = MaterialTheme.typography.bodySmall.copy(color = EmeraldAccent, fontWeight = FontWeight.Bold), modifier = Modifier.weight(1f))
                        IconButton(onClick = { adminViewModel.clearStatus() }, modifier = Modifier.size(24.dp)) {
                            Icon(imageVector = Icons.Default.Close, contentDescription = "Dismiss", tint = EmeraldAccent, modifier = Modifier.size(16.dp))
                        }
                    }
                }
            }

            // Subject Header Card with Publish Metrics
            Card(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(horizontal = 16.dp, vertical = 8.dp),
                shape = RoundedCornerShape(12.dp),
                colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
                elevation = CardDefaults.cardElevation(defaultElevation = 2.dp)
            ) {
                Column(modifier = Modifier.padding(14.dp)) {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Column(modifier = Modifier.weight(1f)) {
                            Text(
                                text = subject?.title ?: "विषय",
                                style = MaterialTheme.typography.titleMedium.copy(fontWeight = FontWeight.Bold, color = RoyalBlueDark)
                            )
                            Text(
                                text = subject?.hindiTitle ?: "",
                                style = MaterialTheme.typography.bodySmall.copy(color = TextSecondary)
                            )
                        }
                        Surface(
                            shape = RoundedCornerShape(16.dp),
                            color = RoyalBluePrimary.copy(alpha = 0.12f)
                        ) {
                            Text(
                                text = course?.title ?: "",
                                modifier = Modifier.padding(horizontal = 10.dp, vertical = 4.dp),
                                fontSize = 11.sp,
                                fontWeight = FontWeight.Bold,
                                color = RoyalBluePrimary
                            )
                        }
                    }

                    Spacer(modifier = Modifier.height(10.dp))
                    Divider(color = OutlineLight.copy(alpha = 0.5f))
                    Spacer(modifier = Modifier.height(10.dp))

                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween
                    ) {
                        MetricPill(label = "कुल अध्याय", value = "${chapters.size}", color = RoyalBluePrimary)
                        MetricPill(label = "प्रकाशित (Live)", value = "$publishedCount", color = EmeraldAccent)
                        MetricPill(label = "ड्राफ्ट (Draft)", value = "$draftCount", color = AmberAccent)
                        MetricPill(label = "मॉक टेस्ट", value = "${mockTests.size}", color = Color(0xFF7C3AED))
                    }
                }
            }

            // Tabs Row
            ScrollableTabRow(
                selectedTabIndex = selectedTab,
                containerColor = MaterialTheme.colorScheme.surface,
                contentColor = RoyalBluePrimary,
                edgePadding = 12.dp
            ) {
                tabs.forEachIndexed { index, title ->
                    Tab(
                        selected = selectedTab == index,
                        onClick = { selectedTab = index },
                        text = {
                            Text(
                                text = title,
                                fontWeight = if (selectedTab == index) FontWeight.Bold else FontWeight.Normal,
                                fontSize = 13.sp
                            )
                        }
                    )
                }
            }

            // Tab Content
            when (selectedTab) {
                0 -> ChaptersManagementTab(
                    chapters = chapters,
                    onAddChapter = { showAddChapterDialog = true },
                    onEditChapter = { editingChapter = it },
                    onTogglePublish = { chapterId, newStatus ->
                        adminViewModel.togglePublishChapter(chapterId, newStatus)
                    },
                    onDeleteChapter = { chapterId ->
                        adminViewModel.deleteChapter(chapterId)
                    },
                    onOpenNotes = { chapterId ->
                        activeChapterIdForNotes = chapterId
                        selectedTab = 1
                    },
                    onOpenMcqs = { chapterId ->
                        filterMcqChapterId = chapterId
                        selectedTab = 2
                    }
                )

                1 -> NotesAndPdfTab(
                    chapters = chapters,
                    activeChapter = activeChapter,
                    onSelectChapter = { activeChapterIdForNotes = it },
                    onSaveNotes = { chId, explanation, authorIntro, authorLifeHistory, importantPoints, definitions ->
                        val current = chapters.find { it.id == chId }
                        if (current != null) {
                            val updated = current.copy(
                                explanation = explanation,
                                authorIntro = authorIntro,
                                authorLifeHistory = authorLifeHistory,
                                importantPoints = importantPoints.lines().filter { it.isNotBlank() },
                                definitions = definitions.lines().filter { it.isNotBlank() }
                            )
                            adminViewModel.updateChapter(updated)
                        }
                    },
                    onSavePdf = { chId, pdfUrl, pageCount ->
                        val current = chapters.find { it.id == chId }
                        if (current != null) {
                            adminViewModel.updateChapterNotesAndPdf(
                                chapterId = chId,
                                notesHindi = current.explanation,
                                pdfUrl = pdfUrl,
                                pageCount = pageCount
                            )
                        }
                    }
                )

                2 -> ObjectiveQuestionsTab(
                    subjectId = subjectId,
                    courseId = courseId,
                    chapters = chapters,
                    filterChapterId = filterMcqChapterId,
                    onFilterChange = { filterMcqChapterId = it },
                    adminViewModel = adminViewModel,
                    onAddQuestion = { showAddMcqDialog = true },
                    onEditQuestion = { editingMcq = it },
                    onDeleteQuestion = { adminViewModel.deleteObjectiveQuestion(it) }
                )

                3 -> SubjectiveQuestionsTab(
                    subjectId = subjectId,
                    courseId = courseId,
                    chapters = chapters,
                    filterChapterId = filterSubChapterId,
                    onFilterChange = { filterSubChapterId = it },
                    adminViewModel = adminViewModel,
                    onAddQuestion = { showAddSubDialog = true },
                    onEditQuestion = { editingSub = it },
                    onDeleteQuestion = { adminViewModel.deleteSubjectiveQuestion(it) }
                )

                4 -> MockTestsTab(
                    subjectId = subjectId,
                    courseId = courseId,
                    chapters = chapters,
                    mockTests = mockTests,
                    onCreateTest = { showAddTestDialog = true },
                    onTogglePublish = { testId, newStatus ->
                        adminViewModel.togglePublishMockTest(testId, newStatus)
                    },
                    onDeleteTest = { adminViewModel.deleteMockTest(it) }
                )
            }
        }
    }

    // --- Dialogs ---

    // Add / Edit Chapter Dialog
    if (showAddChapterDialog || editingChapter != null) {
        val isEditing = editingChapter != null
        ChapterFormDialog(
            subjectId = subjectId,
            courseId = courseId,
            initialChapter = editingChapter,
            nextChapterNumber = (chapters.maxOfOrNull { it.chapterNumber } ?: 0) + 1,
            onDismiss = {
                showAddChapterDialog = false
                editingChapter = null
            },
            onSave = { chNumber, title, hindiTitle, authorName, authorIntro, authorLifeHistory, explanation, importantPoints, definitions, pdfUrl, isPublished ->
                adminViewModel.saveChapter(
                    id = editingChapter?.id,
                    subjectId = subjectId,
                    courseId = courseId,
                    chapterNumber = chNumber,
                    title = title,
                    hindiTitle = hindiTitle,
                    authorName = authorName,
                    authorIntro = authorIntro,
                    authorLifeHistory = authorLifeHistory,
                    explanation = explanation,
                    importantPoints = importantPoints.lines().filter { it.isNotBlank() },
                    definitions = definitions.lines().filter { it.isNotBlank() },
                    pdfUrl = pdfUrl,
                    pageCount = 12,
                    isPublished = isPublished
                )
                showAddChapterDialog = false
                editingChapter = null
            }
        )
    }

    // Add / Edit MCQ Dialog
    if (showAddMcqDialog || editingMcq != null) {
        McqFormDialog(
            subjectId = subjectId,
            courseId = courseId,
            chapters = chapters,
            initialQuestion = editingMcq,
            defaultChapterId = if (filterMcqChapterId != "ALL") filterMcqChapterId else chapters.firstOrNull()?.id ?: "",
            onDismiss = {
                showAddMcqDialog = false
                editingMcq = null
            },
            onSave = { id, chId, qText, opA, opB, opC, opD, correctOp, exp, marks, diff, isPyq, year ->
                adminViewModel.saveObjectiveQuestion(
                    id = id,
                    chapterId = chId,
                    subjectId = subjectId,
                    courseId = courseId,
                    questionText = qText,
                    optionA = opA,
                    optionB = opB,
                    optionC = opC,
                    optionD = opD,
                    correctOption = correctOp,
                    explanation = exp,
                    marks = marks,
                    difficulty = diff,
                    isPreviousYear = isPyq,
                    examYear = year
                )
                showAddMcqDialog = false
                editingMcq = null
            }
        )
    }

    // Add / Edit Subjective Question Dialog
    if (showAddSubDialog || editingSub != null) {
        SubjectiveFormDialog(
            subjectId = subjectId,
            courseId = courseId,
            chapters = chapters,
            initialQuestion = editingSub,
            defaultChapterId = if (filterSubChapterId != "ALL") filterSubChapterId else chapters.firstOrNull()?.id ?: "",
            onDismiss = {
                showAddSubDialog = false
                editingSub = null
            },
            onSave = { id, chId, qText, ansText, marks, qType, isImp, isPyq, year ->
                adminViewModel.saveSubjectiveQuestion(
                    id = id,
                    chapterId = chId,
                    subjectId = subjectId,
                    courseId = courseId,
                    questionText = qText,
                    answerText = ansText,
                    marks = marks,
                    questionType = qType,
                    isImportant = isImp,
                    isPreviousYear = isPyq,
                    examYear = year
                )
                showAddSubDialog = false
                editingSub = null
            }
        )
    }

    // Create Mock Test Dialog
    if (showAddTestDialog) {
        MockTestFormDialog(
            subjectId = subjectId,
            courseId = courseId,
            chapters = chapters,
            onDismiss = { showAddTestDialog = false },
            onSave = { chId, title, desc, duration, totalMarks, totalQuestions, passMarks, isPublished ->
                adminViewModel.saveMockTest(
                    id = null,
                    courseId = courseId,
                    subjectId = subjectId,
                    chapterId = chId,
                    title = title,
                    description = desc,
                    durationMinutes = duration,
                    totalMarks = totalMarks,
                    totalQuestions = totalQuestions,
                    passMarks = passMarks,
                    isPublished = isPublished
                )
                showAddTestDialog = false
            }
        )
    }
}

// -------------------------------------------------------------------------
// Sub-Tab 0: Chapters Management
// -------------------------------------------------------------------------
@Composable
fun ChaptersManagementTab(
    chapters: List<Chapter>,
    onAddChapter: () -> Unit,
    onEditChapter: (Chapter) -> Unit,
    onTogglePublish: (chapterId: String, newStatus: Boolean) -> Unit,
    onDeleteChapter: (chapterId: String) -> Unit,
    onOpenNotes: (chapterId: String) -> Unit,
    onOpenMcqs: (chapterId: String) -> Unit
) {
    LazyColumn(
        modifier = Modifier
            .fillMaxSize()
            .padding(16.dp),
        verticalArrangement = Arrangement.spacedBy(12.dp)
    ) {
        item {
            Button(
                onClick = onAddChapter,
                modifier = Modifier
                    .fillMaxWidth()
                    .height(48.dp)
                    .testTag("admin_add_chapter_action_btn"),
                shape = RoundedCornerShape(10.dp),
                colors = ButtonDefaults.buttonColors(containerColor = RoyalBluePrimary)
            ) {
                Icon(imageVector = Icons.Default.Add, contentDescription = null)
                Spacer(modifier = Modifier.width(8.dp))
                Text("नया अध्याय जोड़ें (Add New Chapter)", fontWeight = FontWeight.Bold)
            }
        }

        if (chapters.isEmpty()) {
            item {
                Card(
                    modifier = Modifier.fillMaxWidth(),
                    shape = RoundedCornerShape(12.dp),
                    colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface)
                ) {
                    Column(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(24.dp),
                        horizontalAlignment = Alignment.CenterHorizontally
                    ) {
                        Icon(imageVector = Icons.Outlined.FolderOff, contentDescription = null, tint = TextMuted, modifier = Modifier.size(48.dp))
                        Spacer(modifier = Modifier.height(8.dp))
                        Text(text = "इस विषय में अभी कोई अध्याय नहीं है", style = MaterialTheme.typography.titleSmall.copy(fontWeight = FontWeight.Bold))
                        Text(text = "ऊपर दिए गए बटन से नया अध्याय व नोट्स जोड़ें।", style = MaterialTheme.typography.bodySmall.copy(color = TextSecondary))
                    }
                }
            }
        } else {
            items(chapters) { chapter ->
                Card(
                    modifier = Modifier
                        .fillMaxWidth()
                        .testTag("chapter_admin_card_${chapter.id}"),
                    shape = RoundedCornerShape(12.dp),
                    colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
                    elevation = CardDefaults.cardElevation(defaultElevation = 2.dp)
                ) {
                    Column(modifier = Modifier.padding(14.dp)) {
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Box(
                                modifier = Modifier
                                    .size(36.dp)
                                    .clip(CircleShape)
                                    .background(RoyalBluePrimary),
                                contentAlignment = Alignment.Center
                            ) {
                                Text(
                                    text = "${chapter.chapterNumber}",
                                    color = Color.White,
                                    fontWeight = FontWeight.Bold,
                                    fontSize = 14.sp
                                )
                            }
                            Spacer(modifier = Modifier.width(10.dp))
                            Column(modifier = Modifier.weight(1f)) {
                                Text(
                                    text = chapter.title,
                                    style = MaterialTheme.typography.titleSmall.copy(fontWeight = FontWeight.Bold),
                                    maxLines = 1,
                                    overflow = TextOverflow.Ellipsis
                                )
                                Text(
                                    text = chapter.hindiTitle,
                                    style = MaterialTheme.typography.bodySmall.copy(color = TextSecondary),
                                    maxLines = 1,
                                    overflow = TextOverflow.Ellipsis
                                )
                            }
                            IconButton(onClick = { onEditChapter(chapter) }) {
                                Icon(imageVector = Icons.Default.Edit, contentDescription = "Edit Chapter", tint = RoyalBluePrimary)
                            }
                            IconButton(onClick = { onDeleteChapter(chapter.id) }) {
                                Icon(imageVector = Icons.Default.Delete, contentDescription = "Delete Chapter", tint = Color(0xFFE11D48))
                            }
                        }

                        if (chapter.authorName.isNotBlank()) {
                            Spacer(modifier = Modifier.height(4.dp))
                            Text(
                                text = "लेखक: ${chapter.authorName}",
                                style = MaterialTheme.typography.bodySmall.copy(color = RoyalBlueDark, fontWeight = FontWeight.Medium)
                            )
                        }

                        Spacer(modifier = Modifier.height(8.dp))
                        Divider(color = OutlineLight.copy(alpha = 0.5f))
                        Spacer(modifier = Modifier.height(8.dp))

                        // Status & Actions Row
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            verticalAlignment = Alignment.CenterVertically,
                            horizontalArrangement = Arrangement.SpaceBetween
                        ) {
                            // Publish Toggle Switch
                            Row(verticalAlignment = Alignment.CenterVertically) {
                                Surface(
                                    shape = RoundedCornerShape(6.dp),
                                    color = if (chapter.isPublished) EmeraldAccent.copy(alpha = 0.15f) else AmberAccent.copy(alpha = 0.15f)
                                ) {
                                    Text(
                                        text = if (chapter.isPublished) "प्रकाशित (Live)" else "ड्राफ्ट (Draft)",
                                        color = if (chapter.isPublished) EmeraldAccent else AmberAccent,
                                        fontSize = 11.sp,
                                        fontWeight = FontWeight.Bold,
                                        modifier = Modifier.padding(horizontal = 8.dp, vertical = 2.dp)
                                    )
                                }
                                Spacer(modifier = Modifier.width(8.dp))
                                Switch(
                                    checked = chapter.isPublished,
                                    onCheckedChange = { onTogglePublish(chapter.id, it) },
                                    modifier = Modifier.testTag("publish_switch_${chapter.id}")
                                )
                            }

                            // Quick jumps
                            Row {
                                TextButton(onClick = { onOpenNotes(chapter.id) }) {
                                    Icon(imageVector = Icons.Default.Article, contentDescription = null, modifier = Modifier.size(16.dp))
                                    Spacer(modifier = Modifier.width(4.dp))
                                    Text("नोट्स", fontSize = 12.sp)
                                }
                                TextButton(onClick = { onOpenMcqs(chapter.id) }) {
                                    Icon(imageVector = Icons.Default.Quiz, contentDescription = null, modifier = Modifier.size(16.dp))
                                    Spacer(modifier = Modifier.width(4.dp))
                                    Text("MCQ", fontSize = 12.sp)
                                }
                            }
                        }
                    }
                }
            }
        }
    }
}

// -------------------------------------------------------------------------
// Sub-Tab 1: Hindi Notes & PDF Upload Tab
// -------------------------------------------------------------------------
@Composable
fun NotesAndPdfTab(
    chapters: List<Chapter>,
    activeChapter: Chapter?,
    onSelectChapter: (String) -> Unit,
    onSaveNotes: (chId: String, explanation: String, authorIntro: String, authorLifeHistory: String, importantPoints: String, definitions: String) -> Unit,
    onSavePdf: (chId: String, pdfUrl: String, pageCount: Int) -> Unit
) {
    if (chapters.isEmpty()) {
        Box(modifier = Modifier.fillMaxSize().padding(24.dp), contentAlignment = Alignment.Center) {
            Text("कृपया पहले 'अध्याय' टैब में जाकर कम से कम एक अध्याय जोड़ें।", color = TextSecondary)
        }
        return
    }

    val current = activeChapter ?: chapters.first()

    var explanation by remember(current.id) { mutableStateOf(current.explanation) }
    var authorIntro by remember(current.id) { mutableStateOf(current.authorIntro) }
    var authorLifeHistory by remember(current.id) { mutableStateOf(current.authorLifeHistory) }
    var importantPoints by remember(current.id) { mutableStateOf(current.importantPoints.joinToString("\n")) }
    var definitions by remember(current.id) { mutableStateOf(current.definitions.joinToString("\n")) }

    var pdfUrl by remember(current.id) { mutableStateOf(current.pdfUrl) }
    var pageCountText by remember(current.id) { mutableStateOf(current.pageCount.toString()) }

    // Real PDF File Picker Launcher
    val pdfPickerLauncher = rememberLauncherForActivityResult(
        contract = ActivityResultContracts.GetContent()
    ) { uri: Uri? ->
        if (uri != null) {
            pdfUrl = uri.toString()
        }
    }

    LazyColumn(
        modifier = Modifier
            .fillMaxSize()
            .padding(16.dp),
        verticalArrangement = Arrangement.spacedBy(14.dp)
    ) {
        // Chapter Selector Dropdown / Scroll Row
        item {
            Text(text = "अध्याय चुनें (Select Chapter):", style = MaterialTheme.typography.titleSmall.copy(fontWeight = FontWeight.Bold))
            Spacer(modifier = Modifier.height(6.dp))
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .horizontalScroll(rememberScrollState()),
                horizontalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                chapters.forEach { ch ->
                    FilterChip(
                        selected = ch.id == current.id,
                        onClick = { onSelectChapter(ch.id) },
                        label = { Text("पाठ ${ch.chapterNumber}: ${ch.title}", fontSize = 12.sp) },
                        colors = FilterChipDefaults.filterChipColors(
                            selectedContainerColor = RoyalBluePrimary,
                            selectedLabelColor = Color.White
                        )
                    )
                }
            }
        }

        // Section A: PDF Upload & Attachment
        item {
            Card(
                modifier = Modifier.fillMaxWidth(),
                shape = RoundedCornerShape(12.dp),
                colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
                elevation = CardDefaults.cardElevation(defaultElevation = 2.dp)
            ) {
                Column(modifier = Modifier.padding(16.dp)) {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Icon(imageVector = Icons.Default.PictureAsPdf, contentDescription = null, tint = Color(0xFFDC2626))
                        Spacer(modifier = Modifier.width(8.dp))
                        Text(
                            text = "PDF नोट्स अपलोड व लिंक (PDF Management)",
                            style = MaterialTheme.typography.titleSmall.copy(fontWeight = FontWeight.Bold)
                        )
                    }

                    Spacer(modifier = Modifier.height(10.dp))

                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.spacedBy(8.dp)
                    ) {
                        Button(
                            onClick = { pdfPickerLauncher.launch("application/pdf") },
                            modifier = Modifier.weight(1f),
                            shape = RoundedCornerShape(8.dp),
                            colors = ButtonDefaults.buttonColors(containerColor = EmeraldAccent)
                        ) {
                            Icon(imageVector = Icons.Default.FileUpload, contentDescription = null)
                            Spacer(modifier = Modifier.width(6.dp))
                            Text("डिवाइस से PDF चुनें", fontSize = 12.sp)
                        }
                    }

                    Spacer(modifier = Modifier.height(10.dp))

                    OutlinedTextField(
                        value = pdfUrl,
                        onValueChange = { pdfUrl = it },
                        label = { Text("PDF URL या डिवाइस पाथ") },
                        modifier = Modifier.fillMaxWidth(),
                        singleLine = true,
                        shape = RoundedCornerShape(8.dp)
                    )

                    Spacer(modifier = Modifier.height(8.dp))

                    OutlinedTextField(
                        value = pageCountText,
                        onValueChange = { pageCountText = it },
                        label = { Text("कुल पृष्ठ संख्या (Pages)") },
                        modifier = Modifier.fillMaxWidth(),
                        singleLine = true,
                        shape = RoundedCornerShape(8.dp)
                    )

                    Spacer(modifier = Modifier.height(12.dp))

                    Button(
                        onClick = {
                            val pages = pageCountText.toIntOrNull() ?: 10
                            onSavePdf(current.id, pdfUrl, pages)
                        },
                        modifier = Modifier
                            .fillMaxWidth()
                            .height(44.dp)
                            .testTag("save_pdf_btn"),
                        shape = RoundedCornerShape(8.dp),
                        colors = ButtonDefaults.buttonColors(containerColor = RoyalBluePrimary)
                    ) {
                        Icon(imageVector = Icons.Default.Save, contentDescription = null)
                        Spacer(modifier = Modifier.width(6.dp))
                        Text("PDF नोट्स स्थायी रूप से सहेजें (Save PDF)")
                    }
                }
            }
        }

        // Section B: Detailed Hindi Notes
        item {
            Card(
                modifier = Modifier.fillMaxWidth(),
                shape = RoundedCornerShape(12.dp),
                colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
                elevation = CardDefaults.cardElevation(defaultElevation = 2.dp)
            ) {
                Column(modifier = Modifier.padding(16.dp)) {
                    Text(
                        text = "विस्तृत हिंदी नोट्स (Detailed Hindi Notes) - पाठ ${current.chapterNumber}",
                        style = MaterialTheme.typography.titleSmall.copy(fontWeight = FontWeight.Bold, color = RoyalBlueDark)
                    )

                    Spacer(modifier = Modifier.height(12.dp))

                    OutlinedTextField(
                        value = authorIntro,
                        onValueChange = { authorIntro = it },
                        label = { Text("लेखक परिचय") },
                        modifier = Modifier.fillMaxWidth(),
                        minLines = 2,
                        shape = RoundedCornerShape(8.dp)
                    )

                    Spacer(modifier = Modifier.height(8.dp))

                    OutlinedTextField(
                        value = authorLifeHistory,
                        onValueChange = { authorLifeHistory = it },
                        label = { Text("लेखक का जीवन परिचय व प्रमुख रचनाएँ") },
                        modifier = Modifier.fillMaxWidth(),
                        minLines = 2,
                        shape = RoundedCornerShape(8.dp)
                    )

                    Spacer(modifier = Modifier.height(8.dp))

                    OutlinedTextField(
                        value = explanation,
                        onValueChange = { explanation = it },
                        label = { Text("अध्याय व्याख्या व मुख्य सारांश (Hindi Explanation)") },
                        modifier = Modifier.fillMaxWidth(),
                        minLines = 4,
                        shape = RoundedCornerShape(8.dp)
                    )

                    Spacer(modifier = Modifier.height(8.dp))

                    OutlinedTextField(
                        value = importantPoints,
                        onValueChange = { importantPoints = it },
                        label = { Text("महत्वपूर्ण बिंदु (Important Points - प्रत्येक पंक्ति में एक)") },
                        modifier = Modifier.fillMaxWidth(),
                        minLines = 3,
                        shape = RoundedCornerShape(8.dp)
                    )

                    Spacer(modifier = Modifier.height(8.dp))

                    OutlinedTextField(
                        value = definitions,
                        onValueChange = { definitions = it },
                        label = { Text("महत्वपूर्ण परिभाषाएं (Definitions - प्रत्येक पंक्ति में एक)") },
                        modifier = Modifier.fillMaxWidth(),
                        minLines = 2,
                        shape = RoundedCornerShape(8.dp)
                    )

                    Spacer(modifier = Modifier.height(14.dp))

                    Button(
                        onClick = {
                            onSaveNotes(current.id, explanation, authorIntro, authorLifeHistory, importantPoints, definitions)
                        },
                        modifier = Modifier
                            .fillMaxWidth()
                            .height(46.dp)
                            .testTag("save_notes_btn"),
                        shape = RoundedCornerShape(8.dp),
                        colors = ButtonDefaults.buttonColors(containerColor = RoyalBluePrimary)
                    ) {
                        Icon(imageVector = Icons.Default.Save, contentDescription = null)
                        Spacer(modifier = Modifier.width(8.dp))
                        Text("हिंदी नोट्स स्थायी रूप से डेटाबेस में सहेजें", fontWeight = FontWeight.Bold)
                    }
                }
            }
        }
    }
}

// -------------------------------------------------------------------------
// Sub-Tab 2: Objective Questions (MCQ Bank)
// -------------------------------------------------------------------------
@Composable
fun ObjectiveQuestionsTab(
    subjectId: String,
    courseId: String,
    chapters: List<Chapter>,
    filterChapterId: String,
    onFilterChange: (String) -> Unit,
    adminViewModel: AdminViewModel,
    onAddQuestion: () -> Unit,
    onEditQuestion: (ObjectiveQuestion) -> Unit,
    onDeleteQuestion: (ObjectiveQuestion) -> Unit
) {
    // When chapter filter is "ALL", fetch all subject questions or filter by chapter
    val questionsFlow = remember(filterChapterId, subjectId) {
        if (filterChapterId != "ALL") {
            adminViewModel.getObjectiveQuestionsByChapter(filterChapterId)
        } else {
            adminViewModel.repository.getObjectiveQuestionsByCourse(courseId)
        }
    }
    val allQuestions by questionsFlow.collectAsState(initial = emptyList())
    val questions = remember(allQuestions, filterChapterId, subjectId) {
        if (filterChapterId != "ALL") {
            allQuestions.filter { it.chapterId == filterChapterId }
        } else {
            allQuestions.filter { it.subjectId == subjectId }
        }
    }

    LazyColumn(
        modifier = Modifier
            .fillMaxSize()
            .padding(16.dp),
        verticalArrangement = Arrangement.spacedBy(10.dp)
    ) {
        item {
            Button(
                onClick = onAddQuestion,
                modifier = Modifier
                    .fillMaxWidth()
                    .height(48.dp)
                    .testTag("admin_add_mcq_btn"),
                shape = RoundedCornerShape(10.dp),
                colors = ButtonDefaults.buttonColors(containerColor = RoyalBluePrimary)
            ) {
                Icon(imageVector = Icons.Default.Add, contentDescription = null)
                Spacer(modifier = Modifier.width(8.dp))
                Text("नया वस्तुनिष्ठ प्रश्न जोड़ें (+ Add MCQ)", fontWeight = FontWeight.Bold)
            }
        }

        // Chapter Filter Chips
        item {
            Text(text = "अध्याय अनुसार फिल्टर करें:", style = MaterialTheme.typography.bodySmall.copy(fontWeight = FontWeight.Bold))
            Spacer(modifier = Modifier.height(4.dp))
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .horizontalScroll(rememberScrollState()),
                horizontalArrangement = Arrangement.spacedBy(6.dp)
            ) {
                FilterChip(
                    selected = filterChapterId == "ALL",
                    onClick = { onFilterChange("ALL") },
                    label = { Text("सभी अध्याय (${questions.size})", fontSize = 11.sp) }
                )
                chapters.forEach { ch ->
                    FilterChip(
                        selected = filterChapterId == ch.id,
                        onClick = { onFilterChange(ch.id) },
                        label = { Text("पाठ ${ch.chapterNumber}", fontSize = 11.sp) }
                    )
                }
            }
        }

        if (questions.isEmpty()) {
            item {
                Card(
                    modifier = Modifier.fillMaxWidth(),
                    shape = RoundedCornerShape(12.dp),
                    colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface)
                ) {
                    Column(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(24.dp),
                        horizontalAlignment = Alignment.CenterHorizontally
                    ) {
                        Icon(imageVector = Icons.Outlined.Quiz, contentDescription = null, tint = TextMuted, modifier = Modifier.size(44.dp))
                        Spacer(modifier = Modifier.height(8.dp))
                        Text(text = "इस अध्याय में कोई वस्तुनिष्ठ प्रश्न नहीं है", fontWeight = FontWeight.Bold)
                        Text(text = "असीमित प्रश्न जोड़ने के लिए '+ Add MCQ' बटन दबाएं।", color = TextSecondary, fontSize = 12.sp)
                    }
                }
            }
        } else {
            items(questions) { q ->
                Card(
                    modifier = Modifier.fillMaxWidth(),
                    shape = RoundedCornerShape(10.dp),
                    colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
                    elevation = CardDefaults.cardElevation(defaultElevation = 1.dp)
                ) {
                    Column(modifier = Modifier.padding(14.dp)) {
                        Row(verticalAlignment = Alignment.Top) {
                            Text(
                                text = "Q.",
                                fontWeight = FontWeight.Bold,
                                color = RoyalBluePrimary,
                                modifier = Modifier.padding(end = 6.dp)
                            )
                            Text(
                                text = q.questionText,
                                style = MaterialTheme.typography.bodyMedium.copy(fontWeight = FontWeight.Bold),
                                modifier = Modifier.weight(1f)
                            )
                            IconButton(onClick = { onEditQuestion(q) }, modifier = Modifier.size(28.dp)) {
                                Icon(imageVector = Icons.Default.Edit, contentDescription = "Edit", tint = RoyalBluePrimary, modifier = Modifier.size(18.dp))
                            }
                            IconButton(onClick = { onDeleteQuestion(q) }, modifier = Modifier.size(28.dp)) {
                                Icon(imageVector = Icons.Default.Delete, contentDescription = "Delete", tint = Color(0xFFE11D48), modifier = Modifier.size(18.dp))
                            }
                        }

                        Spacer(modifier = Modifier.height(8.dp))

                        // 4 Options
                        McqOptionPreview(label = "A", text = q.optionA, isCorrect = q.correctOption == 1)
                        McqOptionPreview(label = "B", text = q.optionB, isCorrect = q.correctOption == 2)
                        McqOptionPreview(label = "C", text = q.optionC, isCorrect = q.correctOption == 3)
                        McqOptionPreview(label = "D", text = q.optionD, isCorrect = q.correctOption == 4)

                        if (q.explanation.isNotBlank()) {
                            Spacer(modifier = Modifier.height(6.dp))
                            Surface(
                                shape = RoundedCornerShape(6.dp),
                                color = RoyalBlueContainer.copy(alpha = 0.5f),
                                modifier = Modifier.fillMaxWidth()
                            ) {
                                Text(
                                    text = "व्याख्या: ${q.explanation}",
                                    fontSize = 11.sp,
                                    color = RoyalBlueDark,
                                    modifier = Modifier.padding(8.dp)
                                )
                            }
                        }

                        if (q.isPreviousYear) {
                            Spacer(modifier = Modifier.height(4.dp))
                            Surface(shape = RoundedCornerShape(4.dp), color = BiharBoardGold.copy(alpha = 0.2f)) {
                                Text(
                                    text = "BSEB ${q.examYear} PYQ",
                                    fontSize = 10.sp,
                                    fontWeight = FontWeight.Bold,
                                    color = RoyalBlueDark,
                                    modifier = Modifier.padding(horizontal = 6.dp, vertical = 2.dp)
                                )
                            }
                        }
                    }
                }
            }
        }
    }
}

@Composable
private fun McqOptionPreview(label: String, text: String, isCorrect: Boolean) {
    Surface(
        shape = RoundedCornerShape(6.dp),
        color = if (isCorrect) EmeraldAccent.copy(alpha = 0.15f) else MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.4f),
        border = if (isCorrect) BorderStroke(1.dp, EmeraldAccent) else null,
        modifier = Modifier
            .fillMaxWidth()
            .padding(vertical = 2.dp)
    ) {
        Row(
            modifier = Modifier.padding(horizontal = 8.dp, vertical = 4.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            Text(
                text = "($label) ",
                fontWeight = FontWeight.Bold,
                color = if (isCorrect) EmeraldAccent else TextSecondary,
                fontSize = 12.sp
            )
            Text(
                text = text,
                fontSize = 12.sp,
                color = if (isCorrect) EmeraldAccent else MaterialTheme.colorScheme.onSurface,
                modifier = Modifier.weight(1f)
            )
            if (isCorrect) {
                Icon(imageVector = Icons.Default.CheckCircle, contentDescription = "Correct", tint = EmeraldAccent, modifier = Modifier.size(16.dp))
            }
        }
    }
}

// -------------------------------------------------------------------------
// Sub-Tab 3: Subjective Questions
// -------------------------------------------------------------------------
@Composable
fun SubjectiveQuestionsTab(
    subjectId: String,
    courseId: String,
    chapters: List<Chapter>,
    filterChapterId: String,
    onFilterChange: (String) -> Unit,
    adminViewModel: AdminViewModel,
    onAddQuestion: () -> Unit,
    onEditQuestion: (SubjectiveQuestion) -> Unit,
    onDeleteQuestion: (SubjectiveQuestion) -> Unit
) {
    val subFlow = remember(filterChapterId, subjectId) {
        if (filterChapterId != "ALL") {
            adminViewModel.getSubjectiveQuestionsByChapter(filterChapterId)
        } else {
            adminViewModel.repository.getSubjectiveQuestionsByCourse(courseId)
        }
    }
    val allQuestions by subFlow.collectAsState(initial = emptyList())
    val questions = remember(allQuestions, filterChapterId, subjectId) {
        if (filterChapterId != "ALL") {
            allQuestions.filter { it.chapterId == filterChapterId }
        } else {
            allQuestions.filter { it.subjectId == subjectId }
        }
    }

    LazyColumn(
        modifier = Modifier
            .fillMaxSize()
            .padding(16.dp),
        verticalArrangement = Arrangement.spacedBy(10.dp)
    ) {
        item {
            Button(
                onClick = onAddQuestion,
                modifier = Modifier
                    .fillMaxWidth()
                    .height(48.dp)
                    .testTag("admin_add_subjective_btn"),
                shape = RoundedCornerShape(10.dp),
                colors = ButtonDefaults.buttonColors(containerColor = RoyalBluePrimary)
            ) {
                Icon(imageVector = Icons.Default.Add, contentDescription = null)
                Spacer(modifier = Modifier.width(8.dp))
                Text("नया सब्जेक्टिव प्रश्न जोड़ें (+ Add Subjective)", fontWeight = FontWeight.Bold)
            }
        }

        // Chapter Filter
        item {
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .horizontalScroll(rememberScrollState()),
                horizontalArrangement = Arrangement.spacedBy(6.dp)
            ) {
                FilterChip(
                    selected = filterChapterId == "ALL",
                    onClick = { onFilterChange("ALL") },
                    label = { Text("सभी अध्याय (${questions.size})", fontSize = 11.sp) }
                )
                chapters.forEach { ch ->
                    FilterChip(
                        selected = filterChapterId == ch.id,
                        onClick = { onFilterChange(ch.id) },
                        label = { Text("पाठ ${ch.chapterNumber}", fontSize = 11.sp) }
                    )
                }
            }
        }

        if (questions.isEmpty()) {
            item {
                Card(
                    modifier = Modifier.fillMaxWidth(),
                    shape = RoundedCornerShape(12.dp),
                    colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface)
                ) {
                    Column(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(24.dp),
                        horizontalAlignment = Alignment.CenterHorizontally
                    ) {
                        Icon(imageVector = Icons.Outlined.EditNote, contentDescription = null, tint = TextMuted, modifier = Modifier.size(44.dp))
                        Spacer(modifier = Modifier.height(8.dp))
                        Text(text = "कोई सब्जेक्टिव प्रश्न नहीं मिला", fontWeight = FontWeight.Bold)
                        Text(text = "लघु उत्तरीय व दीर्घ उत्तरीय प्रश्नों को यहाँ जोड़ें।", color = TextSecondary, fontSize = 12.sp)
                    }
                }
            }
        } else {
            items(questions) { q ->
                Card(
                    modifier = Modifier.fillMaxWidth(),
                    shape = RoundedCornerShape(10.dp),
                    colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
                    elevation = CardDefaults.cardElevation(defaultElevation = 1.dp)
                ) {
                    Column(modifier = Modifier.padding(14.dp)) {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Surface(
                                shape = RoundedCornerShape(4.dp),
                                color = if (q.marks >= 5) AmberAccent.copy(alpha = 0.2f) else RoyalBluePrimary.copy(alpha = 0.15f)
                            ) {
                                Text(
                                    text = if (q.marks >= 5) "दीर्घ उत्तरीय (${q.marks} अंक)" else "लघु उत्तरीय (${q.marks} अंक)",
                                    fontSize = 11.sp,
                                    fontWeight = FontWeight.Bold,
                                    color = if (q.marks >= 5) AmberAccent else RoyalBluePrimary,
                                    modifier = Modifier.padding(horizontal = 6.dp, vertical = 2.dp)
                                )
                            }
                            Spacer(modifier = Modifier.weight(1f))
                            IconButton(onClick = { onEditQuestion(q) }, modifier = Modifier.size(28.dp)) {
                                Icon(imageVector = Icons.Default.Edit, contentDescription = "Edit", tint = RoyalBluePrimary, modifier = Modifier.size(18.dp))
                            }
                            IconButton(onClick = { onDeleteQuestion(q) }, modifier = Modifier.size(28.dp)) {
                                Icon(imageVector = Icons.Default.Delete, contentDescription = "Delete", tint = Color(0xFFE11D48), modifier = Modifier.size(18.dp))
                            }
                        }

                        Spacer(modifier = Modifier.height(6.dp))
                        Text(text = "प्रश्न: ${q.questionText}", fontWeight = FontWeight.Bold, fontSize = 14.sp)
                        Spacer(modifier = Modifier.height(6.dp))
                        Text(text = "उत्तर: ${q.answerText}", fontSize = 13.sp, color = MaterialTheme.colorScheme.onSurfaceVariant)
                    }
                }
            }
        }
    }
}

// -------------------------------------------------------------------------
// Sub-Tab 4: Mock Tests
// -------------------------------------------------------------------------
@Composable
fun MockTestsTab(
    subjectId: String,
    courseId: String,
    chapters: List<Chapter>,
    mockTests: List<MockTest>,
    onCreateTest: () -> Unit,
    onTogglePublish: (testId: String, newStatus: Boolean) -> Unit,
    onDeleteTest: (MockTest) -> Unit
) {
    LazyColumn(
        modifier = Modifier
            .fillMaxSize()
            .padding(16.dp),
        verticalArrangement = Arrangement.spacedBy(12.dp)
    ) {
        item {
            Button(
                onClick = onCreateTest,
                modifier = Modifier
                    .fillMaxWidth()
                    .height(48.dp)
                    .testTag("admin_create_mock_test_btn"),
                shape = RoundedCornerShape(10.dp),
                colors = ButtonDefaults.buttonColors(containerColor = RoyalBluePrimary)
            ) {
                Icon(imageVector = Icons.Default.Add, contentDescription = null)
                Spacer(modifier = Modifier.width(8.dp))
                Text("नया मॉक टेस्ट बनाएँ (Create Mock Test)", fontWeight = FontWeight.Bold)
            }
        }

        if (mockTests.isEmpty()) {
            item {
                Card(
                    modifier = Modifier.fillMaxWidth(),
                    shape = RoundedCornerShape(12.dp),
                    colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface)
                ) {
                    Column(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(24.dp),
                        horizontalAlignment = Alignment.CenterHorizontally
                    ) {
                        Icon(imageVector = Icons.Outlined.Timer, contentDescription = null, tint = TextMuted, modifier = Modifier.size(44.dp))
                        Spacer(modifier = Modifier.height(8.dp))
                        Text(text = "इस विषय में कोई मॉक टेस्ट नहीं बना है", fontWeight = FontWeight.Bold)
                        Text(text = "छात्रों के ऑनलाइन अभ्यास के लिए अध्याय-वार या विषय-वार टेस्ट बनाएं।", color = TextSecondary, fontSize = 12.sp)
                    }
                }
            }
        } else {
            items(mockTests) { test ->
                Card(
                    modifier = Modifier
                        .fillMaxWidth()
                        .testTag("admin_mock_test_${test.id}"),
                    shape = RoundedCornerShape(12.dp),
                    colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
                    elevation = CardDefaults.cardElevation(defaultElevation = 2.dp)
                ) {
                    Column(modifier = Modifier.padding(14.dp)) {
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Column(modifier = Modifier.weight(1f)) {
                                Text(text = test.title, style = MaterialTheme.typography.titleSmall.copy(fontWeight = FontWeight.Bold))
                                Text(text = test.description, style = MaterialTheme.typography.bodySmall.copy(color = TextSecondary), maxLines = 1, overflow = TextOverflow.Ellipsis)
                            }
                            IconButton(onClick = { onDeleteTest(test) }) {
                                Icon(imageVector = Icons.Default.Delete, contentDescription = "Delete Test", tint = Color(0xFFE11D48))
                            }
                        }

                        Spacer(modifier = Modifier.height(8.dp))

                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.spacedBy(8.dp)
                        ) {
                            Surface(shape = RoundedCornerShape(6.dp), color = RoyalBlueContainer.copy(alpha = 0.5f)) {
                                Text("⏱ ${test.durationMinutes} मिनट", fontSize = 11.sp, color = RoyalBlueDark, modifier = Modifier.padding(horizontal = 6.dp, vertical = 2.dp))
                            }
                            Surface(shape = RoundedCornerShape(6.dp), color = EmeraldAccent.copy(alpha = 0.15f)) {
                                Text("🎯 ${test.totalMarks} अंक", fontSize = 11.sp, color = EmeraldAccent, modifier = Modifier.padding(horizontal = 6.dp, vertical = 2.dp))
                            }
                            Surface(shape = RoundedCornerShape(6.dp), color = MaterialTheme.colorScheme.surfaceVariant) {
                                Text("📝 ${test.totalQuestions} प्रश्न", fontSize = 11.sp, modifier = Modifier.padding(horizontal = 6.dp, vertical = 2.dp))
                            }
                        }

                        Spacer(modifier = Modifier.height(10.dp))
                        Divider(color = OutlineLight.copy(alpha = 0.5f))
                        Spacer(modifier = Modifier.height(8.dp))

                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            verticalAlignment = Alignment.CenterVertically,
                            horizontalArrangement = Arrangement.SpaceBetween
                        ) {
                            Text(
                                text = if (test.isPublished) "स्थिति: प्रकाशित (Live)" else "स्थिति: ड्राफ्ट (Draft)",
                                fontWeight = FontWeight.Bold,
                                fontSize = 12.sp,
                                color = if (test.isPublished) EmeraldAccent else AmberAccent
                            )
                            Switch(
                                checked = test.isPublished,
                                onCheckedChange = { onTogglePublish(test.id, it) },
                                modifier = Modifier.testTag("test_publish_switch_${test.id}")
                            )
                        }
                    }
                }
            }
        }
    }
}

// -------------------------------------------------------------------------
// Helper Components & Form Dialogs
// -------------------------------------------------------------------------

@Composable
fun MetricPill(label: String, value: String, color: Color) {
    Column(horizontalAlignment = Alignment.CenterHorizontally) {
        Text(text = value, style = MaterialTheme.typography.titleMedium.copy(fontWeight = FontWeight.Bold, color = color))
        Text(text = label, style = MaterialTheme.typography.labelSmall.copy(color = TextSecondary, fontSize = 10.sp))
    }
}

@Composable
fun ChapterFormDialog(
    subjectId: String,
    courseId: String,
    initialChapter: Chapter?,
    nextChapterNumber: Int,
    onDismiss: () -> Unit,
    onSave: (
        chapterNumber: Int,
        title: String,
        hindiTitle: String,
        authorName: String,
        authorIntro: String,
        authorLifeHistory: String,
        explanation: String,
        importantPoints: String,
        definitions: String,
        pdfUrl: String,
        isPublished: Boolean
    ) -> Unit
) {
    var chapterNumberText by remember { mutableStateOf(initialChapter?.chapterNumber?.toString() ?: nextChapterNumber.toString()) }
    var title by remember { mutableStateOf(initialChapter?.title ?: "") }
    var hindiTitle by remember { mutableStateOf(initialChapter?.hindiTitle ?: "") }
    var authorName by remember { mutableStateOf(initialChapter?.authorName ?: "") }
    var authorIntro by remember { mutableStateOf(initialChapter?.authorIntro ?: "") }
    var authorLifeHistory by remember { mutableStateOf(initialChapter?.authorLifeHistory ?: "") }
    var explanation by remember { mutableStateOf(initialChapter?.explanation ?: "") }
    var importantPoints by remember { mutableStateOf(initialChapter?.importantPoints?.joinToString("\n") ?: "") }
    var definitions by remember { mutableStateOf(initialChapter?.definitions?.joinToString("\n") ?: "") }
    var pdfUrl by remember { mutableStateOf(initialChapter?.pdfUrl ?: "") }
    var isPublished by remember { mutableStateOf(initialChapter?.isPublished ?: true) }

    AlertDialog(
        onDismissRequest = onDismiss,
        title = {
            Text(
                text = if (initialChapter != null) "अध्याय संपादित करें (Edit Chapter)" else "नया अध्याय जोड़ें (Add Chapter)",
                fontWeight = FontWeight.Bold
            )
        },
        text = {
            LazyColumn(
                modifier = Modifier.fillMaxWidth(),
                verticalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                item {
                    OutlinedTextField(
                        value = chapterNumberText,
                        onValueChange = { chapterNumberText = it },
                        label = { Text("अध्याय क्रमांक (Chapter Number)") },
                        modifier = Modifier.fillMaxWidth(),
                        singleLine = true
                    )
                }
                item {
                    OutlinedTextField(
                        value = title,
                        onValueChange = { title = it },
                        label = { Text("अध्याय का शीर्षक (Hindi Title) *") },
                        modifier = Modifier.fillMaxWidth(),
                        singleLine = true
                    )
                }
                item {
                    OutlinedTextField(
                        value = hindiTitle,
                        onValueChange = { hindiTitle = it },
                        label = { Text("विस्तृत शीर्षक (जैसे पाठ 1: श्रम विभाजन...)") },
                        modifier = Modifier.fillMaxWidth(),
                        singleLine = true
                    )
                }
                item {
                    OutlinedTextField(
                        value = authorName,
                        onValueChange = { authorName = it },
                        label = { Text("लेखक / रचनाकार का नाम") },
                        modifier = Modifier.fillMaxWidth(),
                        singleLine = true
                    )
                }
                item {
                    OutlinedTextField(
                        value = authorIntro,
                        onValueChange = { authorIntro = it },
                        label = { Text("लेखक परिचय") },
                        modifier = Modifier.fillMaxWidth(),
                        minLines = 2
                    )
                }
                item {
                    OutlinedTextField(
                        value = explanation,
                        onValueChange = { explanation = it },
                        label = { Text("अध्याय व्याख्या / नोट्स सारांश") },
                        modifier = Modifier.fillMaxWidth(),
                        minLines = 3
                    )
                }
                item {
                    OutlinedTextField(
                        value = pdfUrl,
                        onValueChange = { pdfUrl = it },
                        label = { Text("PDF लिंक / पाथ (वैकल्पिक)") },
                        modifier = Modifier.fillMaxWidth(),
                        singleLine = true
                    )
                }
                item {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.SpaceBetween
                    ) {
                        Text("तुरंत प्रकाशित करें (Live to Students):", fontSize = 12.sp, fontWeight = FontWeight.Bold)
                        Switch(checked = isPublished, onCheckedChange = { isPublished = it })
                    }
                }
            }
        },
        confirmButton = {
            Button(
                onClick = {
                    if (title.isNotBlank()) {
                        val num = chapterNumberText.toIntOrNull() ?: nextChapterNumber
                        onSave(num, title, hindiTitle.ifBlank { "पाठ $num: $title" }, authorName, authorIntro, authorLifeHistory, explanation, importantPoints, definitions, pdfUrl, isPublished)
                    }
                },
                colors = ButtonDefaults.buttonColors(containerColor = RoyalBluePrimary)
            ) {
                Text("सहेजें (Save)")
            }
        },
        dismissButton = {
            TextButton(onClick = onDismiss) { Text("रद्द करें") }
        }
    )
}

@Composable
fun McqFormDialog(
    subjectId: String,
    courseId: String,
    chapters: List<Chapter>,
    initialQuestion: ObjectiveQuestion?,
    defaultChapterId: String,
    onDismiss: () -> Unit,
    onSave: (
        id: String?,
        chapterId: String,
        qText: String,
        opA: String,
        opB: String,
        opC: String,
        opD: String,
        correctOp: Int,
        exp: String,
        marks: Int,
        difficulty: String,
        isPyq: Boolean,
        year: String
    ) -> Unit
) {
    var selectedChapterId by remember { mutableStateOf(initialQuestion?.chapterId ?: defaultChapterId) }
    var questionText by remember { mutableStateOf(initialQuestion?.questionText ?: "") }
    var opA by remember { mutableStateOf(initialQuestion?.optionA ?: "") }
    var opB by remember { mutableStateOf(initialQuestion?.optionB ?: "") }
    var opC by remember { mutableStateOf(initialQuestion?.optionC ?: "") }
    var opD by remember { mutableStateOf(initialQuestion?.optionD ?: "") }
    var correctOp by remember { mutableStateOf(initialQuestion?.correctOption ?: 1) }
    var explanation by remember { mutableStateOf(initialQuestion?.explanation ?: "") }
    var isPyq by remember { mutableStateOf(initialQuestion?.isPreviousYear ?: false) }
    var examYear by remember { mutableStateOf(initialQuestion?.examYear ?: "2024") }

    AlertDialog(
        onDismissRequest = onDismiss,
        title = { Text(if (initialQuestion != null) "MCQ प्रश्न संपादित करें" else "नया वस्तुनिष्ठ प्रश्न जोड़ें", fontWeight = FontWeight.Bold) },
        text = {
            LazyColumn(
                modifier = Modifier.fillMaxWidth(),
                verticalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                item {
                    Text("अध्याय चुनें:", fontSize = 12.sp, fontWeight = FontWeight.Bold)
                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .horizontalScroll(rememberScrollState()),
                        horizontalArrangement = Arrangement.spacedBy(6.dp)
                    ) {
                        chapters.forEach { ch ->
                            FilterChip(
                                selected = selectedChapterId == ch.id,
                                onClick = { selectedChapterId = ch.id },
                                label = { Text("पाठ ${ch.chapterNumber}", fontSize = 11.sp) }
                            )
                        }
                    }
                }

                item {
                    OutlinedTextField(
                        value = questionText,
                        onValueChange = { questionText = it },
                        label = { Text("प्रश्न पाठ (Question Text) *") },
                        modifier = Modifier.fillMaxWidth(),
                        minLines = 2
                    )
                }

                item { OutlinedTextField(value = opA, onValueChange = { opA = it }, label = { Text("विकल्प A *") }, modifier = Modifier.fillMaxWidth(), singleLine = true) }
                item { OutlinedTextField(value = opB, onValueChange = { opB = it }, label = { Text("विकल्प B *") }, modifier = Modifier.fillMaxWidth(), singleLine = true) }
                item { OutlinedTextField(value = opC, onValueChange = { opC = it }, label = { Text("विकल्प C *") }, modifier = Modifier.fillMaxWidth(), singleLine = true) }
                item { OutlinedTextField(value = opD, onValueChange = { opD = it }, label = { Text("विकल्प D *") }, modifier = Modifier.fillMaxWidth(), singleLine = true) }

                item {
                    Text("सही उत्तर विकल्प चुनें (Correct Answer):", fontSize = 12.sp, fontWeight = FontWeight.Bold)
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceAround
                    ) {
                        listOf(1 to "A", 2 to "B", 3 to "C", 4 to "D").forEach { (idx, label) ->
                            Row(verticalAlignment = Alignment.CenterVertically) {
                                RadioButton(selected = correctOp == idx, onClick = { correctOp = idx })
                                Text(label, fontWeight = FontWeight.Bold)
                            }
                        }
                    }
                }

                item {
                    OutlinedTextField(
                        value = explanation,
                        onValueChange = { explanation = it },
                        label = { Text("विस्तृत उत्तर व्याख्या (Explanation)") },
                        modifier = Modifier.fillMaxWidth(),
                        minLines = 2
                    )
                }

                item {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Checkbox(checked = isPyq, onCheckedChange = { isPyq = it })
                        Text("बिहार बोर्ड विगत वर्ष प्रश्न (BSEB PYQ)", fontSize = 12.sp)
                    }
                }

                if (isPyq) {
                    item {
                        OutlinedTextField(
                            value = examYear,
                            onValueChange = { examYear = it },
                            label = { Text("परीक्षा वर्ष (जैसे 2024, 2023)") },
                            modifier = Modifier.fillMaxWidth(),
                            singleLine = true
                        )
                    }
                }
            }
        },
        confirmButton = {
            Button(
                onClick = {
                    if (questionText.isNotBlank() && opA.isNotBlank() && opB.isNotBlank() && selectedChapterId.isNotBlank()) {
                        onSave(initialQuestion?.id, selectedChapterId, questionText, opA, opB, opC.ifBlank { "उपरोक्त में से कोई नहीं" }, opD.ifBlank { "उपरोक्त सभी" }, correctOp, explanation, 1, "मध्यम", isPyq, examYear)
                    }
                },
                colors = ButtonDefaults.buttonColors(containerColor = RoyalBluePrimary)
            ) {
                Text("सहेजें (Save)")
            }
        },
        dismissButton = {
            TextButton(onClick = onDismiss) { Text("रद्द करें") }
        }
    )
}

@Composable
fun SubjectiveFormDialog(
    subjectId: String,
    courseId: String,
    chapters: List<Chapter>,
    initialQuestion: SubjectiveQuestion?,
    defaultChapterId: String,
    onDismiss: () -> Unit,
    onSave: (
        id: String?,
        chapterId: String,
        qText: String,
        ansText: String,
        marks: Int,
        questionType: String,
        isImp: Boolean,
        isPyq: Boolean,
        year: String
    ) -> Unit
) {
    var selectedChapterId by remember { mutableStateOf(initialQuestion?.chapterId ?: defaultChapterId) }
    var questionText by remember { mutableStateOf(initialQuestion?.questionText ?: "") }
    var answerText by remember { mutableStateOf(initialQuestion?.answerText ?: "") }
    var marks by remember { mutableStateOf(initialQuestion?.marks ?: 2) }
    var isImp by remember { mutableStateOf(initialQuestion?.isImportant ?: true) }
    var isPyq by remember { mutableStateOf(initialQuestion?.isPreviousYear ?: false) }
    var examYear by remember { mutableStateOf(initialQuestion?.examYear ?: "2024") }

    AlertDialog(
        onDismissRequest = onDismiss,
        title = { Text(if (initialQuestion != null) "सब्जेक्टिव प्रश्न संपादित करें" else "नया सब्जेक्टिव प्रश्न जोड़ें", fontWeight = FontWeight.Bold) },
        text = {
            LazyColumn(
                modifier = Modifier.fillMaxWidth(),
                verticalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                item {
                    Text("अध्याय चुनें:", fontSize = 12.sp, fontWeight = FontWeight.Bold)
                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .horizontalScroll(rememberScrollState()),
                        horizontalArrangement = Arrangement.spacedBy(6.dp)
                    ) {
                        chapters.forEach { ch ->
                            FilterChip(
                                selected = selectedChapterId == ch.id,
                                onClick = { selectedChapterId = ch.id },
                                label = { Text("पाठ ${ch.chapterNumber}", fontSize = 11.sp) }
                            )
                        }
                    }
                }

                item {
                    Text("प्रश्न प्रकार (अंक निर्धारण):", fontSize = 12.sp, fontWeight = FontWeight.Bold)
                    Row(horizontalArrangement = Arrangement.spacedBy(12.dp)) {
                        FilterChip(selected = marks == 2, onClick = { marks = 2 }, label = { Text("लघु उत्तरीय (2 अंक)") })
                        FilterChip(selected = marks == 5, onClick = { marks = 5 }, label = { Text("दीर्घ उत्तरीय (5 अंक)") })
                    }
                }

                item {
                    OutlinedTextField(
                        value = questionText,
                        onValueChange = { questionText = it },
                        label = { Text("प्रश्न (Question Text) *") },
                        modifier = Modifier.fillMaxWidth(),
                        minLines = 2
                    )
                }

                item {
                    OutlinedTextField(
                        value = answerText,
                        onValueChange = { answerText = it },
                        label = { Text("आदर्श उत्तर (Model Answer in Hindi) *") },
                        modifier = Modifier.fillMaxWidth(),
                        minLines = 4
                    )
                }

                item {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Checkbox(checked = isImp, onCheckedChange = { isImp = it })
                        Text("महत्वपूर्ण प्रश्न (VVI Board Question)", fontSize = 12.sp)
                    }
                }

                item {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Checkbox(checked = isPyq, onCheckedChange = { isPyq = it })
                        Text("बिहार बोर्ड प्रीवियस ईयर (BSEB PYQ)", fontSize = 12.sp)
                    }
                }

                if (isPyq) {
                    item {
                        OutlinedTextField(
                            value = examYear,
                            onValueChange = { examYear = it },
                            label = { Text("परीक्षा वर्ष") },
                            modifier = Modifier.fillMaxWidth(),
                            singleLine = true
                        )
                    }
                }
            }
        },
        confirmButton = {
            Button(
                onClick = {
                    if (questionText.isNotBlank() && answerText.isNotBlank() && selectedChapterId.isNotBlank()) {
                        val qType = if (marks >= 5) "LONG" else "SHORT"
                        onSave(initialQuestion?.id, selectedChapterId, questionText, answerText, marks, qType, isImp, isPyq, examYear)
                    }
                },
                colors = ButtonDefaults.buttonColors(containerColor = RoyalBluePrimary)
            ) {
                Text("सहेजें (Save)")
            }
        },
        dismissButton = {
            TextButton(onClick = onDismiss) { Text("रद्द करें") }
        }
    )
}

@Composable
fun MockTestFormDialog(
    subjectId: String,
    courseId: String,
    chapters: List<Chapter>,
    onDismiss: () -> Unit,
    onSave: (
        chapterId: String,
        title: String,
        desc: String,
        duration: Int,
        totalMarks: Int,
        totalQuestions: Int,
        passMarks: Int,
        isPublished: Boolean
    ) -> Unit
) {
    var isChapterWise by remember { mutableStateOf(false) }
    var selectedChapterId by remember { mutableStateOf(chapters.firstOrNull()?.id ?: "") }
    var title by remember { mutableStateOf("") }
    var description by remember { mutableStateOf("") }
    var durationText by remember { mutableStateOf("45") }
    var totalQuestionsText by remember { mutableStateOf("50") }
    var totalMarksText by remember { mutableStateOf("50") }
    var passMarksText by remember { mutableStateOf("25") }
    var isPublished by remember { mutableStateOf(true) }

    AlertDialog(
        onDismissRequest = onDismiss,
        title = { Text("नया ऑनलाइन मॉक टेस्ट बनाएँ", fontWeight = FontWeight.Bold) },
        text = {
            LazyColumn(
                modifier = Modifier.fillMaxWidth(),
                verticalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                item {
                    Text("टेस्ट का दायरा (Scope):", fontSize = 12.sp, fontWeight = FontWeight.Bold)
                    Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                        FilterChip(selected = !isChapterWise, onClick = { isChapterWise = false }, label = { Text("संपूर्ण विषय टेस्ट") })
                        FilterChip(selected = isChapterWise, onClick = { isChapterWise = true }, label = { Text("अध्याय-वार टेस्ट") })
                    }
                }

                if (isChapterWise) {
                    item {
                        Text("अध्याय चुनें:", fontSize = 12.sp, fontWeight = FontWeight.Bold)
                        Row(
                            modifier = Modifier
                                .fillMaxWidth()
                                .horizontalScroll(rememberScrollState()),
                            horizontalArrangement = Arrangement.spacedBy(6.dp)
                        ) {
                            chapters.forEach { ch ->
                                FilterChip(
                                    selected = selectedChapterId == ch.id,
                                    onClick = { selectedChapterId = ch.id },
                                    label = { Text("पाठ ${ch.chapterNumber}", fontSize = 11.sp) }
                                )
                            }
                        }
                    }
                }

                item {
                    OutlinedTextField(
                        value = title,
                        onValueChange = { title = it },
                        label = { Text("टेस्ट का नाम (Title) *") },
                        modifier = Modifier.fillMaxWidth(),
                        singleLine = true
                    )
                }

                item {
                    OutlinedTextField(
                        value = description,
                        onValueChange = { description = it },
                        label = { Text("विवरण व निर्देश") },
                        modifier = Modifier.fillMaxWidth(),
                        minLines = 2
                    )
                }

                item {
                    Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                        OutlinedTextField(
                            value = durationText,
                            onValueChange = { durationText = it },
                            label = { Text("अवधि (मिनट)") },
                            modifier = Modifier.weight(1f),
                            singleLine = true
                        )
                        OutlinedTextField(
                            value = totalQuestionsText,
                            onValueChange = { totalQuestionsText = it },
                            label = { Text("कुल प्रश्न") },
                            modifier = Modifier.weight(1f),
                            singleLine = true
                        )
                    }
                }

                item {
                    Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                        OutlinedTextField(
                            value = totalMarksText,
                            onValueChange = { totalMarksText = it },
                            label = { Text("पूर्णांक (Marks)") },
                            modifier = Modifier.weight(1f),
                            singleLine = true
                        )
                        OutlinedTextField(
                            value = passMarksText,
                            onValueChange = { passMarksText = it },
                            label = { Text("उत्तीर्णांक (Pass)") },
                            modifier = Modifier.weight(1f),
                            singleLine = true
                        )
                    }
                }

                item {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.SpaceBetween
                    ) {
                        Text("छात्रों के लिए तुरंत प्रकाशित करें:", fontSize = 12.sp, fontWeight = FontWeight.Bold)
                        Switch(checked = isPublished, onCheckedChange = { isPublished = it })
                    }
                }
            }
        },
        confirmButton = {
            Button(
                onClick = {
                    if (title.isNotBlank()) {
                        val dur = durationText.toIntOrNull() ?: 45
                        val tMarks = totalMarksText.toIntOrNull() ?: 50
                        val tQuestions = totalQuestionsText.toIntOrNull() ?: 50
                        val pMarks = passMarksText.toIntOrNull() ?: 25
                        val chId = if (isChapterWise) selectedChapterId else ""
                        onSave(chId, title, description, dur, tMarks, tQuestions, pMarks, isPublished)
                    }
                },
                colors = ButtonDefaults.buttonColors(containerColor = RoyalBluePrimary)
            ) {
                Text("टेस्ट बनाएँ")
            }
        },
        dismissButton = {
            TextButton(onClick = onDismiss) { Text("रद्द करें") }
        }
    )
}
