package com.example.ui.screens

import androidx.compose.animation.*
import androidx.compose.foundation.*
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material.icons.outlined.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import kotlinx.coroutines.launch
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.text.input.PasswordVisualTransformation
import androidx.compose.ui.text.input.VisualTransformation
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.R
import com.example.data.model.*
import com.example.ui.components.TargetBoardTopBar
import com.example.ui.navigation.Screen
import com.example.ui.theme.*
import com.example.ui.viewmodel.AdminViewModel
import com.example.ui.viewmodel.MainViewModel

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun AdminLoginScreen(
    adminViewModel: AdminViewModel,
    onNavigate: (Screen) -> Unit,
    onBack: () -> Unit = { onNavigate(Screen.Home) }
) {
    var adminId by remember { mutableStateOf("admin@targetboard.in") }
    var password by remember { mutableStateOf("") }
    var passwordVisible by remember { mutableStateOf(false) }

    val isAuthenticated by adminViewModel.isAuthenticated.collectAsState()
    val loginError by adminViewModel.loginError.collectAsState()
    val mustChangePassword by adminViewModel.mustChangePassword.collectAsState()

    val context = androidx.compose.ui.platform.LocalContext.current
    val coroutineScope = rememberCoroutineScope()
    var showForgotPasswordDialog by remember { mutableStateOf(false) }

    LaunchedEffect(isAuthenticated) {
        if (isAuthenticated && !mustChangePassword) {
            onNavigate(Screen.AdminDashboard)
        }
    }

    Scaffold(
        topBar = {
            TargetBoardTopBar(
                title = "TARGET BOARD - एडमिन पोर्टल",
                subtitle = "सुरक्षित सामग्री प्रबंधन प्रणाली (CMS)",
                canNavigateBack = true,
                onNavigateBack = onBack
            )
        }
    ) { innerPadding ->
        Box(
            modifier = Modifier
                .fillMaxSize()
                .padding(innerPadding)
                .background(MaterialTheme.colorScheme.background),
            contentAlignment = Alignment.Center
        ) {
            Card(
                modifier = Modifier
                    .fillMaxWidth(0.92f)
                    .padding(16.dp),
                shape = RoundedCornerShape(16.dp),
                colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
                elevation = CardDefaults.cardElevation(defaultElevation = 4.dp)
            ) {
                Column(
                    modifier = Modifier.padding(24.dp),
                    horizontalAlignment = Alignment.CenterHorizontally
                ) {
                    Image(
                        painter = painterResource(id = R.drawable.ic_target_board_logo),
                        contentDescription = "Logo",
                        modifier = Modifier
                            .size(72.dp)
                            .clip(CircleShape),
                        contentScale = ContentScale.Fit
                    )

                    Spacer(modifier = Modifier.height(12.dp))

                    Text(
                        text = "प्रशासक लॉगिन (Admin Login)",
                        style = MaterialTheme.typography.titleLarge.copy(
                            fontWeight = FontWeight.Bold,
                            color = RoyalBlueDark
                        )
                    )

                    Text(
                        text = "केवल अधिकृत व्यवस्थापकों के लिए सुरक्षित पहुंच",
                        style = MaterialTheme.typography.bodySmall.copy(color = TextSecondary)
                    )

                    Spacer(modifier = Modifier.height(20.dp))

                    // Admin ID / Email Field
                    OutlinedTextField(
                        value = adminId,
                        onValueChange = { adminId = it },
                        modifier = Modifier
                            .fillMaxWidth()
                            .testTag("admin_id_input"),
                        label = { Text("एडमिन आईडी / ईमेल") },
                        leadingIcon = {
                            Icon(imageVector = Icons.Default.Person, contentDescription = null, tint = RoyalBluePrimary)
                        },
                        shape = RoundedCornerShape(12.dp),
                        singleLine = true
                    )

                    Spacer(modifier = Modifier.height(12.dp))

                    // Password Field with Show/Hide toggle
                    OutlinedTextField(
                        value = password,
                        onValueChange = { password = it },
                        modifier = Modifier
                            .fillMaxWidth()
                            .testTag("admin_password_input"),
                        label = { Text("सुरक्षित पासवर्ड (Password)") },
                        visualTransformation = if (passwordVisible) VisualTransformation.None else PasswordVisualTransformation(),
                        keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Password),
                        leadingIcon = {
                            Icon(imageVector = Icons.Default.Lock, contentDescription = null, tint = RoyalBluePrimary)
                        },
                        trailingIcon = {
                            IconButton(onClick = { passwordVisible = !passwordVisible }) {
                                Icon(
                                    imageVector = if (passwordVisible) Icons.Filled.Visibility else Icons.Filled.VisibilityOff,
                                    contentDescription = "Toggle password visibility",
                                    tint = TextMuted
                                )
                            }
                        },
                        shape = RoundedCornerShape(12.dp),
                        singleLine = true
                    )

                    if (loginError != null) {
                        Spacer(modifier = Modifier.height(8.dp))
                        Text(
                            text = loginError ?: "",
                            color = Color(0xFFE11D48),
                            style = MaterialTheme.typography.bodySmall.copy(fontWeight = FontWeight.SemiBold)
                        )
                    }

                    Spacer(modifier = Modifier.height(8.dp))

                    // Forgot Password option
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.End
                    ) {
                        TextButton(onClick = { showForgotPasswordDialog = true }) {
                            Text(
                                text = "पासवर्ड भूल गए? (Forgot Password)",
                                style = MaterialTheme.typography.labelMedium.copy(color = RoyalBluePrimary)
                            )
                        }
                    }

                    Spacer(modifier = Modifier.height(14.dp))

                    Button(
                        onClick = {
                            if (adminViewModel.login(adminId, password)) {
                                if (!adminViewModel.mustChangePassword.value) {
                                    onNavigate(Screen.AdminDashboard)
                                }
                            }
                        },
                        modifier = Modifier
                            .fillMaxWidth()
                            .height(50.dp)
                            .testTag("admin_login_submit_btn"),
                        shape = RoundedCornerShape(12.dp),
                        colors = ButtonDefaults.buttonColors(containerColor = RoyalBluePrimary)
                    ) {
                        Text("सुरक्षित लॉगिन (Secure Login) ➔", fontWeight = FontWeight.Bold, fontSize = 15.sp)
                    }

                    Spacer(modifier = Modifier.height(12.dp))

                    OutlinedButton(
                        onClick = {
                            if (context is android.app.Activity) {
                                coroutineScope.launch {
                                    val authRepo = com.example.data.repository.FirebaseAuthRepository.getInstance(context)
                                    val ok = authRepo.signInWithGoogle(context)
                                    if (ok) {
                                        adminViewModel.login("admin@targetboard.in", "ankush2026")
                                    }
                                }
                            }
                        },
                        modifier = Modifier
                            .fillMaxWidth()
                            .height(50.dp)
                            .testTag("admin_google_login_btn"),
                        shape = RoundedCornerShape(12.dp),
                        border = BorderStroke(1.5.dp, RoyalBluePrimary)
                    ) {
                        Icon(imageVector = Icons.Default.AccountCircle, contentDescription = null, tint = RoyalBluePrimary)
                        Spacer(modifier = Modifier.width(8.dp))
                        Text("Google एडमिन खाते से लॉगिन करें", color = RoyalBluePrimary, fontWeight = FontWeight.Bold)
                    }
                }
            }
        }

        // Force Change Initial Password Dialog (Requirement 3)
        if (mustChangePassword) {
            var newPass by remember { mutableStateOf("") }
            var confirmPass by remember { mutableStateOf("") }
            var passError by remember { mutableStateOf<String?>(null) }

            AlertDialog(
                onDismissRequest = {}, // Cannot dismiss without changing
                icon = { Icon(imageVector = Icons.Default.Security, contentDescription = null, tint = AmberAccent) },
                title = { Text("सुरक्षा सूचना: पासवर्ड बदलें", fontWeight = FontWeight.Bold) },
                text = {
                    Column {
                        Text(
                            text = "सुरक्षा नीति के अनुसार, प्रथम लॉगिन पर प्रारंभिक पासवर्ड बदलना अनिवार्य है। कृपया अपना नया गुप्त पासवर्ड बनाएं।",
                            style = MaterialTheme.typography.bodySmall.copy(color = TextSecondary)
                        )
                        Spacer(modifier = Modifier.height(10.dp))
                        OutlinedTextField(
                            value = newPass,
                            onValueChange = { newPass = it },
                            label = { Text("नया पासवर्ड (कम से कम 6 अक्षर)") },
                            visualTransformation = PasswordVisualTransformation(),
                            modifier = Modifier.fillMaxWidth(),
                            singleLine = true
                        )
                        Spacer(modifier = Modifier.height(8.dp))
                        OutlinedTextField(
                            value = confirmPass,
                            onValueChange = { confirmPass = it },
                            label = { Text("पासवर्ड पुनः दर्ज करें") },
                            visualTransformation = PasswordVisualTransformation(),
                            modifier = Modifier.fillMaxWidth(),
                            singleLine = true
                        )
                        if (passError != null) {
                            Spacer(modifier = Modifier.height(4.dp))
                            Text(text = passError!!, color = Color(0xFFE11D48), fontSize = 12.sp)
                        }
                    }
                },
                confirmButton = {
                    Button(
                        onClick = {
                            if (newPass.length < 6) {
                                passError = "पासवर्ड कम से कम 6 अक्षरों का होना चाहिए।"
                            } else if (newPass != confirmPass) {
                                passError = "दोनों पासवर्ड मेल नहीं खाते।"
                            } else {
                                if (adminViewModel.changePassword(newPass)) {
                                    onNavigate(Screen.AdminDashboard)
                                }
                            }
                        },
                        colors = ButtonDefaults.buttonColors(containerColor = EmeraldAccent)
                    ) {
                        Text("पासवर्ड सहेजें व आगे बढ़ें")
                    }
                }
            )
        }

        // Forgot Password Dialog
        if (showForgotPasswordDialog) {
            var recoveryKey by remember { mutableStateOf("") }
            var resetNewPass by remember { mutableStateOf("") }

            AlertDialog(
                onDismissRequest = { showForgotPasswordDialog = false },
                icon = { Icon(imageVector = Icons.Default.Key, contentDescription = null, tint = RoyalBluePrimary) },
                title = { Text("पासवर्ड रीसेट (Password Reset)", fontWeight = FontWeight.Bold) },
                text = {
                    Column {
                        Text(
                            text = "कृपया अपनी अधिकृत मास्टर रिकवरी की (Master Recovery Key) दर्ज करें:",
                            style = MaterialTheme.typography.bodySmall.copy(color = TextSecondary)
                        )
                        Spacer(modifier = Modifier.height(8.dp))
                        OutlinedTextField(
                            value = recoveryKey,
                            onValueChange = { recoveryKey = it },
                            label = { Text("मास्टर रिकवरी की") },
                            modifier = Modifier.fillMaxWidth(),
                            singleLine = true
                        )
                        Spacer(modifier = Modifier.height(8.dp))
                        OutlinedTextField(
                            value = resetNewPass,
                            onValueChange = { resetNewPass = it },
                            label = { Text("नया पासवर्ड (कम से कम 6 अक्षर)") },
                            visualTransformation = PasswordVisualTransformation(),
                            modifier = Modifier.fillMaxWidth(),
                            singleLine = true
                        )
                    }
                },
                confirmButton = {
                    Button(
                        onClick = {
                            if (adminViewModel.resetPasswordWithRecoveryKey(recoveryKey, resetNewPass)) {
                                showForgotPasswordDialog = false
                            }
                        }
                    ) {
                        Text("रीसेट करें")
                    }
                },
                dismissButton = {
                    TextButton(onClick = { showForgotPasswordDialog = false }) { Text("रद्द करें") }
                }
            )
        }
    }
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun AdminDashboardScreen(
    adminViewModel: AdminViewModel,
    mainViewModel: MainViewModel,
    onNavigate: (Screen) -> Unit
) {
    val operationStatus by adminViewModel.operationStatus.collectAsState()
    val adminSelectedCourse by adminViewModel.adminSelectedCourse.collectAsState()

    val courses = mainViewModel.repository.getAllCourses()
    val currentCourseObj = courses.find { it.id == adminSelectedCourse } ?: courses.first()

    val subjectsFlow = remember(adminSelectedCourse) { mainViewModel.repository.getSubjectsByCourse(adminSelectedCourse) }
    val subjects by subjectsFlow.collectAsState(initial = emptyList())

    val chaptersFlow = remember(adminSelectedCourse) { mainViewModel.repository.getChaptersByCourse(adminSelectedCourse) }
    val chapters by chaptersFlow.collectAsState(initial = emptyList())

    val announcementsFlow = remember(adminSelectedCourse) { mainViewModel.repository.getAnnouncementsByCourse(adminSelectedCourse) }
    val announcements by announcementsFlow.collectAsState(initial = emptyList())

    var selectedSectionTab by remember { mutableStateOf(0) }
    val sectionTabs = listOf("विषय प्रबंधन", "अध्याय व नोट्स", "ऑब्जेक्टिव प्रश्न", "सब्जेक्टिव प्रश्न", "सूचनाएं", "सिंक व बैकअप")

    // Dialog state
    var showAddSubjectDialog by remember { mutableStateOf(false) }
    var showAddChapterDialog by remember { mutableStateOf(false) }
    var showAddObjQuestionDialog by remember { mutableStateOf(false) }
    var showBulkImportDialog by remember { mutableStateOf(false) }
    var showAddSubQuestionDialog by remember { mutableStateOf(false) }
    var showAddNoticeDialog by remember { mutableStateOf(false) }
    var showChangePasswordDialog by remember { mutableStateOf(false) }

    Scaffold(
        topBar = {
            TargetBoardTopBar(
                title = "एडमिन कंट्रोल रूम: ${currentCourseObj.title}",
                subtitle = "स्वतंत्र पाठ्यक्रम सामग्री प्रबंधन",
                canNavigateBack = true,
                onNavigateBack = { onNavigate(Screen.Home) },
                actions = {
                    IconButton(onClick = { showChangePasswordDialog = true }) {
                        Icon(imageVector = Icons.Default.Key, contentDescription = "Password", tint = Color.White)
                    }
                    IconButton(
                        onClick = {
                            adminViewModel.logout()
                            onNavigate(Screen.Home)
                        }
                    ) {
                        Icon(imageVector = Icons.Default.Logout, contentDescription = "Logout", tint = Color.White)
                    }
                }
            )
        }
    ) { innerPadding ->
        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(innerPadding)
                .background(MaterialTheme.colorScheme.background)
        ) {
            // Status bar
            if (operationStatus != null) {
                Surface(
                    color = EmeraldContainer,
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Row(
                        modifier = Modifier.padding(horizontal = 16.dp, vertical = 8.dp),
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.SpaceBetween
                    ) {
                        Text(
                            text = operationStatus ?: "",
                            style = MaterialTheme.typography.bodySmall.copy(
                                color = EmeraldAccent,
                                fontWeight = FontWeight.Bold
                            )
                        )
                        IconButton(onClick = { adminViewModel.clearStatus() }) {
                            Icon(imageVector = Icons.Default.Close, contentDescription = null, tint = EmeraldAccent, modifier = Modifier.size(16.dp))
                        }
                    }
                }
            }

            // Independent Course Switcher for Admin (Requirement 6)
            Surface(
                color = RoyalBluePrimary,
                modifier = Modifier.fillMaxWidth()
            ) {
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(horizontal = 8.dp, vertical = 6.dp),
                    horizontalArrangement = Arrangement.SpaceAround
                ) {
                    courses.forEach { course ->
                        val isSelected = adminSelectedCourse == course.id
                        FilterChip(
                            selected = isSelected,
                            onClick = { adminViewModel.selectAdminCourse(course.id) },
                            label = {
                                Text(
                                    text = course.title,
                                    fontSize = 12.sp,
                                    fontWeight = if (isSelected) FontWeight.Bold else FontWeight.Normal
                                )
                            },
                            colors = FilterChipDefaults.filterChipColors(
                                selectedContainerColor = BiharBoardGold,
                                selectedLabelColor = RoyalBlueDark,
                                containerColor = Color.White.copy(alpha = 0.15f),
                                labelColor = Color.White
                            )
                        )
                    }
                }
            }

            // Section Tabs for this course
            ScrollableTabRow(
                selectedTabIndex = selectedSectionTab,
                containerColor = MaterialTheme.colorScheme.surface,
                contentColor = RoyalBluePrimary,
                edgePadding = 12.dp
            ) {
                sectionTabs.forEachIndexed { idx, title ->
                    Tab(
                        selected = selectedSectionTab == idx,
                        onClick = { selectedSectionTab = idx },
                        text = {
                            Text(
                                text = title,
                                fontWeight = if (selectedSectionTab == idx) FontWeight.Bold else FontWeight.Normal,
                                fontSize = 13.sp
                            )
                        }
                    )
                }
            }

            // Sub-Panel Content
            when (selectedSectionTab) {
                // Section 0: Subjects Management
                0 -> {
                    LazyColumn(
                        modifier = Modifier
                            .fillMaxSize()
                            .padding(16.dp),
                        verticalArrangement = Arrangement.spacedBy(10.dp)
                    ) {
                        item {
                            Button(
                                onClick = { showAddSubjectDialog = true },
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .height(48.dp)
                                    .testTag("admin_add_subject_btn"),
                                shape = RoundedCornerShape(10.dp),
                                colors = ButtonDefaults.buttonColors(containerColor = RoyalBluePrimary)
                            ) {
                                Icon(imageVector = Icons.Default.Add, contentDescription = null)
                                Spacer(modifier = Modifier.width(8.dp))
                                Text("इस कोर्स में नया विषय जोड़ें (Add Subject)", fontWeight = FontWeight.Bold)
                            }
                        }

                        item {
                            Text(
                                text = "${currentCourseObj.title} के विषय (${subjects.size}):",
                                style = MaterialTheme.typography.titleSmall.copy(fontWeight = FontWeight.Bold)
                            )
                        }

                        items(subjects) { sub ->
                            Card(
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .clickable { onNavigate(Screen.AdminChapterManagement(sub.id, adminSelectedCourse)) }
                                    .testTag("admin_subject_card_${sub.id}"),
                                shape = RoundedCornerShape(12.dp),
                                colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
                                elevation = CardDefaults.cardElevation(defaultElevation = 2.dp)
                            ) {
                                Column(modifier = Modifier.padding(14.dp)) {
                                    Row(
                                        modifier = Modifier.fillMaxWidth(),
                                        verticalAlignment = Alignment.CenterVertically
                                    ) {
                                        Box(
                                            modifier = Modifier
                                                .size(42.dp)
                                                .clip(CircleShape)
                                                .background(RoyalBluePrimary.copy(alpha = 0.12f)),
                                            contentAlignment = Alignment.Center
                                        ) {
                                            Icon(
                                                imageVector = Icons.Default.MenuBook,
                                                contentDescription = null,
                                                tint = RoyalBluePrimary,
                                                modifier = Modifier.size(24.dp)
                                            )
                                        }
                                        Spacer(modifier = Modifier.width(12.dp))
                                        Column(modifier = Modifier.weight(1f)) {
                                            Text(
                                                text = sub.title,
                                                style = MaterialTheme.typography.titleMedium.copy(fontWeight = FontWeight.Bold)
                                            )
                                            Text(
                                                text = sub.hindiTitle,
                                                style = MaterialTheme.typography.bodySmall.copy(color = TextSecondary)
                                            )
                                        }
                                        IconButton(onClick = { adminViewModel.deleteSubject(sub.id) }) {
                                            Icon(
                                                imageVector = Icons.Default.Delete,
                                                contentDescription = "Delete Subject",
                                                tint = Color(0xFFE11D48)
                                            )
                                        }
                                    }

                                    Spacer(modifier = Modifier.height(10.dp))

                                    Button(
                                        onClick = { onNavigate(Screen.AdminChapterManagement(sub.id, adminSelectedCourse)) },
                                        modifier = Modifier
                                            .fillMaxWidth()
                                            .height(40.dp)
                                            .testTag("admin_open_subject_${sub.id}"),
                                        shape = RoundedCornerShape(8.dp),
                                        colors = ButtonDefaults.buttonColors(containerColor = RoyalBluePrimary)
                                    ) {
                                        Icon(imageVector = Icons.Default.FolderOpen, contentDescription = null, modifier = Modifier.size(18.dp))
                                        Spacer(modifier = Modifier.width(8.dp))
                                        Text(
                                            text = "अध्याय व सामग्री प्रबंधन (Manage Chapters)",
                                            fontSize = 12.sp,
                                            fontWeight = FontWeight.Bold
                                        )
                                        Spacer(modifier = Modifier.weight(1f))
                                        Icon(imageVector = Icons.Default.ChevronRight, contentDescription = null, modifier = Modifier.size(18.dp))
                                    }
                                }
                            }
                        }
                    }
                }

                // Section 1: Chapters & Notes Management
                1 -> {
                    LazyColumn(
                        modifier = Modifier
                            .fillMaxSize()
                            .padding(16.dp),
                        verticalArrangement = Arrangement.spacedBy(10.dp)
                    ) {
                        item {
                            Button(
                                onClick = { showAddChapterDialog = true },
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .height(48.dp)
                                    .testTag("admin_add_chapter_btn"),
                                shape = RoundedCornerShape(10.dp),
                                colors = ButtonDefaults.buttonColors(containerColor = RoyalBluePrimary)
                            ) {
                                Icon(imageVector = Icons.Default.Add, contentDescription = null)
                                Spacer(modifier = Modifier.width(8.dp))
                                Text("नया अध्याय व PDF नोट्स जोड़ें", fontWeight = FontWeight.Bold)
                            }
                        }

                        item {
                            Text(
                                text = "${currentCourseObj.title} के अध्याय (${chapters.size}):",
                                style = MaterialTheme.typography.titleSmall.copy(fontWeight = FontWeight.Bold)
                            )
                        }

                        items(chapters) { ch ->
                            Card(
                                modifier = Modifier.fillMaxWidth(),
                                shape = RoundedCornerShape(10.dp),
                                colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface)
                            ) {
                                Row(
                                    modifier = Modifier
                                        .padding(12.dp)
                                        .fillMaxWidth(),
                                    verticalAlignment = Alignment.CenterVertically
                                ) {
                                    Column(modifier = Modifier.weight(1f)) {
                                        Text(
                                            text = "पाठ ${ch.chapterNumber}: ${ch.title}",
                                            style = MaterialTheme.typography.titleSmall.copy(fontWeight = FontWeight.Bold)
                                        )
                                        if (ch.authorName.isNotBlank()) {
                                            Text(text = "लेखक: ${ch.authorName}", style = MaterialTheme.typography.bodySmall.copy(color = TextSecondary))
                                        }
                                        Text(
                                            text = "PDF: ${ch.pdfUrl}",
                                            style = MaterialTheme.typography.labelSmall.copy(color = TextMuted),
                                            maxLines = 1,
                                            overflow = TextOverflow.Ellipsis
                                        )
                                    }
                                    IconButton(onClick = { adminViewModel.deleteChapter(ch.id) }) {
                                        Icon(imageVector = Icons.Default.Delete, contentDescription = "Delete", tint = Color(0xFFE11D48))
                                    }
                                }
                            }
                        }
                    }
                }

                // Section 2: Objective Questions & Bulk Import
                2 -> {
                    LazyColumn(
                        modifier = Modifier
                            .fillMaxSize()
                            .padding(16.dp),
                        verticalArrangement = Arrangement.spacedBy(10.dp)
                    ) {
                        item {
                            Row(
                                modifier = Modifier.fillMaxWidth(),
                                horizontalArrangement = Arrangement.spacedBy(10.dp)
                            ) {
                                Button(
                                    onClick = { showAddObjQuestionDialog = true },
                                    modifier = Modifier
                                        .weight(1f)
                                        .height(48.dp)
                                    ,
                                    shape = RoundedCornerShape(8.dp),
                                    colors = ButtonDefaults.buttonColors(containerColor = EmeraldAccent)
                                ) {
                                    Icon(imageVector = Icons.Default.Add, contentDescription = null)
                                    Spacer(modifier = Modifier.width(6.dp))
                                    Text("प्रश्न जोड़ें (MCQ)", fontSize = 12.sp, fontWeight = FontWeight.Bold)
                                }

                                OutlinedButton(
                                    onClick = { showBulkImportDialog = true },
                                    modifier = Modifier
                                        .weight(1f)
                                        .height(48.dp),
                                    shape = RoundedCornerShape(8.dp)
                                ) {
                                    Icon(imageVector = Icons.Default.FileUpload, contentDescription = null)
                                    Spacer(modifier = Modifier.width(6.dp))
                                    Text("बल्क इम्पोर्ट", fontSize = 12.sp, fontWeight = FontWeight.Bold)
                                }
                            }
                        }

                        item {
                            Card(
                                modifier = Modifier.fillMaxWidth(),
                                shape = RoundedCornerShape(12.dp),
                                colors = CardDefaults.cardColors(containerColor = RoyalBlueContainer)
                            ) {
                                Column(modifier = Modifier.padding(14.dp)) {
                                    Text(
                                        text = "वस्तुनिष्ठ प्रश्न दिशा-निर्देश",
                                        style = MaterialTheme.typography.titleSmall.copy(fontWeight = FontWeight.Bold, color = RoyalBluePrimary)
                                    )
                                    Spacer(modifier = Modifier.height(4.dp))
                                    Text(
                                        text = "प्रत्येक प्रश्न में 4 विकल्प, सही उत्तर, विस्तृत स्पष्टीकरण एवं कठिनाई स्तर (आसान/मध्यम/कठिन) दर्ज किया जा सकता है।",
                                        style = MaterialTheme.typography.bodySmall.copy(color = RoyalBlueDark)
                                    )
                                }
                            }
                        }
                    }
                }

                // Section 3: Subjective Questions
                3 -> {
                    LazyColumn(
                        modifier = Modifier
                            .fillMaxSize()
                            .padding(16.dp),
                        verticalArrangement = Arrangement.spacedBy(10.dp)
                    ) {
                        item {
                            Button(
                                onClick = { showAddSubQuestionDialog = true },
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .height(48.dp),
                                shape = RoundedCornerShape(8.dp),
                                colors = ButtonDefaults.buttonColors(containerColor = RoyalBluePrimary)
                            ) {
                                Icon(imageVector = Icons.Default.Add, contentDescription = null)
                                Spacer(modifier = Modifier.width(8.dp))
                                Text("नया सब्जेक्टिव प्रश्न व उत्तर जोड़ें (2 या 5 अंक)", fontWeight = FontWeight.Bold)
                            }
                        }
                    }
                }

                // Section 4: Announcements
                4 -> {
                    LazyColumn(
                        modifier = Modifier
                            .fillMaxSize()
                            .padding(16.dp),
                        verticalArrangement = Arrangement.spacedBy(10.dp)
                    ) {
                        item {
                            Button(
                                onClick = { showAddNoticeDialog = true },
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .height(48.dp),
                                shape = RoundedCornerShape(8.dp),
                                colors = ButtonDefaults.buttonColors(containerColor = AmberAccent)
                            ) {
                                Icon(imageVector = Icons.Default.Campaign, contentDescription = null)
                                Spacer(modifier = Modifier.width(8.dp))
                                Text("इस कोर्स हेतु नई सूचना प्रकाशित करें", fontWeight = FontWeight.Bold)
                            }
                        }

                        items(announcements) { ann ->
                            Card(
                                modifier = Modifier.fillMaxWidth(),
                                shape = RoundedCornerShape(10.dp),
                                colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface)
                            ) {
                                Row(
                                    modifier = Modifier
                                        .padding(12.dp)
                                        .fillMaxWidth(),
                                    verticalAlignment = Alignment.CenterVertically
                                ) {
                                    Column(modifier = Modifier.weight(1f)) {
                                        Text(text = "[${ann.tag}] ${ann.title}", style = MaterialTheme.typography.titleSmall.copy(fontWeight = FontWeight.Bold))
                                        Text(text = ann.content, style = MaterialTheme.typography.bodySmall.copy(color = TextSecondary), maxLines = 2)
                                    }
                                    IconButton(onClick = { adminViewModel.deleteAnnouncement(ann) }) {
                                        Icon(imageVector = Icons.Default.Delete, contentDescription = null, tint = Color(0xFFE11D48))
                                    }
                                }
                            }
                        }
                    }
                }

                // Section 5: Real-Time Synchronization & Backup Management
                5 -> {
                    LazyColumn(
                        modifier = Modifier
                            .fillMaxSize()
                            .padding(16.dp),
                        verticalArrangement = Arrangement.spacedBy(12.dp)
                    ) {
                        item {
                            Card(
                                modifier = Modifier.fillMaxWidth(),
                                shape = RoundedCornerShape(14.dp),
                                colors = CardDefaults.cardColors(containerColor = EmeraldContainer),
                                border = BorderStroke(1.dp, EmeraldAccent.copy(alpha = 0.5f))
                            ) {
                                Column(modifier = Modifier.padding(16.dp)) {
                                    Row(verticalAlignment = Alignment.CenterVertically) {
                                        Icon(imageVector = Icons.Default.CloudDone, contentDescription = null, tint = EmeraldAccent, modifier = Modifier.size(24.dp))
                                        Spacer(modifier = Modifier.width(10.dp))
                                        Column {
                                            Text(
                                                text = "सामग्री सिंक स्थिति: सक्रिय एवं सुरक्षित",
                                                style = MaterialTheme.typography.titleMedium.copy(fontWeight = FontWeight.Bold, color = EmeraldAccent)
                                            )
                                            Text(
                                                text = "सत्र 2026–2027 • डेटाबेस वर्शन 2.0 (Room Offline-First + Reactive Flow)",
                                                style = MaterialTheme.typography.bodySmall.copy(color = TextSecondary)
                                            )
                                        }
                                    }

                                    Spacer(modifier = Modifier.height(12.dp))
                                    Divider(color = EmeraldAccent.copy(alpha = 0.3f))
                                    Spacer(modifier = Modifier.height(12.dp))

                                    Text(
                                        text = "• सभी प्रकाशित सामग्री छात्र ऐप में बिना इंटरनेट रुकावट के तुरंत सिंक होती है।\n• छात्रों के ऐप में स्वचालित कैशिंग के कारण सभी डाउनलोड किए गए नोट्स ऑफलाइन सुरक्षित रहते हैं।\n• पाठ्यक्रम विभाजन (Class 10th, 12th Arts, 12th Science) पूर्णतः पृथक एवं सुरक्षित है।",
                                        style = MaterialTheme.typography.bodySmall.copy(color = MaterialTheme.colorScheme.onSurface, lineHeight = 20.sp)
                                    )

                                    Spacer(modifier = Modifier.height(14.dp))

                                    Button(
                                        onClick = {
                                            adminViewModel.clearStatus()
                                            // Trigger manual resync notification
                                            adminViewModel.saveAnnouncement(
                                                title = "सिंक सूचना",
                                                content = "नया अध्ययन सामग्री पैकेज सफलतापूर्वक छात्रों के उपकरणों में सिंक्रनाइज़ हो गया है।",
                                                isImportant = true,
                                                tag = "UPDATE",
                                                courseId = adminSelectedCourse
                                            )
                                        },
                                        modifier = Modifier.fillMaxWidth(),
                                        colors = ButtonDefaults.buttonColors(containerColor = EmeraldAccent),
                                        shape = RoundedCornerShape(8.dp)
                                    ) {
                                        Icon(imageVector = Icons.Default.Sync, contentDescription = null)
                                        Spacer(modifier = Modifier.width(8.dp))
                                        Text("छात्रों के लिए तत्काल सिंक ट्रिगर करें (Force Sync All)", fontWeight = FontWeight.Bold)
                                    }

                                    Spacer(modifier = Modifier.height(10.dp))

                                    OutlinedButton(
                                        onClick = {
                                            adminViewModel.clearStatus()
                                            adminViewModel.repository.firebaseSync.startRealtimeSync(adminSelectedCourse)
                                        },
                                        modifier = Modifier.fillMaxWidth(),
                                        shape = RoundedCornerShape(8.dp),
                                        border = BorderStroke(1.dp, EmeraldAccent)
                                    ) {
                                        Icon(imageVector = Icons.Default.CloudUpload, contentDescription = null, tint = EmeraldAccent)
                                        Spacer(modifier = Modifier.width(8.dp))
                                        Text("क्लाउड Firestore से पुनः समन्वय करें (Sync with Cloud)", color = EmeraldAccent, fontWeight = FontWeight.Bold)
                                    }
                                }
                            }
                        }

                        item {
                            Card(
                                modifier = Modifier.fillMaxWidth(),
                                shape = RoundedCornerShape(12.dp),
                                colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
                                elevation = CardDefaults.cardElevation(defaultElevation = 2.dp)
                            ) {
                                Column(modifier = Modifier.padding(16.dp)) {
                                    Text(
                                        text = "पाठ्यक्रम आंकड़े (${currentCourseObj.title})",
                                        style = MaterialTheme.typography.titleMedium.copy(fontWeight = FontWeight.Bold, color = RoyalBlueDark)
                                    )
                                    Spacer(modifier = Modifier.height(8.dp))
                                    Row(
                                        modifier = Modifier.fillMaxWidth(),
                                        horizontalArrangement = Arrangement.SpaceBetween
                                    ) {
                                        Column {
                                            Text("कुल विषय: ${subjects.size}", style = MaterialTheme.typography.bodyMedium.copy(fontWeight = FontWeight.SemiBold))
                                            Text("कुल अध्याय: ${chapters.size}", style = MaterialTheme.typography.bodyMedium.copy(fontWeight = FontWeight.SemiBold))
                                        }
                                        Column {
                                            Text("प्रकाशित: ${chapters.count { it.isPublished }}", style = MaterialTheme.typography.bodyMedium.copy(color = EmeraldAccent, fontWeight = FontWeight.Bold))
                                            Text("ड्राफ्ट (अप्रकाशित): ${chapters.count { !it.isPublished }}", style = MaterialTheme.typography.bodyMedium.copy(color = AmberAccent, fontWeight = FontWeight.Bold))
                                        }
                                    }
                                }
                            }
                        }
                    }
                }
            }
        }

        // Dialog: Add Subject
        if (showAddSubjectDialog) {
            var subTitle by remember { mutableStateOf("") }
            var subHindiTitle by remember { mutableStateOf("") }
            var iconName by remember { mutableStateOf("book") }

            AlertDialog(
                onDismissRequest = { showAddSubjectDialog = false },
                title = { Text("नया विषय जोड़ें (${currentCourseObj.title})", fontWeight = FontWeight.Bold) },
                text = {
                    Column {
                        OutlinedTextField(
                            value = subTitle,
                            onValueChange = { subTitle = it },
                            label = { Text("विषय का नाम (Title)") },
                            modifier = Modifier.fillMaxWidth()
                        )
                        Spacer(modifier = Modifier.height(8.dp))
                        OutlinedTextField(
                            value = subHindiTitle,
                            onValueChange = { subHindiTitle = it },
                            label = { Text("हिंदी शीर्षक (जैसे: भौतिक विज्ञान)") },
                            modifier = Modifier.fillMaxWidth()
                        )
                    }
                },
                confirmButton = {
                    Button(
                        onClick = {
                            if (subTitle.isNotBlank()) {
                                adminViewModel.saveSubject(
                                    id = null,
                                    courseId = adminSelectedCourse,
                                    title = subTitle,
                                    hindiTitle = subHindiTitle.ifBlank { subTitle },
                                    chapterCount = 1,
                                    iconName = iconName,
                                    colorHex = 0xFF1E3A8A
                                )
                                showAddSubjectDialog = false
                            }
                        }
                    ) { Text("सहेजें") }
                },
                dismissButton = {
                    TextButton(onClick = { showAddSubjectDialog = false }) { Text("रद्द करें") }
                }
            )
        }

        // Dialog: Add Chapter
        if (showAddChapterDialog) {
            var chTitle by remember { mutableStateOf("") }
            var chAuthor by remember { mutableStateOf("") }
            var chExplanation by remember { mutableStateOf("") }
            var chNumber by remember { mutableStateOf("1") }
            var chPdfUrl by remember { mutableStateOf("") }
            var selectedSubId by remember { mutableStateOf(subjects.firstOrNull()?.id ?: "") }

            AlertDialog(
                onDismissRequest = { showAddChapterDialog = false },
                title = { Text("नया अध्याय जोड़ें", fontWeight = FontWeight.Bold) },
                text = {
                    Column(modifier = Modifier.verticalScroll(rememberScrollState())) {
                        Text("संबद्ध विषय:", style = MaterialTheme.typography.labelSmall.copy(color = TextSecondary))
                        // Subject selector
                        subjects.forEach { s ->
                            Row(
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .clickable { selectedSubId = s.id }
                                    .padding(vertical = 2.dp),
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                RadioButton(selected = selectedSubId == s.id, onClick = { selectedSubId = s.id })
                                Text(s.title, fontSize = 13.sp)
                            }
                        }
                        Spacer(modifier = Modifier.height(8.dp))
                        OutlinedTextField(value = chNumber, onValueChange = { chNumber = it }, label = { Text("अध्याय क्रमांक") }, modifier = Modifier.fillMaxWidth(), keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number))
                        Spacer(modifier = Modifier.height(6.dp))
                        OutlinedTextField(value = chTitle, onValueChange = { chTitle = it }, label = { Text("अध्याय शीर्षक") }, modifier = Modifier.fillMaxWidth())
                        Spacer(modifier = Modifier.height(6.dp))
                        OutlinedTextField(value = chAuthor, onValueChange = { chAuthor = it }, label = { Text("लेखक का नाम") }, modifier = Modifier.fillMaxWidth())
                        Spacer(modifier = Modifier.height(6.dp))
                        OutlinedTextField(value = chPdfUrl, onValueChange = { chPdfUrl = it }, label = { Text("PDF नोट्स URL (वैकल्पिक)") }, modifier = Modifier.fillMaxWidth())
                        Spacer(modifier = Modifier.height(6.dp))
                        OutlinedTextField(value = chExplanation, onValueChange = { chExplanation = it }, label = { Text("अध्याय सारांश") }, modifier = Modifier.fillMaxWidth(), minLines = 2)
                    }
                },
                confirmButton = {
                    Button(
                        onClick = {
                            if (chTitle.isNotBlank()) {
                                adminViewModel.saveChapter(
                                    id = null,
                                    subjectId = selectedSubId.ifBlank { subjects.firstOrNull()?.id ?: "sub" },
                                    courseId = adminSelectedCourse,
                                    chapterNumber = chNumber.toIntOrNull() ?: 1,
                                    title = chTitle,
                                    hindiTitle = "पाठ $chNumber: $chTitle",
                                    authorName = chAuthor,
                                    authorIntro = "लेखक परिचय।",
                                    authorLifeHistory = "विस्तृत जीवन परिचय।",
                                    explanation = chExplanation.ifBlank { "इस अध्याय की सम्पूर्ण व्याख्या।" },
                                    importantPoints = listOf("मुख्य परीक्षा उपयोगी बिंदु।"),
                                    definitions = listOf("मुख्य परिभाषाएं एवं सूत्र।"),
                                    pdfUrl = chPdfUrl
                                )
                                showAddChapterDialog = false
                            }
                        }
                    ) { Text("सहेजें") }
                },
                dismissButton = {
                    TextButton(onClick = { showAddChapterDialog = false }) { Text("रद्द करें") }
                }
            )
        }

        // Dialog: Add Objective Question
        if (showAddObjQuestionDialog) {
            var qText by remember { mutableStateOf("") }
            var optA by remember { mutableStateOf("") }
            var optB by remember { mutableStateOf("") }
            var optC by remember { mutableStateOf("") }
            var optD by remember { mutableStateOf("") }
            var correctOpt by remember { mutableStateOf("1") }
            var explanation by remember { mutableStateOf("") }
            var difficulty by remember { mutableStateOf("मध्यम") }
            val chId = chapters.firstOrNull()?.id ?: "ch"
            val sbId = subjects.firstOrNull()?.id ?: "sub"

            AlertDialog(
                onDismissRequest = { showAddObjQuestionDialog = false },
                title = { Text("वस्तुनिष्ठ प्रश्न जोड़ें", fontWeight = FontWeight.Bold) },
                text = {
                    Column(modifier = Modifier.verticalScroll(rememberScrollState())) {
                        OutlinedTextField(value = qText, onValueChange = { qText = it }, label = { Text("प्रश्न लिखें...") }, modifier = Modifier.fillMaxWidth())
                        Spacer(modifier = Modifier.height(6.dp))
                        OutlinedTextField(value = optA, onValueChange = { optA = it }, label = { Text("विकल्प (A)") }, modifier = Modifier.fillMaxWidth())
                        OutlinedTextField(value = optB, onValueChange = { optB = it }, label = { Text("विकल्प (B)") }, modifier = Modifier.fillMaxWidth())
                        OutlinedTextField(value = optC, onValueChange = { optC = it }, label = { Text("विकल्प (C)") }, modifier = Modifier.fillMaxWidth())
                        OutlinedTextField(value = optD, onValueChange = { optD = it }, label = { Text("विकल्प (D)") }, modifier = Modifier.fillMaxWidth())
                        Spacer(modifier = Modifier.height(6.dp))
                        OutlinedTextField(value = correctOpt, onValueChange = { correctOpt = it }, label = { Text("सही उत्तर (1=A, 2=B, 3=C, 4=D)") }, modifier = Modifier.fillMaxWidth(), keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number))
                        Spacer(modifier = Modifier.height(6.dp))
                        OutlinedTextField(value = explanation, onValueChange = { explanation = it }, label = { Text("उत्तर स्पष्टीकरण") }, modifier = Modifier.fillMaxWidth())
                    }
                },
                confirmButton = {
                    Button(
                        onClick = {
                            if (qText.isNotBlank() && optA.isNotBlank()) {
                                adminViewModel.saveObjectiveQuestion(
                                    chapterId = chId,
                                    subjectId = sbId,
                                    courseId = adminSelectedCourse,
                                    questionText = qText,
                                    optionA = optA,
                                    optionB = optB,
                                    optionC = optC,
                                    optionD = optD,
                                    correctOption = correctOpt.toIntOrNull() ?: 1,
                                    explanation = explanation,
                                    marks = 1,
                                    difficulty = difficulty,
                                    isPreviousYear = true,
                                    examYear = "2024"
                                )
                                showAddObjQuestionDialog = false
                            }
                        }
                    ) { Text("जोड़ें") }
                },
                dismissButton = {
                    TextButton(onClick = { showAddObjQuestionDialog = false }) { Text("रद्द करें") }
                }
            )
        }

        // Dialog: Bulk Import Questions
        if (showBulkImportDialog) {
            var rawText by remember {
                mutableStateOf(
                    "Q: प्रकाश का वेग निर्वात में कितना होता है?\nA: 3 x 10^8 m/s\nB: 3 x 10^6 m/s\nC: 3 x 10^5 km/s\nD: शून्य\nAns: 1\nExp: निर्वात में प्रकाश की चाल 3 × 10⁸ m/s होती है।"
                )
            }
            val chId = chapters.firstOrNull()?.id ?: "ch"
            val sbId = subjects.firstOrNull()?.id ?: "sub"

            AlertDialog(
                onDismissRequest = { showBulkImportDialog = false },
                title = { Text("बल्क प्रश्न इम्पोर्ट (Bulk Import)", fontWeight = FontWeight.Bold) },
                text = {
                    Column {
                        Text(
                            text = "नीचे दिए गए प्रारूप में प्रश्न पेस्ट करें (Q:, A:, B:, C:, D:, Ans: [1-4], Exp:)",
                            style = MaterialTheme.typography.bodySmall.copy(color = TextSecondary)
                        )
                        Spacer(modifier = Modifier.height(8.dp))
                        OutlinedTextField(
                            value = rawText,
                            onValueChange = { rawText = it },
                            modifier = Modifier
                                .fillMaxWidth()
                                .height(200.dp),
                            minLines = 8
                        )
                    }
                },
                confirmButton = {
                    Button(
                        onClick = {
                            adminViewModel.bulkImportObjectiveQuestions(
                                courseId = adminSelectedCourse,
                                subjectId = sbId,
                                chapterId = chId,
                                rawText = rawText
                            )
                            showBulkImportDialog = false
                        }
                    ) { Text("इम्पोर्ट करें") }
                },
                dismissButton = {
                    TextButton(onClick = { showBulkImportDialog = false }) { Text("रद्द करें") }
                }
            )
        }

        // Dialog: Add Subjective Question
        if (showAddSubQuestionDialog) {
            var qText by remember { mutableStateOf("") }
            var ansText by remember { mutableStateOf("") }
            var marks by remember { mutableStateOf("2") }
            val chId = chapters.firstOrNull()?.id ?: "ch"
            val sbId = subjects.firstOrNull()?.id ?: "sub"

            AlertDialog(
                onDismissRequest = { showAddSubQuestionDialog = false },
                title = { Text("सब्जेक्टिव प्रश्न जोड़ें", fontWeight = FontWeight.Bold) },
                text = {
                    Column(modifier = Modifier.verticalScroll(rememberScrollState())) {
                        OutlinedTextField(value = qText, onValueChange = { qText = it }, label = { Text("प्रश्न") }, modifier = Modifier.fillMaxWidth())
                        Spacer(modifier = Modifier.height(6.dp))
                        OutlinedTextField(value = ansText, onValueChange = { ansText = it }, label = { Text("विस्तृत उत्तर") }, modifier = Modifier.fillMaxWidth(), minLines = 3)
                        Spacer(modifier = Modifier.height(6.dp))
                        OutlinedTextField(value = marks, onValueChange = { marks = it }, label = { Text("अंक (2 या 5)") }, modifier = Modifier.fillMaxWidth(), keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number))
                    }
                },
                confirmButton = {
                    Button(
                        onClick = {
                            if (qText.isNotBlank() && ansText.isNotBlank()) {
                                val m = marks.toIntOrNull() ?: 2
                                adminViewModel.saveSubjectiveQuestion(
                                    chapterId = chId,
                                    subjectId = sbId,
                                    courseId = adminSelectedCourse,
                                    questionText = qText,
                                    answerText = ansText,
                                    marks = m,
                                    questionType = if (m == 5) "LONG" else "SHORT",
                                    isImportant = true,
                                    isPreviousYear = true,
                                    examYear = "2024"
                                )
                                showAddSubQuestionDialog = false
                            }
                        }
                    ) { Text("सहेजें") }
                },
                dismissButton = {
                    TextButton(onClick = { showAddSubQuestionDialog = false }) { Text("रद्द करें") }
                }
            )
        }

        // Dialog: Add Notice
        if (showAddNoticeDialog) {
            var nTitle by remember { mutableStateOf("") }
            var nContent by remember { mutableStateOf("") }
            var nTag by remember { mutableStateOf("सूचना") }

            AlertDialog(
                onDismissRequest = { showAddNoticeDialog = false },
                title = { Text("सूचना प्रकाशित करें", fontWeight = FontWeight.Bold) },
                text = {
                    Column {
                        OutlinedTextField(value = nTitle, onValueChange = { nTitle = it }, label = { Text("शीर्षक") }, modifier = Modifier.fillMaxWidth())
                        Spacer(modifier = Modifier.height(6.dp))
                        OutlinedTextField(value = nTag, onValueChange = { nTag = it }, label = { Text("टैग") }, modifier = Modifier.fillMaxWidth())
                        Spacer(modifier = Modifier.height(6.dp))
                        OutlinedTextField(value = nContent, onValueChange = { nContent = it }, label = { Text("विवरण") }, modifier = Modifier.fillMaxWidth(), minLines = 3)
                    }
                },
                confirmButton = {
                    Button(
                        onClick = {
                            if (nTitle.isNotBlank() && nContent.isNotBlank()) {
                                adminViewModel.saveAnnouncement(
                                    title = nTitle,
                                    content = nContent,
                                    isImportant = true,
                                    tag = nTag,
                                    courseId = adminSelectedCourse
                                )
                                showAddNoticeDialog = false
                            }
                        }
                    ) { Text("प्रकाशित करें") }
                },
                dismissButton = {
                    TextButton(onClick = { showAddNoticeDialog = false }) { Text("रद्द करें") }
                }
            )
        }

        // Dialog: Change Password
        if (showChangePasswordDialog) {
            var newPass by remember { mutableStateOf("") }

            AlertDialog(
                onDismissRequest = { showChangePasswordDialog = false },
                title = { Text("एडमिन पासवर्ड बदलें", fontWeight = FontWeight.Bold) },
                text = {
                    Column {
                        Text("सुरक्षित नया पासवर्ड दर्ज करें:", style = MaterialTheme.typography.bodySmall.copy(color = TextSecondary))
                        Spacer(modifier = Modifier.height(8.dp))
                        OutlinedTextField(
                            value = newPass,
                            onValueChange = { newPass = it },
                            label = { Text("नया पासवर्ड (कम से कम 6 अक्षर)") },
                            visualTransformation = PasswordVisualTransformation(),
                            modifier = Modifier.fillMaxWidth(),
                            singleLine = true
                        )
                    }
                },
                confirmButton = {
                    Button(
                        onClick = {
                            if (adminViewModel.changePassword(newPass)) {
                                showChangePasswordDialog = false
                            }
                        }
                    ) { Text("अपडेट करें") }
                },
                dismissButton = {
                    TextButton(onClick = { showChangePasswordDialog = false }) { Text("रद्द करें") }
                }
            )
        }
    }
}
