package com.example.ui.screens

import androidx.compose.animation.*
import androidx.compose.foundation.*
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.lazy.itemsIndexed
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.data.model.*
import com.example.data.repository.SeedData
import com.example.ui.components.*
import com.example.ui.navigation.Screen
import com.example.ui.theme.*
import com.example.ui.viewmodel.MainViewModel
import kotlinx.coroutines.delay

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun MockTestListScreen(
    viewModel: MainViewModel,
    onNavigate: (Screen) -> Unit
) {
    val allTests by viewModel.allMockTests.collectAsState()
    val selectedCourseId by viewModel.selectedCourseId.collectAsState()
    val courses = viewModel.repository.getAllCourses()

    Scaffold(
        topBar = {
            TargetBoardTopBar(
                title = "ऑनलाइन मॉक टेस्ट सीरीज़",
                subtitle = "समयबद्ध परीक्षा • नवीनतम बिहार बोर्ड पैटर्न",
                canNavigateBack = true,
                onNavigateBack = { onNavigate(Screen.Home) }
            )
        },
        bottomBar = {
            TargetBoardBottomBar(
                currentRoute = Screen.MockTestList.route,
                onNavigate = onNavigate
            )
        }
    ) { innerPadding ->
        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(innerPadding)
                .background(MaterialTheme.colorScheme.background)
        ) {
            // Course Filter Tabs
            ScrollableTabRow(
                selectedTabIndex = courses.indexOfFirst { it.id == selectedCourseId }.coerceAtLeast(0),
                containerColor = MaterialTheme.colorScheme.surface,
                contentColor = RoyalBluePrimary,
                edgePadding = 16.dp
            ) {
                courses.forEach { course ->
                    val isSelected = course.id == selectedCourseId
                    Tab(
                        selected = isSelected,
                        onClick = { viewModel.selectCourse(course.id) },
                        text = {
                            Text(
                                text = course.title,
                                fontWeight = if (isSelected) FontWeight.Bold else FontWeight.Normal,
                                fontSize = 13.sp
                            )
                        }
                    )
                }
            }

            LazyColumn(
                modifier = Modifier
                    .fillMaxSize()
                    .padding(16.dp),
                verticalArrangement = Arrangement.spacedBy(12.dp)
            ) {
                // Info Banner
                item {
                    Card(
                        modifier = Modifier.fillMaxWidth(),
                        shape = RoundedCornerShape(12.dp),
                        colors = CardDefaults.cardColors(containerColor = RoyalBlueContainer)
                    ) {
                        Row(
                            modifier = Modifier.padding(14.dp),
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Icon(
                                imageVector = Icons.Default.Timer,
                                contentDescription = null,
                                tint = RoyalBluePrimary,
                                modifier = Modifier.size(32.dp)
                            )
                            Spacer(modifier = Modifier.width(12.dp))
                            Column {
                                Text(
                                    text = "लाइव टाइमर युक्त मॉक टेस्ट",
                                    style = MaterialTheme.typography.titleMedium.copy(
                                        fontWeight = FontWeight.Bold,
                                        color = RoyalBluePrimary
                                    )
                                )
                                Text(
                                    text = "समय समाप्त होने पर स्वतः जमा होगा • तुरंत स्कोर व विस्तृत समाधान देखें",
                                    style = MaterialTheme.typography.bodySmall.copy(color = RoyalBlueDark)
                                )
                            }
                        }
                    }
                }

                item {
                    Text(
                        text = "उपलब्ध टेस्ट पेपर",
                        style = MaterialTheme.typography.titleMedium.copy(
                            fontWeight = FontWeight.Bold,
                            color = MaterialTheme.colorScheme.onBackground
                        )
                    )
                }

                val testsToShow = allTests.ifEmpty {
                    SeedData.getInitialMockTests().map {
                        MockTest(it.id, it.courseId, it.subjectId, it.title, it.description, it.durationMinutes, it.totalMarks, it.totalQuestions, it.passMarks)
                    }
                }

                items(testsToShow) { test ->
                    Card(
                        modifier = Modifier
                            .fillMaxWidth()
                            .testTag("mock_test_card_${test.id}"),
                        shape = RoundedCornerShape(14.dp),
                        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
                        elevation = CardDefaults.cardElevation(defaultElevation = 2.dp)
                    ) {
                        Column(modifier = Modifier.padding(16.dp)) {
                            Row(
                                modifier = Modifier.fillMaxWidth(),
                                horizontalArrangement = Arrangement.SpaceBetween,
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                Surface(
                                    shape = RoundedCornerShape(6.dp),
                                    color = EmeraldContainer
                                ) {
                                    Text(
                                        text = "नि:शुल्क ऑनलाइन टेस्ट",
                                        modifier = Modifier.padding(horizontal = 6.dp, vertical = 2.dp),
                                        style = MaterialTheme.typography.labelSmall.copy(
                                            color = EmeraldAccent,
                                            fontWeight = FontWeight.Bold
                                        )
                                    )
                                }

                                Row(verticalAlignment = Alignment.CenterVertically) {
                                    Icon(
                                        imageVector = Icons.Default.Schedule,
                                        contentDescription = null,
                                        tint = AmberAccent,
                                        modifier = Modifier.size(16.dp)
                                    )
                                    Spacer(modifier = Modifier.width(4.dp))
                                    Text(
                                        text = "${test.durationMinutes} मिनट",
                                        style = MaterialTheme.typography.labelSmall.copy(
                                            fontWeight = FontWeight.Bold,
                                            color = AmberAccent
                                        )
                                    )
                                }
                            }

                            Spacer(modifier = Modifier.height(10.dp))

                            Text(
                                text = test.title,
                                style = MaterialTheme.typography.titleMedium.copy(
                                    fontWeight = FontWeight.Bold,
                                    color = MaterialTheme.colorScheme.onSurface
                                )
                            )

                            Spacer(modifier = Modifier.height(4.dp))

                            Text(
                                text = test.description,
                                style = MaterialTheme.typography.bodySmall.copy(color = TextSecondary)
                            )

                            Spacer(modifier = Modifier.height(12.dp))

                            Row(
                                modifier = Modifier.fillMaxWidth(),
                                horizontalArrangement = Arrangement.SpaceBetween,
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                Row(horizontalArrangement = Arrangement.spacedBy(12.dp)) {
                                    Text(
                                        text = "कुल अंक: ${test.totalMarks}",
                                        style = MaterialTheme.typography.labelSmall.copy(
                                            fontWeight = FontWeight.SemiBold,
                                            color = TextSecondary
                                        )
                                    )
                                    Text(
                                        text = "उत्तीर्णांक: ${test.passMarks}",
                                        style = MaterialTheme.typography.labelSmall.copy(
                                            fontWeight = FontWeight.SemiBold,
                                            color = TextSecondary
                                        )
                                    )
                                }

                                Button(
                                    onClick = { onNavigate(Screen.MockTestRunning(test.id)) },
                                    shape = RoundedCornerShape(8.dp),
                                    colors = ButtonDefaults.buttonColors(containerColor = RoyalBluePrimary),
                                    modifier = Modifier.testTag("start_test_btn_${test.id}")
                                ) {
                                    Text("टेस्ट शुरू करें ➔", fontWeight = FontWeight.Bold)
                                }
                            }
                        }
                    }
                }
            }
        }
    }
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun MockTestRunningScreen(
    testId: String,
    viewModel: MainViewModel,
    onNavigate: (Screen) -> Unit
) {
    var test by remember { mutableStateOf<MockTest?>(null) }
    var questions by remember { mutableStateOf<List<ObjectiveQuestion>>(emptyList()) }
    var currentQuestionIndex by remember { mutableStateOf(0) }
    val userAnswers = remember { mutableStateMapOf<String, Int>() }
    var timeLeftSeconds by remember { mutableStateOf(1800L) } // default 30 min
    var showSubmitConfirmDialog by remember { mutableStateOf(false) }

    LaunchedEffect(testId) {
        val initialSeed = SeedData.getInitialMockTests().find { it.id == testId }?.let {
            MockTest(it.id, it.courseId, it.subjectId, it.title, it.description, it.durationMinutes, it.totalMarks, it.totalQuestions, it.passMarks)
        }
        val foundTest = viewModel.repository.getMockTestById(testId) ?: initialSeed
        test = foundTest
        if (foundTest != null) {
            timeLeftSeconds = foundTest.durationMinutes * 60L
            val qList = viewModel.repository.getObjectiveQuestionsForSubject(foundTest.subjectId)
            questions = if (qList.isNotEmpty()) qList else viewModel.repository.getRandomObjectiveQuestionsByCourse(foundTest.courseId, 10)
        }
    }

    // Countdown Timer with Auto-Submit
    LaunchedEffect(timeLeftSeconds) {
        if (timeLeftSeconds > 0) {
            delay(1000L)
            timeLeftSeconds -= 1
        } else if (test != null && questions.isNotEmpty()) {
            // Auto submit when time ends
            val totalTime = test!!.durationMinutes * 60L
            viewModel.submitMockTest(test!!, questions, userAnswers.toMap(), totalTime)
            onNavigate(Screen.MockTestList) // Will navigate to result view
        }
    }

    val minutes = timeLeftSeconds / 60
    val seconds = timeLeftSeconds % 60
    val timeFormatted = String.format("%02d:%02d", minutes, seconds)

    Scaffold(
        topBar = {
            TopAppBar(
                title = {
                    Column {
                        Text(
                            text = test?.title ?: "मॉक टेस्ट",
                            style = MaterialTheme.typography.titleSmall.copy(
                                color = Color.White,
                                fontWeight = FontWeight.Bold
                            ),
                            maxLines = 1
                        )
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Icon(
                                imageVector = Icons.Default.Timer,
                                contentDescription = null,
                                tint = if (timeLeftSeconds < 300) Color.Red else BiharBoardGold,
                                modifier = Modifier.size(14.dp)
                            )
                            Spacer(modifier = Modifier.width(4.dp))
                            Text(
                                text = "शेष समय: $timeFormatted",
                                style = MaterialTheme.typography.labelSmall.copy(
                                    color = if (timeLeftSeconds < 300) Color.Red else BiharBoardGold,
                                    fontWeight = FontWeight.Bold
                                )
                            )
                        }
                    }
                },
                navigationIcon = {
                    IconButton(onClick = { showSubmitConfirmDialog = true }) {
                        Icon(imageVector = Icons.Default.Close, contentDescription = "Close", tint = Color.White)
                    }
                },
                actions = {
                    Button(
                        onClick = { showSubmitConfirmDialog = true },
                        colors = ButtonDefaults.buttonColors(containerColor = EmeraldAccent),
                        shape = RoundedCornerShape(8.dp),
                        modifier = Modifier
                            .padding(end = 8.dp)
                            .testTag("submit_test_top_action")
                    ) {
                        Text("सबमिट करें", fontWeight = FontWeight.Bold, fontSize = 12.sp)
                    }
                },
                colors = TopAppBarDefaults.topAppBarColors(containerColor = RoyalBluePrimary)
            )
        }
    ) { innerPadding ->
        if (test == null || questions.isEmpty()) {
            Box(
                modifier = Modifier
                    .fillMaxSize()
                    .padding(innerPadding),
                contentAlignment = Alignment.Center
            ) {
                CircularProgressIndicator(color = RoyalBluePrimary)
            }
        } else {
            val q = questions[currentQuestionIndex]
            val selectedOption = userAnswers[q.id] ?: 0

            Column(
                modifier = Modifier
                    .fillMaxSize()
                    .padding(innerPadding)
                    .background(MaterialTheme.colorScheme.background)
            ) {
                // Question Palette (1, 2, 3... circle indicators)
                LazyRow(
                    modifier = Modifier
                        .fillMaxWidth()
                        .background(MaterialTheme.colorScheme.surface)
                        .padding(horizontal = 12.dp, vertical = 8.dp),
                    horizontalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    itemsIndexed(questions) { idx, item ->
                        val isAnswered = userAnswers.containsKey(item.id)
                        val isCurrent = idx == currentQuestionIndex

                        Box(
                            modifier = Modifier
                                .size(34.dp)
                                .clip(CircleShape)
                                .background(
                                    when {
                                        isCurrent -> RoyalBluePrimary
                                        isAnswered -> EmeraldAccent
                                        else -> SurfaceVariantLight
                                    }
                                )
                                .border(
                                    width = if (isCurrent) 2.dp else 1.dp,
                                    color = if (isCurrent) BiharBoardGold else OutlineLight,
                                    shape = CircleShape
                                )
                                .clickable { currentQuestionIndex = idx },
                            contentAlignment = Alignment.Center
                        ) {
                            Text(
                                text = "${idx + 1}",
                                style = MaterialTheme.typography.labelSmall.copy(
                                    fontWeight = FontWeight.Bold,
                                    color = if (isCurrent || isAnswered) Color.White else TextPrimary
                                )
                            )
                        }
                    }
                }

                // Question Body
                LazyColumn(
                    modifier = Modifier
                        .fillMaxSize()
                        .weight(1f)
                        .padding(16.dp),
                    verticalArrangement = Arrangement.spacedBy(14.dp)
                ) {
                    item {
                        Card(
                            modifier = Modifier.fillMaxWidth(),
                            shape = RoundedCornerShape(14.dp),
                            colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
                            elevation = CardDefaults.cardElevation(defaultElevation = 2.dp)
                        ) {
                            Column(modifier = Modifier.padding(16.dp)) {
                                Text(
                                    text = "प्रश्न ${currentQuestionIndex + 1} / ${questions.size}",
                                    style = MaterialTheme.typography.labelMedium.copy(
                                        color = RoyalBluePrimary,
                                        fontWeight = FontWeight.Bold
                                    )
                                )
                                Spacer(modifier = Modifier.height(8.dp))
                                Text(
                                    text = q.questionText,
                                    style = MaterialTheme.typography.titleMedium.copy(
                                        fontWeight = FontWeight.Bold,
                                        color = RoyalBlueDark,
                                        lineHeight = 24.sp
                                    )
                                )
                            }
                        }
                    }

                    val options = listOf(
                        1 to q.optionA,
                        2 to q.optionB,
                        3 to q.optionC,
                        4 to q.optionD
                    )

                    items(options.size) { optIdx ->
                        val (optNum, optText) = options[optIdx]
                        val isSelected = selectedOption == optNum

                        Surface(
                            modifier = Modifier
                                .fillMaxWidth()
                                .clickable { userAnswers[q.id] = optNum },
                            shape = RoundedCornerShape(12.dp),
                            color = if (isSelected) RoyalBlueContainer else MaterialTheme.colorScheme.surface,
                            border = BorderStroke(1.5.dp, if (isSelected) RoyalBluePrimary else OutlineLight)
                        ) {
                            Row(
                                modifier = Modifier.padding(14.dp),
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                RadioButton(
                                    selected = isSelected,
                                    onClick = { userAnswers[q.id] = optNum },
                                    colors = RadioButtonDefaults.colors(selectedColor = RoyalBluePrimary)
                                )
                                Spacer(modifier = Modifier.width(8.dp))
                                Text(
                                    text = optText,
                                    style = MaterialTheme.typography.bodyMedium.copy(
                                        fontWeight = if (isSelected) FontWeight.Bold else FontWeight.Normal,
                                        color = if (isSelected) RoyalBluePrimary else MaterialTheme.colorScheme.onSurface
                                    )
                                )
                            }
                        }
                    }

                    // Clear option button
                    if (selectedOption != 0) {
                        item {
                            TextButton(
                                onClick = { userAnswers.remove(q.id) },
                                modifier = Modifier.align(Alignment.End)
                            ) {
                                Icon(imageVector = Icons.Default.Clear, contentDescription = null, tint = TextMuted)
                                Spacer(modifier = Modifier.width(4.dp))
                                Text("उत्तर मिटाएं (Clear Answer)", color = TextMuted)
                            }
                        }
                    }
                }

                // Bottom Navigation Bar for Questions
                Surface(
                    color = MaterialTheme.colorScheme.surface,
                    tonalElevation = 6.dp
                ) {
                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(16.dp),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        OutlinedButton(
                            onClick = { if (currentQuestionIndex > 0) currentQuestionIndex-- },
                            enabled = currentQuestionIndex > 0,
                            shape = RoundedCornerShape(8.dp)
                        ) {
                            Text("◀ पिछला")
                        }

                        if (currentQuestionIndex + 1 < questions.size) {
                            Button(
                                onClick = { currentQuestionIndex++ },
                                shape = RoundedCornerShape(8.dp),
                                colors = ButtonDefaults.buttonColors(containerColor = RoyalBluePrimary)
                            ) {
                                Text("अगला ▶")
                            }
                        } else {
                            Button(
                                onClick = { showSubmitConfirmDialog = true },
                                shape = RoundedCornerShape(8.dp),
                                colors = ButtonDefaults.buttonColors(containerColor = EmeraldAccent),
                                modifier = Modifier.testTag("submit_mock_test_final_btn")
                            ) {
                                Text("फाइनल सबमिट 🏆", fontWeight = FontWeight.Bold)
                            }
                        }
                    }
                }
            }

            // Submit Confirmation Dialog
            if (showSubmitConfirmDialog) {
                val attemptedCount = userAnswers.size
                val unattemptedCount = questions.size - attemptedCount

                AlertDialog(
                    onDismissRequest = { showSubmitConfirmDialog = false },
                    title = { Text("टेस्ट सबमिट करें?", fontWeight = FontWeight.Bold) },
                    text = {
                        Column {
                            Text("कुल प्रश्न: ${questions.size}")
                            Text("हल किए गए: $attemptedCount", color = EmeraldAccent, fontWeight = FontWeight.Bold)
                            Text("छूटे हुए प्रश्न: $unattemptedCount", color = AmberAccent)
                            Spacer(modifier = Modifier.height(8.dp))
                            Text("क्या आप निश्चित रूप से अपना टेस्ट समाप्त करना चाहते हैं?")
                        }
                    },
                    confirmButton = {
                        Button(
                            onClick = {
                                showSubmitConfirmDialog = false
                                val totalTimeSpent = (test!!.durationMinutes * 60L) - timeLeftSeconds
                                viewModel.submitMockTest(test!!, questions, userAnswers.toMap(), totalTimeSpent)
                            },
                            colors = ButtonDefaults.buttonColors(containerColor = EmeraldAccent)
                        ) {
                            Text("हाँ, सबमिट करें")
                        }
                    },
                    dismissButton = {
                        TextButton(onClick = { showSubmitConfirmDialog = false }) {
                            Text("नहीं, जारी रखें")
                        }
                    }
                )
            }
        }
    }
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun MockTestResultScreen(
    result: MockTestResult,
    onClose: () -> Unit
) {
    Scaffold(
        topBar = {
            TargetBoardTopBar(
                title = "टेस्ट परिणाम (Scorecard)",
                subtitle = result.testTitle,
                canNavigateBack = true,
                onNavigateBack = onClose
            )
        }
    ) { innerPadding ->
        LazyColumn(
            modifier = Modifier
                .fillMaxSize()
                .padding(innerPadding)
                .background(MaterialTheme.colorScheme.background)
                .padding(16.dp),
            verticalArrangement = Arrangement.spacedBy(14.dp)
        ) {
            // Result Overview Card
            item {
                Card(
                    modifier = Modifier.fillMaxWidth(),
                    shape = RoundedCornerShape(16.dp),
                    colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
                    elevation = CardDefaults.cardElevation(defaultElevation = 3.dp)
                ) {
                    Column(
                        modifier = Modifier.padding(20.dp),
                        horizontalAlignment = Alignment.CenterHorizontally
                    ) {
                        Box(
                            modifier = Modifier
                                .size(64.dp)
                                .clip(CircleShape)
                                .background(if (result.percentage >= 60) EmeraldContainer else AmberContainer),
                            contentAlignment = Alignment.Center
                        ) {
                            Icon(
                                imageVector = if (result.percentage >= 60) Icons.Default.EmojiEvents else Icons.Default.ThumbUp,
                                contentDescription = null,
                                tint = if (result.percentage >= 60) EmeraldAccent else AmberAccent,
                                modifier = Modifier.size(36.dp)
                            )
                        }

                        Spacer(modifier = Modifier.height(10.dp))

                        Text(
                            text = result.performanceRating,
                            style = MaterialTheme.typography.titleMedium.copy(
                                fontWeight = FontWeight.Bold,
                                color = if (result.percentage >= 60) EmeraldAccent else AmberAccent
                            )
                        )

                        Spacer(modifier = Modifier.height(4.dp))

                        Text(
                            text = "${result.score} अंक",
                            style = MaterialTheme.typography.headlineLarge.copy(
                                fontWeight = FontWeight.Bold,
                                color = RoyalBluePrimary
                            )
                        )

                        Text(
                            text = "सटीकता: ${result.percentage.toInt()}% • समय: ${result.timeTakenSeconds / 60} मिनट ${result.timeTakenSeconds % 60} सेकंड",
                            style = MaterialTheme.typography.bodySmall.copy(color = TextSecondary)
                        )

                        Spacer(modifier = Modifier.height(16.dp))

                        // Stats Row
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceAround
                        ) {
                            StatBox("सही उत्तर", "${result.correct}", EmeraldAccent, EmeraldContainer)
                            StatBox("गलत उत्तर", "${result.wrong}", Color(0xFFE11D48), Color(0xFFFFE4E6))
                            StatBox("छूटे प्रश्न", "${result.unattempted}", TextMuted, SurfaceVariantLight)
                        }
                    }
                }
            }

            item {
                Text(
                    text = "विस्तृत उत्तर कुंजी एवं समाधान (Answer Key Review)",
                    style = MaterialTheme.typography.titleMedium.copy(
                        fontWeight = FontWeight.Bold,
                        color = MaterialTheme.colorScheme.onBackground
                    )
                )
            }

            // Question by Question Review
            itemsIndexed(result.questionReviewList) { index, item ->
                Card(
                    modifier = Modifier.fillMaxWidth(),
                    shape = RoundedCornerShape(12.dp),
                    colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
                    border = BorderStroke(
                        1.dp,
                        if (item.isCorrect) EmeraldAccent else if (item.selectedOption != 0) Color(0xFFE11D48) else OutlineLight
                    )
                ) {
                    Column(modifier = Modifier.padding(14.dp)) {
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween
                        ) {
                            Text(
                                text = "प्रश्न ${index + 1}",
                                style = MaterialTheme.typography.labelMedium.copy(
                                    fontWeight = FontWeight.Bold,
                                    color = RoyalBluePrimary
                                )
                            )

                            Surface(
                                shape = RoundedCornerShape(4.dp),
                                color = if (item.isCorrect) EmeraldContainer else if (item.selectedOption != 0) Color(0xFFFFE4E6) else SurfaceVariantLight
                            ) {
                                Text(
                                    text = if (item.isCorrect) "सही (+1)" else if (item.selectedOption != 0) "गलत (0)" else "अनसुलझा",
                                    modifier = Modifier.padding(horizontal = 6.dp, vertical = 2.dp),
                                    style = MaterialTheme.typography.labelSmall.copy(
                                        color = if (item.isCorrect) EmeraldAccent else if (item.selectedOption != 0) Color(0xFFE11D48) else TextMuted,
                                        fontWeight = FontWeight.Bold
                                    )
                                )
                            }
                        }

                        Spacer(modifier = Modifier.height(8.dp))

                        Text(
                            text = item.question.questionText,
                            style = MaterialTheme.typography.titleSmall.copy(fontWeight = FontWeight.Bold)
                        )

                        Spacer(modifier = Modifier.height(8.dp))

                        val options = listOf(
                            1 to item.question.optionA,
                            2 to item.question.optionB,
                            3 to item.question.optionC,
                            4 to item.question.optionD
                        )

                        options.forEach { (num, text) ->
                            val isCorrectOpt = num == item.question.correctOption
                            val isSelectedOpt = num == item.selectedOption

                            Row(
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .padding(vertical = 2.dp),
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                Text(
                                    text = when (num) {
                                        1 -> "(A)"
                                        2 -> "(B)"
                                        3 -> "(C)"
                                        else -> "(D)"
                                    },
                                    fontWeight = FontWeight.Bold,
                                    color = if (isCorrectOpt) EmeraldAccent else if (isSelectedOpt) Color(0xFFE11D48) else TextMuted
                                )
                                Spacer(modifier = Modifier.width(6.dp))
                                Text(
                                    text = text,
                                    style = MaterialTheme.typography.bodySmall.copy(
                                        fontWeight = if (isCorrectOpt || isSelectedOpt) FontWeight.Bold else FontWeight.Normal,
                                        color = if (isCorrectOpt) EmeraldAccent else if (isSelectedOpt) Color(0xFFE11D48) else MaterialTheme.colorScheme.onSurface
                                    )
                                )
                            }
                        }

                        if (item.question.explanation.isNotBlank()) {
                            Spacer(modifier = Modifier.height(6.dp))
                            Surface(
                                shape = RoundedCornerShape(6.dp),
                                color = AmberContainer.copy(alpha = 0.5f)
                            ) {
                                Text(
                                    text = "व्याख्या: ${item.question.explanation}",
                                    modifier = Modifier.padding(8.dp),
                                    style = MaterialTheme.typography.bodySmall.copy(color = RoyalBlueDark)
                                )
                            }
                        }
                    }
                }
            }

            item {
                Button(
                    onClick = onClose,
                    modifier = Modifier
                        .fillMaxWidth()
                        .height(50.dp),
                    shape = RoundedCornerShape(12.dp),
                    colors = ButtonDefaults.buttonColors(containerColor = RoyalBluePrimary)
                ) {
                    Text("वापस मुख्य पृष्ठ पर जाएँ (Home)", fontWeight = FontWeight.Bold)
                }
                Spacer(modifier = Modifier.height(16.dp))
            }
        }
    }
}

@Composable
fun StatBox(title: String, value: String, textColor: Color, bgColor: Color) {
    Surface(
        shape = RoundedCornerShape(10.dp),
        color = bgColor,
        modifier = Modifier.width(90.dp)
    ) {
        Column(
            modifier = Modifier.padding(10.dp),
            horizontalAlignment = Alignment.CenterHorizontally
        ) {
            Text(
                text = value,
                style = MaterialTheme.typography.titleMedium.copy(
                    fontWeight = FontWeight.Bold,
                    color = textColor
                )
            )
            Text(
                text = title,
                style = MaterialTheme.typography.labelSmall.copy(color = TextSecondary, fontSize = 10.sp)
            )
        }
    }
}
