package com.example.ui.navigation

sealed class Screen(val route: String) {
    object Splash : Screen("splash")
    object GoogleSignIn : Screen("google_sign_in")
    object CourseSelection : Screen("course_selection")
    object Home : Screen("home")
    object Courses : Screen("courses")
    data class SubjectDetail(val subjectId: String) : Screen("subject_detail/$subjectId")
    data class ChapterDetail(val chapterId: String) : Screen("chapter_detail/$chapterId")
    data class ObjectiveQuiz(val chapterId: String = "", val subjectId: String = "") : Screen("quiz")
    object MockTestList : Screen("mock_tests")
    data class MockTestRunning(val testId: String) : Screen("mock_test_running/$testId")
    object Notes : Screen("notes")
    object Bookmarks : Screen("bookmarks")
    object Profile : Screen("profile")
    object AdminLogin : Screen("admin_login")
    object AdminDashboard : Screen("admin_dashboard")
    data class AdminChapterManagement(val subjectId: String, val courseId: String) : Screen("admin_chapter_mgmt/$subjectId/$courseId")
}
