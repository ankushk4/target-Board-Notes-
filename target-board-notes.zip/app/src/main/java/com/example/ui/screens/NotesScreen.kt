package com.example.ui.screens

import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material.icons.outlined.BookmarkBorder
import androidx.compose.material.icons.outlined.Download
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.data.model.Chapter
import com.example.ui.components.*
import com.example.ui.navigation.Screen
import com.example.ui.theme.*
import com.example.ui.viewmodel.MainViewModel

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun NotesScreen(
    viewModel: MainViewModel,
    onNavigate: (Screen) -> Unit
) {
    val selectedCourseId by viewModel.selectedCourseId.collectAsState()
    val courses = viewModel.repository.getAllCourses()
    val currentCourse = courses.find { it.id == selectedCourseId } ?: courses.first()
    val chapters by viewModel.currentChapters.collectAsState()
    val bookmarks by viewModel.currentBookmarks.collectAsState()
    val bookmarkedIds = remember(bookmarks) { bookmarks.map { it.chapterId }.toSet() }

    var filterType by remember { mutableStateOf("ALL") }
    val filters = listOf(
        "ALL" to "सभी नोट्स (All)",
        "DOWNLOADED" to "ऑफलाइन सेव्ड (Downloaded)",
        "SUBJECTIVE" to "सब्जेक्टिव नोट्स",
        "OBJECTIVE" to "ऑब्जेक्टिव नोट्स",
        "PDF" to "PDF नोट्स",
        "PYQ" to "विगत वर्षों के प्रश्न"
    )

    var localSearchQuery by remember { mutableStateOf("") }

    val filteredChapters = chapters.filter { ch ->
        val matchesQuery = localSearchQuery.isBlank() ||
                ch.title.contains(localSearchQuery, ignoreCase = true) ||
                ch.hindiTitle.contains(localSearchQuery, ignoreCase = true)
        val matchesFilter = when (filterType) {
            "DOWNLOADED" -> ch.isDownloaded
            "PDF" -> ch.pdfUrl.isNotBlank()
            "PYQ" -> ch.chapterNumber <= 2
            else -> true
        }
        matchesQuery && matchesFilter
    }

    Scaffold(
        topBar = {
            TargetBoardTopBar(
                title = "नोट्स संग्रह: ${currentCourse.title}",
                subtitle = "हस्तलिखित नोट्स • VVI प्रश्न • PDF डाउनलोड",
                actions = {
                    IconButton(onClick = { onNavigate(Screen.Bookmarks) }) {
                        Icon(
                            imageVector = Icons.Default.Bookmark,
                            contentDescription = "Saved Bookmarks",
                            tint = Color.White
                        )
                    }
                }
            )
        },
        bottomBar = {
            TargetBoardBottomBar(
                currentRoute = Screen.Notes.route,
                onNavigate = onNavigate
            )
        }
    ) { innerPadding ->
        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(innerPadding)
                .background(MaterialTheme.colorScheme.background)
        ) {
            // Course Folder Selector (Class 10th, 12th Science, 12th Arts)
            ScrollableTabRow(
                selectedTabIndex = courses.indexOfFirst { it.id == selectedCourseId }.coerceAtLeast(0),
                containerColor = MaterialTheme.colorScheme.surface,
                contentColor = RoyalBluePrimary,
                edgePadding = 16.dp
            ) {
                courses.forEach { course ->
                    val isSelected = course.id == selectedCourseId
                    Tab(
                        selected = isSelected,
                        onClick = { viewModel.selectAndPersistCourse(course.id) },
                        text = {
                            Text(
                                text = "${course.title} फोल्डर",
                                fontWeight = if (isSelected) FontWeight.Bold else FontWeight.Normal,
                                fontSize = 13.sp
                            )
                        },
                        modifier = Modifier.testTag("notes_folder_tab_${course.id}")
                    )
                }
            }

            // Search Bar for Notes
            OutlinedTextField(
                value = localSearchQuery,
                onValueChange = { localSearchQuery = it },
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(horizontal = 16.dp, vertical = 10.dp)
                    .testTag("notes_search_input"),
                placeholder = { Text("${currentCourse.title} में नोट्स खोजें...", fontSize = 14.sp) },
                leadingIcon = {
                    Icon(imageVector = Icons.Default.Search, contentDescription = null, tint = RoyalBluePrimary)
                },
                trailingIcon = {
                    if (localSearchQuery.isNotEmpty()) {
                        IconButton(onClick = { localSearchQuery = "" }) {
                            Icon(imageVector = Icons.Default.Close, contentDescription = null)
                        }
                    }
                },
                shape = RoundedCornerShape(10.dp),
                colors = OutlinedTextFieldDefaults.colors(
                    focusedContainerColor = MaterialTheme.colorScheme.surface,
                    unfocusedContainerColor = MaterialTheme.colorScheme.surface
                ),
                singleLine = true
            )

            // Category Filter Pills
            LazyRow(
                modifier = Modifier.padding(horizontal = 16.dp, vertical = 4.dp),
                horizontalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                items(filters) { (key, label) ->
                    val isSelected = filterType == key
                    FilterChip(
                        selected = isSelected,
                        onClick = { filterType = key },
                        label = {
                            Text(
                                text = label,
                                fontSize = 12.sp,
                                fontWeight = if (isSelected) FontWeight.Bold else FontWeight.Normal
                            )
                        },
                        colors = FilterChipDefaults.filterChipColors(
                            selectedContainerColor = RoyalBluePrimary,
                            selectedLabelColor = Color.White
                        )
                    )
                }
            }

            // Notes Items List
            LazyColumn(
                modifier = Modifier
                    .fillMaxSize()
                    .padding(horizontal = 16.dp, vertical = 8.dp),
                verticalArrangement = Arrangement.spacedBy(10.dp)
            ) {
                if (filteredChapters.isEmpty()) {
                    item {
                        EmptyNoticeCard("इस फ़ोल्डर में कोई नोट्स उपलब्ध नहीं हैं। कृपया दूसरा फ़िल्टर चुनें।")
                    }
                } else {
                    items(filteredChapters) { chapter ->
                        Card(
                            modifier = Modifier
                                .fillMaxWidth()
                                .clickable { onNavigate(Screen.ChapterDetail(chapter.id)) }
                                .testTag("notes_card_${chapter.id}"),
                            shape = RoundedCornerShape(12.dp),
                            colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
                            elevation = CardDefaults.cardElevation(defaultElevation = 1.dp)
                        ) {
                            Column(modifier = Modifier.padding(14.dp)) {
                                Row(
                                    modifier = Modifier.fillMaxWidth(),
                                    horizontalArrangement = Arrangement.SpaceBetween,
                                    verticalAlignment = Alignment.CenterVertically
                                ) {
                                    Surface(
                                        shape = RoundedCornerShape(4.dp),
                                        color = RoyalBlueContainer
                                    ) {
                                        Text(
                                            text = "पाठ ${chapter.chapterNumber} • सम्पूर्ण नोट्स",
                                            modifier = Modifier.padding(horizontal = 6.dp, vertical = 2.dp),
                                            style = MaterialTheme.typography.labelSmall.copy(
                                                color = RoyalBluePrimary,
                                                fontWeight = FontWeight.Bold
                                            )
                                        )
                                    }

                                    Row {
                                        IconButton(
                                            onClick = {
                                                viewModel.toggleBookmark(chapter, bookmarkedIds.contains(chapter.id))
                                            }
                                        ) {
                                            Icon(
                                                imageVector = if (bookmarkedIds.contains(chapter.id)) Icons.Filled.Bookmark else Icons.Outlined.BookmarkBorder,
                                                contentDescription = "Bookmark",
                                                tint = if (bookmarkedIds.contains(chapter.id)) BiharBoardGold else TextMuted
                                            )
                                        }

                                        IconButton(
                                            onClick = { viewModel.toggleDownload(chapter.id, chapter.isDownloaded) }
                                        ) {
                                            Icon(
                                                imageVector = if (chapter.isDownloaded) Icons.Filled.FileDownloadDone else Icons.Outlined.Download,
                                                contentDescription = "Download",
                                                tint = if (chapter.isDownloaded) EmeraldAccent else RoyalBluePrimary
                                            )
                                        }
                                    }
                                }

                                Spacer(modifier = Modifier.height(6.dp))

                                Text(
                                    text = chapter.hindiTitle,
                                    style = MaterialTheme.typography.titleMedium.copy(
                                        fontWeight = FontWeight.Bold,
                                        color = MaterialTheme.colorScheme.onSurface
                                    )
                                )

                                if (chapter.authorName.isNotBlank()) {
                                    Text(
                                        text = "लेखक: ${chapter.authorName}",
                                        style = MaterialTheme.typography.bodySmall.copy(color = TextSecondary)
                                    )
                                }

                                Spacer(modifier = Modifier.height(8.dp))

                                Row(
                                    modifier = Modifier.fillMaxWidth(),
                                    horizontalArrangement = Arrangement.SpaceBetween,
                                    verticalAlignment = Alignment.CenterVertically
                                ) {
                                    Text(
                                        text = "${chapter.pageCount} पृष्ठ • PDF + सम्पूर्ण व्याख्या",
                                        style = MaterialTheme.typography.labelSmall.copy(
                                            color = TextMuted,
                                            fontSize = 11.sp
                                        )
                                    )

                                    FilledTonalButton(
                                        onClick = { onNavigate(Screen.ChapterDetail(chapter.id)) },
                                        shape = RoundedCornerShape(8.dp),
                                        contentPadding = PaddingValues(horizontal = 12.dp, vertical = 4.dp)
                                    ) {
                                        Text("नोट्स पढ़ें (Read)", fontSize = 12.sp, fontWeight = FontWeight.Bold)
                                    }
                                }
                            }
                        }
                    }
                }
            }
        }
    }
}
