package com.example.ui.viewmodel

import android.app.Application
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import com.example.data.model.*
import com.example.data.repository.TargetBoardRepository
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.launch

class AdminViewModel(application: Application) : AndroidViewModel(application) {

    val repository = TargetBoardRepository.getInstance(application)
    private val prefs = repository.preferencesManager

    private val _isAuthenticated = MutableStateFlow(false)
    val isAuthenticated: StateFlow<Boolean> = _isAuthenticated.asStateFlow()

    private val _loginError = MutableStateFlow<String?>(null)
    val loginError: StateFlow<String?> = _loginError.asStateFlow()

    private val _mustChangePassword = MutableStateFlow(false)
    val mustChangePassword: StateFlow<Boolean> = _mustChangePassword.asStateFlow()

    private val _operationStatus = MutableStateFlow<String?>(null)
    val operationStatus: StateFlow<String?> = _operationStatus.asStateFlow()

    // Course selection in Admin Panel: "class_10", "class_12_science", "class_12_arts"
    private val _adminSelectedCourse = MutableStateFlow("class_10")
    val adminSelectedCourse: StateFlow<String> = _adminSelectedCourse.asStateFlow()

    fun selectAdminCourse(courseId: String) {
        _adminSelectedCourse.value = courseId
    }

    fun login(adminId: String, passwordAttempt: String): Boolean {
        if (adminId.isBlank() || passwordAttempt.isBlank()) {
            _loginError.value = "कृपया एडमिन आईडी एवं पासवर्ड दर्ज करें।"
            return false
        }

        val isValid = prefs.verifyAdminCredentials(adminId, passwordAttempt)
        return if (isValid) {
            _isAuthenticated.value = true
            _loginError.value = null
            // Check if initial password must be changed
            if (prefs.isInitialPasswordChangeRequired()) {
                _mustChangePassword.value = true
            }
            true
        } else {
            _loginError.value = "अमान्य एडमिन क्रेडेंशियल! कृपया सही आईडी व पासवर्ड दर्ज करें।"
            false
        }
    }

    fun logout() {
        _isAuthenticated.value = false
        _loginError.value = null
        _mustChangePassword.value = false
    }

    fun changePassword(newPassword: String): Boolean {
        if (newPassword.length < 6) {
            _operationStatus.value = "नया पासवर्ड कम से कम 6 अक्षरों का होना चाहिए।"
            return false
        }
        val success = prefs.updateAdminPassword(newPassword)
        if (success) {
            _mustChangePassword.value = false
            _operationStatus.value = "एडमिन पासवर्ड सफलतापूर्वक अपडेट हो गया!"
        }
        return success
    }

    fun resetPasswordWithRecoveryKey(recoveryKey: String, newPassword: String): Boolean {
        val success = prefs.resetPasswordWithRecoveryKey(recoveryKey, newPassword)
        if (success) {
            _operationStatus.value = "पासवर्ड सफलतापूर्वक रीसेट हो गया! अब नए पासवर्ड से लॉगिन करें।"
            _loginError.value = null
        } else {
            _loginError.value = "अमान्य रिकवरी की! कृपया सही मास्टर की दर्ज करें।"
        }
        return success
    }

    // --- Subject Management ---
    fun saveSubject(
        id: String?,
        courseId: String,
        title: String,
        hindiTitle: String,
        chapterCount: Int,
        iconName: String,
        colorHex: Long
    ) {
        viewModelScope.launch {
            val subjectId = id ?: "sub_${courseId}_${System.currentTimeMillis()}"
            val subject = Subject(
                id = subjectId,
                courseId = courseId,
                title = title,
                hindiTitle = hindiTitle,
                chapterCount = chapterCount,
                iconName = iconName,
                colorHex = colorHex
            )
            repository.saveSubject(subject)
            _operationStatus.value = "विषय सफलतापूर्वक सहेज लिया गया!"
        }
    }

    fun deleteSubject(subjectId: String) {
        viewModelScope.launch {
            repository.deleteSubject(subjectId)
            _operationStatus.value = "विषय हटा दिया गया।"
        }
    }

    // --- Chapter Management ---
    fun getChaptersBySubject(subjectId: String) = repository.getChaptersBySubject(subjectId)

    fun saveChapter(
        id: String?,
        subjectId: String,
        courseId: String,
        chapterNumber: Int,
        title: String,
        hindiTitle: String,
        authorName: String = "",
        authorIntro: String = "",
        authorLifeHistory: String = "",
        explanation: String = "",
        importantPoints: List<String> = emptyList(),
        definitions: List<String> = emptyList(),
        pdfUrl: String = "",
        pageCount: Int = 12,
        isPublished: Boolean = true
    ) {
        viewModelScope.launch {
            val chapterId = id ?: "custom_ch_${System.currentTimeMillis()}"
            val chapter = Chapter(
                id = chapterId,
                subjectId = subjectId,
                courseId = courseId,
                chapterNumber = chapterNumber,
                title = title,
                hindiTitle = hindiTitle,
                authorName = authorName,
                authorIntro = authorIntro,
                authorLifeHistory = authorLifeHistory,
                explanation = explanation,
                importantPoints = importantPoints,
                definitions = definitions,
                pdfUrl = pdfUrl.ifBlank { "https://targetboardnotes.biharboard.ac.in/pdf/$chapterId.pdf" },
                pageCount = pageCount,
                isCustom = true,
                isPublished = isPublished
            )
            repository.saveChapter(chapter)
            _operationStatus.value = if (id != null) "अध्याय सफलतापूर्वक अपडेट हो गया!" else "नया अध्याय सफलतापूर्वक सहेज लिया गया!"
        }
    }

    fun updateChapter(chapter: Chapter) {
        viewModelScope.launch {
            repository.updateChapter(chapter)
            _operationStatus.value = "अध्याय सफलतापूर्वक अपडेट हो गया!"
        }
    }

    fun togglePublishChapter(chapterId: String, isPublished: Boolean) {
        viewModelScope.launch {
            repository.toggleChapterPublishStatus(chapterId, isPublished)
            _operationStatus.value = if (isPublished) "अध्याय विद्यार्थियों के लिए प्रकाशित कर दिया गया!" else "अध्याय ड्राफ्ट (अप्रकाशित) में रख दिया गया।"
        }
    }

    fun updateChapterNotesAndPdf(chapterId: String, notesHindi: String, pdfUrl: String, pageCount: Int) {
        viewModelScope.launch {
            repository.updateChapterNotesAndPdf(chapterId, notesHindi, pdfUrl, pageCount)
            _operationStatus.value = "विस्तृत नोट्स व PDF फाइल सफलतापूर्वक सहेज लिए गए!"
        }
    }

    fun deleteChapter(chapterId: String) {
        viewModelScope.launch {
            repository.deleteChapter(chapterId)
            _operationStatus.value = "अध्याय हटा दिया गया।"
        }
    }

    // --- Objective Question Management ---
    fun getObjectiveQuestionsByChapter(chapterId: String) = repository.getObjectiveQuestions(chapterId)

    fun saveObjectiveQuestion(
        id: String? = null,
        chapterId: String,
        subjectId: String,
        courseId: String,
        questionText: String,
        optionA: String,
        optionB: String,
        optionC: String,
        optionD: String,
        correctOption: Int,
        explanation: String,
        marks: Int = 1,
        difficulty: String = "मध्यम",
        isPreviousYear: Boolean,
        examYear: String
    ) {
        viewModelScope.launch {
            val qId = id ?: "custom_obj_${System.currentTimeMillis()}"
            val question = ObjectiveQuestion(
                id = qId,
                chapterId = chapterId,
                subjectId = subjectId,
                courseId = courseId,
                questionText = questionText,
                optionA = optionA,
                optionB = optionB,
                optionC = optionC,
                optionD = optionD,
                correctOption = correctOption,
                explanation = explanation,
                marks = marks,
                difficulty = difficulty,
                isPreviousYear = isPreviousYear,
                examYear = examYear
            )
            if (id != null) {
                repository.updateObjectiveQuestion(question)
                _operationStatus.value = "वस्तुनिष्ठ प्रश्न सफलतापूर्वक अपडेट हो गया!"
            } else {
                repository.saveObjectiveQuestion(question)
                _operationStatus.value = "नया वस्तुनिष्ठ प्रश्न सफलतापूर्वक जोड़ दिया गया!"
            }
        }
    }

    fun updateObjectiveQuestion(question: ObjectiveQuestion) {
        viewModelScope.launch {
            repository.updateObjectiveQuestion(question)
            _operationStatus.value = "वस्तुनिष्ठ प्रश्न अपडेट हो गया!"
        }
    }

    fun deleteObjectiveQuestion(question: ObjectiveQuestion) {
        viewModelScope.launch {
            repository.deleteObjectiveQuestion(question)
            _operationStatus.value = "वस्तुनिष्ठ प्रश्न हटा दिया गया।"
        }
    }

    // --- Bulk Question Import ---
    fun bulkImportObjectiveQuestions(
        courseId: String,
        subjectId: String,
        chapterId: String,
        rawText: String
    ) {
        viewModelScope.launch {
            val lines = rawText.lines().map { it.trim() }.filter { it.isNotBlank() }
            val importedList = mutableListOf<ObjectiveQuestion>()
            var i = 0
            while (i < lines.size) {
                val qLine = lines.getOrNull(i) ?: break
                if (qLine.startsWith("Q:") || qLine.startsWith("प्रश्न:")) {
                    val qText = qLine.substringAfter(":").trim()
                    val a = lines.getOrNull(i + 1)?.substringAfter(":")?.trim() ?: "A"
                    val b = lines.getOrNull(i + 2)?.substringAfter(":")?.trim() ?: "B"
                    val c = lines.getOrNull(i + 3)?.substringAfter(":")?.trim() ?: "C"
                    val d = lines.getOrNull(i + 4)?.substringAfter(":")?.trim() ?: "D"
                    val ans = lines.getOrNull(i + 5)?.substringAfter(":")?.trim()?.toIntOrNull() ?: 1
                    val exp = lines.getOrNull(i + 6)?.substringAfter(":")?.trim() ?: ""

                    importedList.add(
                        ObjectiveQuestion(
                            id = "bulk_obj_${System.currentTimeMillis()}_${importedList.size}",
                            chapterId = chapterId,
                            subjectId = subjectId,
                            courseId = courseId,
                            questionText = qText,
                            optionA = a,
                            optionB = b,
                            optionC = c,
                            optionD = d,
                            correctOption = ans,
                            explanation = exp,
                            marks = 1,
                            difficulty = "मध्यम",
                            isPreviousYear = false,
                            examYear = "2024"
                        )
                    )
                    i += 7
                } else {
                    i++
                }
            }

            if (importedList.isNotEmpty()) {
                repository.bulkSaveObjectiveQuestions(importedList)
                _operationStatus.value = "${importedList.size} प्रश्न सफलतापूर्वक बल्क इम्पोर्ट किए गए!"
            } else {
                _operationStatus.value = "प्रश्न प्रारूप अमान्य था। कृपया दिए गए फॉर्मेट अनुसार इनपुट दें।"
            }
        }
    }

    // --- Subjective Question Management ---
    fun getSubjectiveQuestionsByChapter(chapterId: String) = repository.getSubjectiveQuestions(chapterId)

    fun saveSubjectiveQuestion(
        id: String? = null,
        chapterId: String,
        subjectId: String,
        courseId: String,
        questionText: String,
        answerText: String,
        marks: Int,
        questionType: String,
        isImportant: Boolean,
        isPreviousYear: Boolean,
        examYear: String
    ) {
        viewModelScope.launch {
            val qId = id ?: "custom_sub_${System.currentTimeMillis()}"
            val question = SubjectiveQuestion(
                id = qId,
                chapterId = chapterId,
                subjectId = subjectId,
                courseId = courseId,
                questionText = questionText,
                answerText = answerText,
                marks = marks,
                questionType = questionType,
                isImportant = isImportant,
                isPreviousYear = isPreviousYear,
                examYear = examYear
            )
            if (id != null) {
                repository.updateSubjectiveQuestion(question)
                _operationStatus.value = "सब्जेक्टिव प्रश्न सफलतापूर्वक अपडेट हो गया!"
            } else {
                repository.saveSubjectiveQuestion(question)
                _operationStatus.value = "नया सब्जेक्टिव प्रश्न सफलतापूर्वक जोड़ दिया गया!"
            }
        }
    }

    fun updateSubjectiveQuestion(question: SubjectiveQuestion) {
        viewModelScope.launch {
            repository.updateSubjectiveQuestion(question)
            _operationStatus.value = "सब्जेक्टिव प्रश्न अपडेट हो गया!"
        }
    }

    fun deleteSubjectiveQuestion(question: SubjectiveQuestion) {
        viewModelScope.launch {
            repository.deleteSubjectiveQuestion(question)
            _operationStatus.value = "सब्जेक्टिव प्रश्न हटा दिया गया।"
        }
    }

    // --- Announcements ---
    fun saveAnnouncement(title: String, content: String, isImportant: Boolean, tag: String, courseId: String) {
        viewModelScope.launch {
            val announcement = Announcement(
                id = "custom_ann_${System.currentTimeMillis()}",
                courseId = courseId,
                title = title,
                content = content,
                date = "TARGET BOARD एडमिन द्वारा",
                isImportant = isImportant,
                tag = tag
            )
            repository.saveAnnouncement(announcement)
            _operationStatus.value = "सूचना सफलतापूर्वक प्रकाशित की गई!"
        }
    }

    fun deleteAnnouncement(announcement: Announcement) {
        viewModelScope.launch {
            repository.deleteAnnouncement(announcement)
            _operationStatus.value = "सूचना हटा दी गई।"
        }
    }

    // --- Mock Test Creation ---
    fun getMockTestsBySubject(subjectId: String) = repository.getMockTestsBySubject(subjectId)
    fun getMockTestsByChapter(chapterId: String) = repository.getMockTestsByChapter(chapterId)

    fun saveMockTest(
        id: String? = null,
        courseId: String,
        subjectId: String,
        chapterId: String = "",
        title: String,
        description: String,
        durationMinutes: Int,
        totalMarks: Int,
        totalQuestions: Int,
        passMarks: Int,
        isPublished: Boolean = true
    ) {
        viewModelScope.launch {
            val testId = id ?: "test_${courseId}_${System.currentTimeMillis()}"
            val test = MockTest(
                id = testId,
                courseId = courseId,
                subjectId = subjectId,
                chapterId = chapterId,
                title = title,
                description = description,
                durationMinutes = durationMinutes,
                totalMarks = totalMarks,
                totalQuestions = totalQuestions,
                passMarks = passMarks,
                isPublished = isPublished
            )
            if (id != null) {
                repository.updateMockTest(test)
                _operationStatus.value = "मॉक टेस्ट सफलतापूर्वक अपडेट हो गया!"
            } else {
                repository.saveMockTest(test)
                _operationStatus.value = "नया मॉक टेस्ट सफलतापूर्वक निर्मित हो गया!"
            }
        }
    }

    fun togglePublishMockTest(testId: String, isPublished: Boolean) {
        viewModelScope.launch {
            repository.toggleMockTestPublishStatus(testId, isPublished)
            _operationStatus.value = if (isPublished) "मॉक टेस्ट विद्यार्थियों के लिए प्रकाशित कर दिया गया!" else "मॉक टेस्ट अप्रकाशित (ड्राफ्ट) किया गया।"
        }
    }

    fun deleteMockTest(test: MockTest) {
        viewModelScope.launch {
            repository.deleteMockTest(test)
            _operationStatus.value = "मॉक टेस्ट हटा दिया गया।"
        }
    }

    fun clearStatus() {
        _operationStatus.value = null
    }
}
