package com.example.data.repository

import android.content.Context
import com.example.data.local.PreferencesManager
import com.example.data.local.TargetBoardDatabase
import com.example.data.local.entity.*
import com.example.data.model.*
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.first
import kotlinx.coroutines.flow.map
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext

class TargetBoardRepository private constructor(context: Context) {

    private val db = TargetBoardDatabase.getDatabase(context)
    private val dao = db.targetBoardDao()
    val preferencesManager = PreferencesManager(context)
    val firebaseSync = FirebaseSyncRepository.getInstance(context)

    init {
        CoroutineScope(Dispatchers.IO).launch {
            seedDatabaseIfEmpty()
        }
    }

    private suspend fun seedDatabaseIfEmpty() {
        val existingAnnouncements = dao.getAnnouncements().first()
        if (existingAnnouncements.isEmpty()) {
            dao.insertSubjects(SeedData.getInitialSubjects())
            dao.insertAnnouncements(SeedData.getInitialAnnouncements())
            dao.insertChapters(SeedData.getInitialChapters())
            dao.insertObjectiveQuestions(SeedData.getInitialObjectiveQuestions())
            dao.insertSubjectiveQuestions(SeedData.getInitialSubjectiveQuestions())
            dao.insertMockTests(SeedData.getInitialMockTests())
        }
    }

    // Courses & Subjects
    fun getAllCourses(): List<Course> = SeedData.courses

    fun getCourseById(courseId: String): Course? =
        SeedData.courses.find { it.id == courseId }

    fun getSubjectsByCourse(courseId: String): Flow<List<Subject>> =
        dao.getSubjectsByCourse(courseId).map { entities ->
            entities.map { it.toDomain() }
        }

    suspend fun getSubjectById(subjectId: String): Subject? = withContext(Dispatchers.IO) {
        dao.getSubjectById(subjectId)?.toDomain()
    }

    suspend fun saveSubject(subject: Subject) = withContext(Dispatchers.IO) {
        dao.insertSubject(subject.toEntity())
    }

    suspend fun deleteSubject(subjectId: String) = withContext(Dispatchers.IO) {
        val entity = dao.getSubjectById(subjectId)
        if (entity != null) {
            dao.deleteSubject(entity)
        }
    }

    // Chapters
    fun getChaptersBySubject(subjectId: String): Flow<List<Chapter>> =
        dao.getChaptersBySubject(subjectId).map { entities ->
            entities.map { it.toDomain() }
        }

    fun getChaptersByCourse(courseId: String): Flow<List<Chapter>> =
        dao.getChaptersByCourse(courseId).map { entities ->
            entities.map { it.toDomain() }
        }

    suspend fun getChapterById(chapterId: String): Chapter? = withContext(Dispatchers.IO) {
        dao.getChapterById(chapterId)?.toDomain()
    }

    suspend fun searchChapters(courseId: String, query: String): List<Chapter> = withContext(Dispatchers.IO) {
        dao.searchChaptersByCourse(courseId, query).map { it.toDomain() }
    }

    suspend fun toggleDownloadChapter(chapterId: String, currentStatus: Boolean) = withContext(Dispatchers.IO) {
        dao.updateDownloadStatus(chapterId, !currentStatus)
    }

    // Admin Chapter Management
    suspend fun saveChapter(chapter: Chapter) = withContext(Dispatchers.IO) {
        dao.insertChapter(chapter.toEntity())
        firebaseSync.saveChapterToCloud(chapter)
    }

    suspend fun updateChapter(chapter: Chapter) = withContext(Dispatchers.IO) {
        dao.updateChapter(chapter.toEntity())
        firebaseSync.saveChapterToCloud(chapter)
    }

    suspend fun toggleChapterPublishStatus(chapterId: String, isPublished: Boolean) = withContext(Dispatchers.IO) {
        dao.updateChapterPublishStatus(chapterId, isPublished)
        val entity = dao.getChapterById(chapterId)
        if (entity != null) {
            firebaseSync.toggleChapterPublishInCloud(chapterId, entity.courseId, isPublished)
        }
    }

    suspend fun updateChapterNotesAndPdf(chapterId: String, notesHindi: String, pdfUrl: String, pageCount: Int) = withContext(Dispatchers.IO) {
        dao.updateChapterNotesAndPdf(chapterId, notesHindi, pdfUrl, pageCount)
        val entity = dao.getChapterById(chapterId)
        if (entity != null) {
            firebaseSync.saveChapterToCloud(entity.toDomain())
        }
    }

    suspend fun deleteChapter(chapterId: String) = withContext(Dispatchers.IO) {
        val entity = dao.getChapterById(chapterId)
        if (entity != null) {
            dao.deleteChapter(entity)
            firebaseSync.deleteChapterFromCloud(chapterId, entity.courseId)
        }
    }

    // Questions
    fun getObjectiveQuestions(chapterId: String): Flow<List<ObjectiveQuestion>> =
        dao.getObjectiveQuestionsByChapter(chapterId).map { entities ->
            entities.map { it.toDomain() }
        }

    fun getObjectiveQuestionsByCourse(courseId: String): Flow<List<ObjectiveQuestion>> =
        dao.getObjectiveQuestionsByCourse(courseId).map { entities ->
            entities.map { it.toDomain() }
        }

    suspend fun getObjectiveQuestionsForSubject(subjectId: String): List<ObjectiveQuestion> = withContext(Dispatchers.IO) {
        dao.getObjectiveQuestionsBySubject(subjectId).map { it.toDomain() }
    }

    suspend fun getRandomObjectiveQuestionsByCourse(courseId: String, limit: Int): List<ObjectiveQuestion> = withContext(Dispatchers.IO) {
        val questions = dao.getRandomObjectiveQuestionsByCourse(courseId, limit)
        if (questions.isEmpty()) {
            SeedData.getInitialObjectiveQuestions().filter { it.courseId == courseId }.shuffled().take(limit).map { it.toDomain() }
        } else {
            questions.map { it.toDomain() }
        }
    }

    suspend fun getRandomObjectiveQuestions(limit: Int): List<ObjectiveQuestion> = withContext(Dispatchers.IO) {
        val questions = dao.getRandomObjectiveQuestions(limit)
        if (questions.isEmpty()) {
            SeedData.getInitialObjectiveQuestions().shuffled().take(limit).map { it.toDomain() }
        } else {
            questions.map { it.toDomain() }
        }
    }

    suspend fun saveObjectiveQuestion(question: ObjectiveQuestion) = withContext(Dispatchers.IO) {
        dao.insertObjectiveQuestion(question.toEntity())
        firebaseSync.saveObjectiveQuestionToCloud(question)
    }

    suspend fun updateObjectiveQuestion(question: ObjectiveQuestion) = withContext(Dispatchers.IO) {
        dao.updateObjectiveQuestion(question.toEntity())
        firebaseSync.saveObjectiveQuestionToCloud(question)
    }

    suspend fun bulkSaveObjectiveQuestions(questions: List<ObjectiveQuestion>) = withContext(Dispatchers.IO) {
        dao.insertObjectiveQuestions(questions.map { it.toEntity() })
    }

    suspend fun deleteObjectiveQuestion(question: ObjectiveQuestion) = withContext(Dispatchers.IO) {
        dao.deleteObjectiveQuestion(question.toEntity())
    }

    fun getSubjectiveQuestions(chapterId: String): Flow<List<SubjectiveQuestion>> =
        dao.getSubjectiveQuestionsByChapter(chapterId).map { entities ->
            entities.map { it.toDomain() }
        }

    fun getSubjectiveQuestionsByCourse(courseId: String): Flow<List<SubjectiveQuestion>> =
        dao.getSubjectiveQuestionsByCourse(courseId).map { entities ->
            entities.map { it.toDomain() }
        }

    suspend fun saveSubjectiveQuestion(question: SubjectiveQuestion) = withContext(Dispatchers.IO) {
        dao.insertSubjectiveQuestion(question.toEntity())
        firebaseSync.saveSubjectiveQuestionToCloud(question)
    }

    suspend fun updateSubjectiveQuestion(question: SubjectiveQuestion) = withContext(Dispatchers.IO) {
        dao.updateSubjectiveQuestion(question.toEntity())
        firebaseSync.saveSubjectiveQuestionToCloud(question)
    }

    suspend fun deleteSubjectiveQuestion(question: SubjectiveQuestion) = withContext(Dispatchers.IO) {
        dao.deleteSubjectiveQuestion(question.toEntity())
    }

    // Mock Tests
    fun getMockTestsByCourse(courseId: String): Flow<List<MockTest>> =
        dao.getMockTestsByCourse(courseId).map { entities ->
            entities.map { it.toDomain() }
        }

    fun getMockTestsBySubject(subjectId: String): Flow<List<MockTest>> =
        dao.getMockTestsBySubject(subjectId).map { entities ->
            entities.map { it.toDomain() }
        }

    fun getMockTestsByChapter(chapterId: String): Flow<List<MockTest>> =
        dao.getMockTestsByChapter(chapterId).map { entities ->
            entities.map { it.toDomain() }
        }

    fun getAllMockTests(): Flow<List<MockTest>> =
        dao.getAllMockTests().map { entities ->
            entities.map { it.toDomain() }
        }

    suspend fun getMockTestById(testId: String): MockTest? = withContext(Dispatchers.IO) {
        dao.getMockTestById(testId)?.toDomain()
    }

    suspend fun toggleMockTestPublishStatus(testId: String, isPublished: Boolean) = withContext(Dispatchers.IO) {
        dao.updateMockTestPublishStatus(testId, isPublished)
    }

    suspend fun saveMockTest(test: MockTest) = withContext(Dispatchers.IO) {
        dao.insertMockTest(test.toEntity())
        firebaseSync.saveMockTestToCloud(test)
    }

    suspend fun updateMockTest(test: MockTest) = withContext(Dispatchers.IO) {
        dao.updateMockTest(test.toEntity())
        firebaseSync.saveMockTestToCloud(test)
    }

    suspend fun deleteMockTest(test: MockTest) = withContext(Dispatchers.IO) {
        dao.deleteMockTest(test.toEntity())
    }

    // Announcements
    fun getAnnouncementsByCourse(courseId: String): Flow<List<Announcement>> =
        dao.getAnnouncementsByCourse(courseId).map { entities ->
            entities.map { it.toDomain() }
        }

    fun getAnnouncements(): Flow<List<Announcement>> =
        dao.getAnnouncements().map { entities ->
            entities.map { it.toDomain() }
        }

    suspend fun saveAnnouncement(announcement: Announcement) = withContext(Dispatchers.IO) {
        dao.insertAnnouncement(announcement.toEntity())
    }

    suspend fun deleteAnnouncement(announcement: Announcement) = withContext(Dispatchers.IO) {
        dao.deleteAnnouncement(announcement.toEntity())
    }

    // Bookmarks (Course-separated)
    fun getBookmarksByCourse(courseId: String): Flow<List<Bookmark>> =
        dao.getBookmarksByCourse(courseId).map { entities ->
            entities.map { Bookmark(it.chapterId, it.chapterId, it.chapterTitle, it.subjectName, it.courseId, it.timestamp) }
        }

    fun getAllBookmarks(): Flow<List<Bookmark>> =
        dao.getAllBookmarks().map { entities ->
            entities.map { Bookmark(it.chapterId, it.chapterId, it.chapterTitle, it.subjectName, it.courseId, it.timestamp) }
        }

    fun isBookmarked(chapterId: String): Flow<Boolean> = dao.isBookmarked(chapterId)

    suspend fun toggleBookmark(chapter: Chapter, isCurrentlyBookmarked: Boolean) = withContext(Dispatchers.IO) {
        if (isCurrentlyBookmarked) {
            dao.removeBookmark(chapter.id)
        } else {
            val subject = getSubjectById(chapter.subjectId)?.title ?: "बिहार बोर्ड"
            dao.addBookmark(
                BookmarkEntity(
                    chapterId = chapter.id,
                    chapterTitle = chapter.title,
                    subjectName = subject,
                    courseId = chapter.courseId,
                    timestamp = System.currentTimeMillis()
                )
            )
        }
    }

    // App Version Update Check
    suspend fun checkForUpdates(): AppUpdateInfo = withContext(Dispatchers.IO) {
        AppUpdateInfo(
            currentVersionCode = 1,
            currentVersionName = "1.0",
            latestVersionCode = 2,
            latestVersionName = "2.0 (2026-27 Special)",
            updateTitle = "नया अपडेट उपलब्ध है! (New Update Available)",
            releaseNotes = "• सत्र 2026–2027 के नए मॉडल पेपर्स व नोट्स जोड़े गए\n• नए ऑब्जेक्टिव और VVI सब्जेक्टिव प्रश्न\n• ऑफलाइन डाउनलोड गति में सुधार\n• नया टेस्ट सीरीज विश्लेषण",
            apkUrl = "https://github.com/targetboardnotes/releases/download/v2.0/TargetBoardNotes_v2.0.apk",
            apkSize = "14.2 MB",
            sha256Checksum = "e3b0c44298fc1c149afbf4c8996fb92427ae41e4649b934ca495991b7852b855",
            isAvailable = true
        )
    }

    // Converters
    private fun SubjectEntity.toDomain(): Subject = Subject(
        id = id,
        courseId = courseId,
        title = title,
        hindiTitle = hindiTitle,
        chapterCount = chapterCount,
        iconName = iconName,
        colorHex = colorHex
    )

    private fun Subject.toEntity(): SubjectEntity = SubjectEntity(
        id = id,
        courseId = courseId,
        title = title,
        hindiTitle = hindiTitle,
        chapterCount = chapterCount,
        iconName = iconName,
        colorHex = colorHex
    )

    private fun ChapterEntity.toDomain(): Chapter = Chapter(
        id = id,
        subjectId = subjectId,
        courseId = courseId,
        chapterNumber = chapterNumber,
        title = title,
        hindiTitle = hindiTitle,
        authorName = authorName,
        authorIntro = authorIntro,
        authorLifeHistory = authorLifeHistory,
        explanation = explanation,
        importantPoints = importantPointsRaw.split("\n").filter { it.isNotBlank() },
        definitions = definitionsRaw.split("\n").filter { it.isNotBlank() },
        pdfUrl = pdfUrl,
        pageCount = pageCount,
        isDownloaded = isDownloaded,
        isCustom = isCustom,
        isPublished = isPublished
    )

    private fun Chapter.toEntity(): ChapterEntity = ChapterEntity(
        id = id,
        subjectId = subjectId,
        courseId = courseId,
        chapterNumber = chapterNumber,
        title = title,
        hindiTitle = hindiTitle,
        authorName = authorName,
        authorIntro = authorIntro,
        authorLifeHistory = authorLifeHistory,
        explanation = explanation,
        importantPointsRaw = importantPoints.joinToString("\n"),
        definitionsRaw = definitions.joinToString("\n"),
        pdfUrl = pdfUrl,
        pageCount = pageCount,
        isDownloaded = isDownloaded,
        isCustom = isCustom,
        isPublished = isPublished
    )

    private fun ObjectiveQuestionEntity.toDomain(): ObjectiveQuestion = ObjectiveQuestion(
        id = id,
        chapterId = chapterId,
        subjectId = subjectId,
        courseId = courseId,
        questionText = questionText,
        optionA = optionA,
        optionB = optionB,
        optionC = optionC,
        optionD = optionD,
        correctOption = correctOption,
        explanation = explanation,
        marks = marks,
        difficulty = difficulty,
        isPreviousYear = isPreviousYear,
        examYear = examYear
    )

    private fun ObjectiveQuestion.toEntity(): ObjectiveQuestionEntity = ObjectiveQuestionEntity(
        id = id,
        chapterId = chapterId,
        subjectId = subjectId,
        courseId = courseId,
        questionText = questionText,
        optionA = optionA,
        optionB = optionB,
        optionC = optionC,
        optionD = optionD,
        correctOption = correctOption,
        explanation = explanation,
        marks = marks,
        difficulty = difficulty,
        isPreviousYear = isPreviousYear,
        examYear = examYear
    )

    private fun SubjectiveQuestionEntity.toDomain(): SubjectiveQuestion = SubjectiveQuestion(
        id = id,
        chapterId = chapterId,
        subjectId = subjectId,
        courseId = courseId,
        questionText = questionText,
        answerText = answerText,
        marks = marks,
        questionType = questionType,
        isImportant = isImportant,
        isPreviousYear = isPreviousYear,
        examYear = examYear
    )

    private fun SubjectiveQuestion.toEntity(): SubjectiveQuestionEntity = SubjectiveQuestionEntity(
        id = id,
        chapterId = chapterId,
        subjectId = subjectId,
        courseId = courseId,
        questionText = questionText,
        answerText = answerText,
        marks = marks,
        questionType = questionType,
        isImportant = isImportant,
        isPreviousYear = isPreviousYear,
        examYear = examYear
    )

    private fun MockTestEntity.toDomain(): MockTest = MockTest(
        id = id,
        courseId = courseId,
        subjectId = subjectId,
        title = title,
        description = description,
        durationMinutes = durationMinutes,
        totalMarks = totalMarks,
        totalQuestions = totalQuestions,
        passMarks = passMarks,
        instructions = emptyList(),
        chapterId = chapterId,
        isPublished = isPublished
    )

    private fun MockTest.toEntity(): MockTestEntity = MockTestEntity(
        id = id,
        courseId = courseId,
        subjectId = subjectId,
        title = title,
        description = description,
        durationMinutes = durationMinutes,
        totalMarks = totalMarks,
        totalQuestions = totalQuestions,
        passMarks = passMarks,
        chapterId = chapterId,
        isPublished = isPublished
    )

    private fun AnnouncementEntity.toDomain(): Announcement = Announcement(
        id = id,
        courseId = courseId,
        title = title,
        content = content,
        date = date,
        isImportant = isImportant,
        tag = tag
    )

    private fun Announcement.toEntity(): AnnouncementEntity = AnnouncementEntity(
        id = id,
        courseId = courseId,
        title = title,
        content = content,
        date = date,
        isImportant = isImportant,
        tag = tag
    )

    companion object {
        @Volatile
        private var INSTANCE: TargetBoardRepository? = null

        fun getInstance(context: Context): TargetBoardRepository {
            return INSTANCE ?: synchronized(this) {
                val instance = TargetBoardRepository(context.applicationContext)
                INSTANCE = instance
                instance
            }
        }
    }
}
