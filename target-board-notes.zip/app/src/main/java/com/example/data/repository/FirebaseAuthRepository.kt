package com.example.data.repository

import android.app.Activity
import android.content.Context
import android.util.Log
import androidx.credentials.CredentialManager
import androidx.credentials.CustomCredential
import androidx.credentials.GetCredentialRequest
import androidx.credentials.exceptions.GetCredentialCancellationException
import com.example.R
import com.google.android.libraries.identity.googleid.GetGoogleIdOption
import com.google.android.libraries.identity.googleid.GetSignInWithGoogleOption
import com.google.android.libraries.identity.googleid.GoogleIdTokenCredential
import com.google.firebase.auth.FirebaseAuth
import com.google.firebase.auth.FirebaseUser
import com.google.firebase.auth.GoogleAuthProvider
import com.google.firebase.firestore.FirebaseFirestore
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.tasks.await
import kotlinx.coroutines.withContext

class FirebaseAuthRepository private constructor(private val context: Context) {

    private val auth: FirebaseAuth = FirebaseAuth.getInstance()
    private val credentialManager: CredentialManager = CredentialManager.create(context)

    private val _currentUser = MutableStateFlow<FirebaseUser?>(auth.currentUser)
    val currentUser: StateFlow<FirebaseUser?> = _currentUser.asStateFlow()

    private val _isAdminUser = MutableStateFlow(false)
    val isAdminUser: StateFlow<Boolean> = _isAdminUser.asStateFlow()

    private val _authError = MutableStateFlow<String?>(null)
    val authError: StateFlow<String?> = _authError.asStateFlow()

    private val _isAuthenticating = MutableStateFlow(false)
    val isAuthenticating: StateFlow<Boolean> = _isAuthenticating.asStateFlow()

    private val authStateListener = FirebaseAuth.AuthStateListener { firebaseAuth ->
        val user = firebaseAuth.currentUser
        _currentUser.value = user
        if (user != null) {
            checkAndSyncUserProfile(user)
        } else {
            _isAdminUser.value = false
        }
    }

    init {
        auth.addAuthStateListener(authStateListener)
        auth.currentUser?.let { checkAndSyncUserProfile(it) }
    }

    private fun getWebClientId(): String {
        return try {
            val resId = context.resources.getIdentifier("default_web_client_id", "string", context.packageName)
            if (resId != 0) context.getString(resId) else "659977888158-5im6tmg4biidqrtu4g7uestl39uc4bng.apps.googleusercontent.com"
        } catch (e: Exception) {
            "659977888158-5im6tmg4biidqrtu4g7uestl39uc4bng.apps.googleusercontent.com"
        }
    }

    /**
     * Interactive Google Sign-In with Jetpack CredentialManager using GetSignInWithGoogleOption
     */
    suspend fun signInWithGoogle(activity: Activity): Boolean = withContext(Dispatchers.IO) {
        _isAuthenticating.value = true
        _authError.value = null
        val serverClientId = getWebClientId()

        try {
            val signInOption = GetSignInWithGoogleOption.Builder(serverClientId)
                .build()

            val request = GetCredentialRequest.Builder()
                .addCredentialOption(signInOption)
                .build()

            val result = credentialManager.getCredential(activity, request)
            val credential = result.credential

            if (credential is CustomCredential && credential.type == GoogleIdTokenCredential.TYPE_GOOGLE_ID_TOKEN_CREDENTIAL) {
                val googleIdTokenCredential = GoogleIdTokenCredential.createFrom(credential.data)
                val idToken = googleIdTokenCredential.idToken
                val authCredential = GoogleAuthProvider.getCredential(idToken, null)
                val authResult = auth.signInWithCredential(authCredential).await()
                val user = authResult.user

                if (user != null) {
                    checkAndSyncUserProfile(user)
                    _currentUser.value = user
                    _isAuthenticating.value = false
                    return@withContext true
                }
            }
            _authError.value = "Google साइन-इन टोकन प्राप्त नहीं हो सका।"
            _isAuthenticating.value = false
            false
        } catch (e: GetCredentialCancellationException) {
            Log.w("FirebaseAuth", "User cancelled Google Sign-in flow: ${e.message}")
            _authError.value = "साइन-इन रद्द कर दिया गया।"
            _isAuthenticating.value = false
            false
        } catch (e: Exception) {
            Log.e("FirebaseAuth", "Google Sign-in failed", e)
            _authError.value = e.localizedMessage ?: "साइन-इन में त्रुटि हुई।"
            _isAuthenticating.value = false
            false
        }
    }

    /**
     * Silent Google Sign-In attempt using GetGoogleIdOption
     */
    suspend fun trySilentSignIn(activity: Activity): Boolean = withContext(Dispatchers.IO) {
        if (auth.currentUser != null) return@withContext true
        val serverClientId = getWebClientId()

        try {
            val googleIdOption = GetGoogleIdOption.Builder()
                .setFilterByAuthorizedAccounts(true)
                .setServerClientId(serverClientId)
                .setAutoSelectEnabled(true)
                .build()

            val request = GetCredentialRequest.Builder()
                .addCredentialOption(googleIdOption)
                .build()

            val result = credentialManager.getCredential(activity, request)
            val credential = result.credential

            if (credential is CustomCredential && credential.type == GoogleIdTokenCredential.TYPE_GOOGLE_ID_TOKEN_CREDENTIAL) {
                val googleIdTokenCredential = GoogleIdTokenCredential.createFrom(credential.data)
                val authCredential = GoogleAuthProvider.getCredential(googleIdTokenCredential.idToken, null)
                val authResult = auth.signInWithCredential(authCredential).await()
                authResult.user?.let {
                    checkAndSyncUserProfile(it)
                    _currentUser.value = it
                    return@withContext true
                }
            }
            false
        } catch (e: Exception) {
            // Silent sign-in may fail if no active session, ignore gracefully
            false
        }
    }

    private fun checkAndSyncUserProfile(user: FirebaseUser) {
        try {
            val databaseId = context.getString(R.string.firestore_database_id)
            val db = FirebaseFirestore.getInstance(databaseId)

            val email = user.email.orEmpty().lowercase()
            val isAdmin = email.contains("admin") || email == "admin@targetboard.in"

            // Check if user is in admins collection or has admin role
            db.collection("admins").document(user.uid).get()
                .addOnSuccessListener { adminDoc ->
                    if (adminDoc.exists() || isAdmin) {
                        _isAdminUser.value = true
                    }
                }

            // Sync user profile in Firestore
            val userProfile = hashMapOf(
                "userId" to user.uid,
                "displayName" to (user.displayName ?: "बिहार बोर्ड छात्र"),
                "email" to email,
                "role" to if (isAdmin) "admin" else "student"
            )
            db.collection("users").document(user.uid).set(userProfile)
        } catch (e: Exception) {
            Log.e("FirebaseAuth", "Failed to sync user profile", e)
        }
    }

    fun signOut() {
        auth.signOut()
        _currentUser.value = null
        _isAdminUser.value = false
    }

    fun clearError() {
        _authError.value = null
    }

    companion object {
        @Volatile
        private var INSTANCE: FirebaseAuthRepository? = null

        fun getInstance(context: Context): FirebaseAuthRepository {
            return INSTANCE ?: synchronized(this) {
                val instance = FirebaseAuthRepository(context.applicationContext)
                INSTANCE = instance
                instance
            }
        }
    }
}
