package com.example.data.model

data class Course(
    val id: String,
    val title: String,
    val hindiTitle: String,
    val description: String,
    val session: String = "2026–2027",
    val studentCount: String = "50K+ छात्र",
    val badge: String = "100% FREE"
)

data class Subject(
    val id: String,
    val courseId: String,
    val title: String,
    val hindiTitle: String,
    val chapterCount: Int,
    val iconName: String = "book",
    val colorHex: Long = 0xFF1E3A8A
)

data class Chapter(
    val id: String,
    val subjectId: String,
    val courseId: String,
    val chapterNumber: Int,
    val title: String,
    val hindiTitle: String,
    val authorName: String = "",
    val authorIntro: String = "",
    val authorLifeHistory: String = "",
    val explanation: String = "",
    val importantPoints: List<String> = emptyList(),
    val definitions: List<String> = emptyList(),
    val pdfUrl: String = "",
    val pageCount: Int = 12,
    val isDownloaded: Boolean = false,
    val viewCount: Int = 0,
    val isCustom: Boolean = false,
    val isPublished: Boolean = true
)

data class ObjectiveQuestion(
    val id: String,
    val chapterId: String,
    val subjectId: String,
    val courseId: String = "class_10",
    val questionText: String,
    val optionA: String,
    val optionB: String,
    val optionC: String,
    val optionD: String,
    val correctOption: Int, // 1 for A, 2 for B, 3 for C, 4 for D
    val explanation: String = "",
    val marks: Int = 1,
    val difficulty: String = "मध्यम",
    val isPreviousYear: Boolean = false,
    val examYear: String = "2024"
)

data class SubjectiveQuestion(
    val id: String,
    val chapterId: String,
    val subjectId: String,
    val courseId: String = "class_10",
    val questionText: String,
    val answerText: String,
    val marks: Int = 2, // 2 for Short (लघु उत्तरीय), 5 for Long (दीर्घ उत्तरीय)
    val questionType: String = "SHORT", // SHORT or LONG
    val isImportant: Boolean = true,
    val isPreviousYear: Boolean = false,
    val examYear: String = "2024"
)

data class MockTest(
    val id: String,
    val courseId: String,
    val subjectId: String,
    val title: String,
    val description: String,
    val durationMinutes: Int = 60,
    val totalMarks: Int = 50,
    val totalQuestions: Int = 50,
    val passMarks: Int = 25,
    val instructions: List<String> = emptyList(),
    val chapterId: String = "",
    val isPublished: Boolean = true
)

data class MockTestResult(
    val testId: String,
    val testTitle: String,
    val totalQuestions: Int,
    val attempted: Int,
    val correct: Int,
    val wrong: Int,
    val unattempted: Int,
    val score: Int,
    val percentage: Float,
    val timeTakenSeconds: Long,
    val performanceRating: String,
    val questionReviewList: List<QuestionReviewItem>
)

data class QuestionReviewItem(
    val question: ObjectiveQuestion,
    val selectedOption: Int,
    val isCorrect: Boolean
)

data class Announcement(
    val id: String,
    val courseId: String = "ALL",
    val title: String,
    val content: String,
    val date: String,
    val isImportant: Boolean = false,
    val tag: String = "सूचना"
)

data class Bookmark(
    val id: String,
    val chapterId: String,
    val chapterTitle: String,
    val subjectName: String,
    val courseId: String,
    val timestamp: Long = System.currentTimeMillis()
)

data class AppUpdateInfo(
    val currentVersionCode: Int = 1,
    val currentVersionName: String = "1.0",
    val latestVersionCode: Int = 2,
    val latestVersionName: String = "2.0 (2026-27 Special)",
    val updateTitle: String = "नया अपडेट उपलब्ध है! (New Update Available)",
    val releaseNotes: String = "• सत्र 2026–2027 के नए मॉडल पेपर्स व नोट्स जोड़े गए\n• नए ऑब्जेक्टिव और VVI सब्जेक्टिव प्रश्न\n• ऑफलाइन डाउनलोड गति में सुधार\n• नया टेस्ट सीरीज विश्लेषण",
    val apkUrl: String = "https://github.com/targetboardnotes/releases/download/v2.0/TargetBoardNotes_v2.0.apk",
    val apkSize: String = "14.2 MB",
    val sha256Checksum: String = "e3b0c44298fc1c149afbf4c8996fb92427ae41e4649b934ca495991b7852b855",
    val isAvailable: Boolean = true
)

data class StudentProfile(
    val name: String = "प्रिय विद्यार्थी",
    val rollNumber: String = "BSEB-2027",
    val selectedCourseId: String = "class_10",
    val streakDays: Int = 5,
    val solvedQuestionsCount: Int = 42,
    val testsCompletedCount: Int = 6,
    val savedNotesCount: Int = 8
)
