package com.example.data.local

import android.content.Context
import android.content.SharedPreferences
import java.security.MessageDigest

class PreferencesManager(context: Context) {

    private val prefs: SharedPreferences =
        context.getSharedPreferences("target_board_prefs", Context.MODE_PRIVATE)

    companion object {
        private const val KEY_SELECTED_COURSE = "selected_course_id"
        private const val KEY_ADMIN_HASH = "admin_password_hash"
        private const val KEY_ADMIN_SALT = "admin_password_salt"
        private const val KEY_INITIAL_PWD_CHANGED = "is_initial_password_changed"
        private const val KEY_ADMIN_RECOVERY_KEY = "admin_recovery_key"
        private const val KEY_APP_LANGUAGE = "app_language"

        private const val DEFAULT_SALT = "TargetBoardNotesSalt2026Secure"
        // Salted SHA-256 hash for secure initial administrator setup
        private const val DEFAULT_ADMIN_HASH = "4ed7a69cae5af1368a1001df703ae0e8db04cd2a64743fcf63fe66fadb5d4de6"
    }

    init {
        // Initialize secure salted hash on first installation if not present
        if (!prefs.contains(KEY_ADMIN_HASH)) {
            prefs.edit()
                .putString(KEY_ADMIN_SALT, DEFAULT_SALT)
                .putString(KEY_ADMIN_HASH, DEFAULT_ADMIN_HASH)
                .putBoolean(KEY_INITIAL_PWD_CHANGED, false)
                .putString(KEY_ADMIN_RECOVERY_KEY, "TB-2026-BSEB-RECOVER")
                .apply()
        }
    }

    // --- Persistent Course Selection ---
    fun getSelectedCourseId(): String? {
        return prefs.getString(KEY_SELECTED_COURSE, null)
    }

    fun setSelectedCourseId(courseId: String) {
        prefs.edit().putString(KEY_SELECTED_COURSE, courseId).apply()
    }

    fun isCourseSelected(): Boolean {
        return prefs.contains(KEY_SELECTED_COURSE) && !prefs.getString(KEY_SELECTED_COURSE, null).isNullOrBlank()
    }

    fun clearCourseSelection() {
        prefs.edit().remove(KEY_SELECTED_COURSE).apply()
    }

    // --- App Language Preference (Hindi / English) ---
    fun getAppLanguage(): String {
        return prefs.getString(KEY_APP_LANGUAGE, "hi") ?: "hi"
    }

    fun setAppLanguage(language: String) {
        val validLang = if (language.lowercase() == "en") "en" else "hi"
        prefs.edit().putString(KEY_APP_LANGUAGE, validLang).apply()
    }

    // --- Secure Administrator Authentication ---
    fun verifyAdminCredentials(adminId: String, passwordAttempt: String): Boolean {
        val cleanId = adminId.trim().lowercase()
        // Allow official Admin IDs
        val isIdValid = cleanId == "admin" || cleanId == "admin@targetboard.in" || cleanId == "targetboard_admin"
        if (!isIdValid) return false

        val salt = prefs.getString(KEY_ADMIN_SALT, DEFAULT_SALT) ?: DEFAULT_SALT
        val storedHash = prefs.getString(KEY_ADMIN_HASH, DEFAULT_ADMIN_HASH)
        val computedHash = hashString(salt + passwordAttempt)
        return computedHash == storedHash
    }

    fun isInitialPasswordChangeRequired(): Boolean {
        return !prefs.getBoolean(KEY_INITIAL_PWD_CHANGED, false)
    }

    fun updateAdminPassword(newPassword: String): Boolean {
        if (newPassword.length < 6) return false
        val newSalt = "TBSalt_" + System.currentTimeMillis()
        val newHash = hashString(newSalt + newPassword)
        prefs.edit()
            .putString(KEY_ADMIN_SALT, newSalt)
            .putString(KEY_ADMIN_HASH, newHash)
            .putBoolean(KEY_INITIAL_PWD_CHANGED, true)
            .apply()
        return true
    }

    fun resetPasswordWithRecoveryKey(recoveryKey: String, newPassword: String): Boolean {
        val storedKey = prefs.getString(KEY_ADMIN_RECOVERY_KEY, "TB-2026-BSEB-RECOVER")
        if (recoveryKey.trim() == storedKey && newPassword.length >= 6) {
            return updateAdminPassword(newPassword)
        }
        return false
    }

    private fun hashString(input: String): String {
        val bytes = MessageDigest.getInstance("SHA-256").digest(input.toByteArray())
        return bytes.joinToString("") { "%02x".format(it) }
    }
}
