package com.example.data.local

import android.content.Context
import androidx.room.Database
import androidx.room.Room
import androidx.room.RoomDatabase
import com.example.data.local.dao.TargetBoardDao
import com.example.data.local.entity.*

@Database(
    entities = [
        SubjectEntity::class,
        ChapterEntity::class,
        ObjectiveQuestionEntity::class,
        SubjectiveQuestionEntity::class,
        MockTestEntity::class,
        AnnouncementEntity::class,
        BookmarkEntity::class
    ],
    version = 3,
    exportSchema = false
)
abstract class TargetBoardDatabase : RoomDatabase() {
    abstract fun targetBoardDao(): TargetBoardDao

    companion object {
        @Volatile
        private var INSTANCE: TargetBoardDatabase? = null

        fun getDatabase(context: Context): TargetBoardDatabase {
            return INSTANCE ?: synchronized(this) {
                val instance = Room.databaseBuilder(
                    context.applicationContext,
                    TargetBoardDatabase::class.java,
                    "target_board_notes.db"
                )
                    .fallbackToDestructiveMigration()
                    .build()
                INSTANCE = instance
                instance
            }
        }
    }
}
