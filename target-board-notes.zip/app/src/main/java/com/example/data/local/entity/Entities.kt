package com.example.data.local.entity

import androidx.room.Entity
import androidx.room.PrimaryKey

@Entity(tableName = "subjects")
data class SubjectEntity(
    @PrimaryKey val id: String,
    val courseId: String,
    val title: String,
    val hindiTitle: String,
    val chapterCount: Int,
    val iconName: String = "book",
    val colorHex: Long = 0xFF1E3A8A
)

@Entity(tableName = "chapters")
data class ChapterEntity(
    @PrimaryKey val id: String,
    val subjectId: String,
    val courseId: String,
    val chapterNumber: Int,
    val title: String,
    val hindiTitle: String,
    val authorName: String,
    val authorIntro: String,
    val authorLifeHistory: String,
    val explanation: String,
    val importantPointsRaw: String, // newline separated
    val definitionsRaw: String,     // newline separated
    val pdfUrl: String,
    val pageCount: Int,
    val isDownloaded: Boolean = false,
    val isCustom: Boolean = false,
    val isPublished: Boolean = true
)

@Entity(tableName = "objective_questions")
data class ObjectiveQuestionEntity(
    @PrimaryKey val id: String,
    val chapterId: String,
    val subjectId: String,
    val courseId: String,
    val questionText: String,
    val optionA: String,
    val optionB: String,
    val optionC: String,
    val optionD: String,
    val correctOption: Int,
    val explanation: String,
    val marks: Int = 1,
    val difficulty: String = "मध्यम", // आसान, मध्यम, कठिन
    val isPreviousYear: Boolean,
    val examYear: String
)

@Entity(tableName = "subjective_questions")
data class SubjectiveQuestionEntity(
    @PrimaryKey val id: String,
    val chapterId: String,
    val subjectId: String,
    val courseId: String,
    val questionText: String,
    val answerText: String,
    val marks: Int,
    val questionType: String, // SHORT or LONG
    val isImportant: Boolean,
    val isPreviousYear: Boolean,
    val examYear: String
)

@Entity(tableName = "mock_tests")
data class MockTestEntity(
    @PrimaryKey val id: String,
    val courseId: String,
    val subjectId: String,
    val title: String,
    val description: String,
    val durationMinutes: Int,
    val totalMarks: Int,
    val totalQuestions: Int,
    val passMarks: Int,
    val chapterId: String = "",
    val isPublished: Boolean = true
)

@Entity(tableName = "announcements")
data class AnnouncementEntity(
    @PrimaryKey val id: String,
    val courseId: String = "ALL", // "ALL", "class_10", "class_12_science", "class_12_arts"
    val title: String,
    val content: String,
    val date: String,
    val isImportant: Boolean,
    val tag: String
)

@Entity(tableName = "bookmarks")
data class BookmarkEntity(
    @PrimaryKey val chapterId: String,
    val chapterTitle: String,
    val subjectName: String,
    val courseId: String,
    val timestamp: Long
)
