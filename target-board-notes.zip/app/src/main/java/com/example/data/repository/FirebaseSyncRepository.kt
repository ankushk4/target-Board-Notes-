package com.example.data.repository

import android.content.Context
import android.util.Log
import com.example.R
import com.example.data.local.TargetBoardDatabase
import com.example.data.local.entity.*
import com.example.data.model.*
import com.google.firebase.auth.FirebaseAuth
import com.google.firebase.firestore.*
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.launch
import kotlinx.coroutines.tasks.await
import kotlinx.coroutines.withContext

class FirebaseSyncRepository private constructor(private val context: Context) {

    private val databaseId = context.getString(R.string.firestore_database_id)
    val firestore: FirebaseFirestore = FirebaseFirestore.getInstance(databaseId).apply {
        firestoreSettings = FirebaseFirestoreSettings.Builder()
            .setLocalCacheSettings(PersistentCacheSettings.newBuilder().build())
            .build()
    }

    private val roomDb = TargetBoardDatabase.getDatabase(context)
    private val dao = roomDb.targetBoardDao()
    private val scope = CoroutineScope(Dispatchers.IO)

    private val _isCloudSyncing = MutableStateFlow(false)
    val isCloudSyncing: StateFlow<Boolean> = _isCloudSyncing.asStateFlow()

    private val _cloudSyncStatus = MutableStateFlow("क्लाउड सिंक सक्रिय (Firestore Ready)")
    val cloudSyncStatus: StateFlow<String> = _cloudSyncStatus.asStateFlow()

    private val activeListeners = mutableListOf<ListenerRegistration>()

    init {
        // Initial sync and seed if connected
        scope.launch {
            try {
                if (FirebaseAuth.getInstance().currentUser != null) {
                    seedFirestoreIfEmpty()
                }
            } catch (e: Exception) {
                Log.w("FirebaseSync", "Cloud initial check skipped: ${e.message}")
            }
        }
    }

    /**
     * Start real-time Firestore listeners for a selected course to keep student devices synchronized.
     */
    fun startRealtimeSync(courseId: String) {
        if (FirebaseAuth.getInstance().currentUser == null) return

        // Clear previous listeners for clean memory
        activeListeners.forEach { it.remove() }
        activeListeners.clear()

        _isCloudSyncing.value = true

        // 1. Chapters Real-time Sync for Course
        val chaptersListener = firestore.collection("courses")
            .document(courseId)
            .collection("chapters")
            .addSnapshotListener { snapshots, error ->
                if (error != null) {
                    Log.w("FirebaseSync", "Chapters listener error: ${error.message}")
                    _isCloudSyncing.value = false
                    return@addSnapshotListener
                }

                if (snapshots != null && !snapshots.isEmpty) {
                    scope.launch {
                        val chapterEntities = snapshots.documents.mapNotNull { doc ->
                            try {
                                ChapterEntity(
                                    id = doc.getString("id") ?: doc.id,
                                    subjectId = doc.getString("subjectId") ?: "",
                                    courseId = doc.getString("courseId") ?: courseId,
                                    chapterNumber = (doc.getLong("chapterNumber") ?: 1L).toInt(),
                                    title = doc.getString("title") ?: "",
                                    hindiTitle = doc.getString("hindiTitle") ?: doc.getString("title") ?: "",
                                    authorName = doc.getString("authorName") ?: "",
                                    authorIntro = doc.getString("authorIntro") ?: "",
                                    authorLifeHistory = doc.getString("authorLifeHistory") ?: "",
                                    explanation = doc.getString("explanation") ?: "",
                                    importantPointsRaw = (doc.get("importantPoints") as? List<*>)?.joinToString("\n") ?: "",
                                    definitionsRaw = (doc.get("definitions") as? List<*>)?.joinToString("\n") ?: "",
                                    pdfUrl = doc.getString("pdfUrl") ?: "",
                                    pageCount = (doc.getLong("pageCount") ?: 10L).toInt(),
                                    isDownloaded = false,
                                    isCustom = true,
                                    isPublished = doc.getBoolean("isPublished") ?: true
                                )
                            } catch (e: Exception) {
                                null
                            }
                        }
                        dao.insertChapters(chapterEntities)
                        _cloudSyncStatus.value = "क्लाउड से ${chapterEntities.size} अध्याय सिंक्रनाइज़ हुए"
                    }
                }
                _isCloudSyncing.value = false
            }
        activeListeners.add(chaptersListener)

        // 2. Announcements Real-time Sync for Course
        val announcementsListener = firestore.collection("courses")
            .document(courseId)
            .collection("announcements")
            .addSnapshotListener { snapshots, error ->
                if (error != null) return@addSnapshotListener
                if (snapshots != null && !snapshots.isEmpty) {
                    scope.launch {
                        val announcements = snapshots.documents.mapNotNull { doc ->
                            try {
                                AnnouncementEntity(
                                    id = doc.getString("id") ?: doc.id,
                                    courseId = doc.getString("courseId") ?: courseId,
                                    title = doc.getString("title") ?: "",
                                    content = doc.getString("content") ?: "",
                                    date = doc.getString("date") ?: "सत्र 2026–2027",
                                    isImportant = doc.getBoolean("isImportant") ?: false,
                                    tag = doc.getString("tag") ?: "सूचना"
                                )
                            } catch (e: Exception) {
                                null
                            }
                        }
                        dao.insertAnnouncements(announcements)
                    }
                }
            }
        activeListeners.add(announcementsListener)
    }

    /**
     * Upload or update a chapter in Cloud Firestore (Admin Operation)
     */
    suspend fun saveChapterToCloud(chapter: Chapter): Boolean = withContext(Dispatchers.IO) {
        val currentUser = FirebaseAuth.getInstance().currentUser ?: return@withContext false
        _isCloudSyncing.value = true

        try {
            val chapterData = hashMapOf(
                "id" to chapter.id,
                "subjectId" to chapter.subjectId,
                "courseId" to chapter.courseId,
                "chapterNumber" to chapter.chapterNumber,
                "title" to chapter.title,
                "hindiTitle" to chapter.hindiTitle,
                "authorName" to chapter.authorName,
                "authorIntro" to chapter.authorIntro,
                "authorLifeHistory" to chapter.authorLifeHistory,
                "explanation" to chapter.explanation,
                "importantPoints" to chapter.importantPoints,
                "definitions" to chapter.definitions,
                "pdfUrl" to chapter.pdfUrl,
                "pageCount" to chapter.pageCount,
                "isPublished" to chapter.isPublished,
                "updatedBy" to currentUser.uid
            )

            firestore.collection("courses")
                .document(chapter.courseId)
                .collection("chapters")
                .document(chapter.id)
                .set(chapterData)
                .await()

            _cloudSyncStatus.value = "अध्याय क्लाउड में सफलतापूर्वक सहेज लिया गया"
            _isCloudSyncing.value = false
            true
        } catch (e: Exception) {
            Log.e("FirebaseSync", "Failed to save chapter to Firestore", e)
            _cloudSyncStatus.value = "क्लाउड सहेजने में त्रुटि: ${e.localizedMessage}"
            _isCloudSyncing.value = false
            false
        }
    }

    /**
     * Delete a chapter from Cloud Firestore (Admin Operation)
     */
    suspend fun deleteChapterFromCloud(chapterId: String, courseId: String): Boolean = withContext(Dispatchers.IO) {
        try {
            firestore.collection("courses")
                .document(courseId)
                .collection("chapters")
                .document(chapterId)
                .delete()
                .await()
            true
        } catch (e: Exception) {
            Log.e("FirebaseSync", "Failed to delete chapter from Firestore", e)
            false
        }
    }

    /**
     * Toggle chapter publication status in Cloud Firestore
     */
    suspend fun toggleChapterPublishInCloud(chapterId: String, courseId: String, isPublished: Boolean): Boolean = withContext(Dispatchers.IO) {
        try {
            firestore.collection("courses")
                .document(courseId)
                .collection("chapters")
                .document(chapterId)
                .update("isPublished", isPublished)
                .await()
            true
        } catch (e: Exception) {
            Log.e("FirebaseSync", "Failed to toggle chapter publish in Firestore", e)
            false
        }
    }

    /**
     * Upload Objective Question to Cloud Firestore
     */
    suspend fun saveObjectiveQuestionToCloud(question: ObjectiveQuestion): Boolean = withContext(Dispatchers.IO) {
        try {
            val data = hashMapOf(
                "id" to question.id,
                "chapterId" to question.chapterId,
                "subjectId" to question.subjectId,
                "courseId" to question.courseId,
                "questionText" to question.questionText,
                "optionA" to question.optionA,
                "optionB" to question.optionB,
                "optionC" to question.optionC,
                "optionD" to question.optionD,
                "correctOption" to question.correctOption,
                "explanation" to question.explanation,
                "marks" to question.marks,
                "difficulty" to question.difficulty,
                "isPreviousYear" to question.isPreviousYear,
                "examYear" to question.examYear
            )

            firestore.collection("courses")
                .document(question.courseId)
                .collection("chapters")
                .document(question.chapterId)
                .collection("objective_questions")
                .document(question.id)
                .set(data)
                .await()
            true
        } catch (e: Exception) {
            Log.e("FirebaseSync", "Failed to save objective question", e)
            false
        }
    }

    /**
     * Upload Subjective Question to Cloud Firestore
     */
    suspend fun saveSubjectiveQuestionToCloud(question: SubjectiveQuestion): Boolean = withContext(Dispatchers.IO) {
        try {
            val data = hashMapOf(
                "id" to question.id,
                "chapterId" to question.chapterId,
                "subjectId" to question.subjectId,
                "courseId" to question.courseId,
                "questionText" to question.questionText,
                "answerText" to question.answerText,
                "marks" to question.marks,
                "questionType" to question.questionType,
                "isImportant" to question.isImportant,
                "isPreviousYear" to question.isPreviousYear,
                "examYear" to question.examYear
            )

            firestore.collection("courses")
                .document(question.courseId)
                .collection("chapters")
                .document(question.chapterId)
                .collection("subjective_questions")
                .document(question.id)
                .set(data)
                .await()
            true
        } catch (e: Exception) {
            Log.e("FirebaseSync", "Failed to save subjective question", e)
            false
        }
    }

    /**
     * Upload Mock Test to Cloud Firestore
     */
    suspend fun saveMockTestToCloud(mockTest: MockTest): Boolean = withContext(Dispatchers.IO) {
        try {
            val data = hashMapOf(
                "id" to mockTest.id,
                "courseId" to mockTest.courseId,
                "subjectId" to mockTest.subjectId,
                "chapterId" to mockTest.chapterId,
                "title" to mockTest.title,
                "description" to mockTest.description,
                "durationMinutes" to mockTest.durationMinutes,
                "totalMarks" to mockTest.totalMarks,
                "totalQuestions" to mockTest.totalQuestions,
                "passMarks" to mockTest.passMarks,
                "isPublished" to mockTest.isPublished
            )

            firestore.collection("courses")
                .document(mockTest.courseId)
                .collection("mock_tests")
                .document(mockTest.id)
                .set(data)
                .await()
            true
        } catch (e: Exception) {
            Log.e("FirebaseSync", "Failed to save mock test", e)
            false
        }
    }

    /**
     * Seed Cloud Firestore with initial curated curriculum if database is empty
     */
    suspend fun seedFirestoreIfEmpty() = withContext(Dispatchers.IO) {
        try {
            val testSnap = firestore.collection("courses")
                .document("class_10")
                .collection("chapters")
                .limit(1)
                .get()
                .await()

            if (testSnap.isEmpty) {
                _cloudSyncStatus.value = "क्लाउड डेटाबेस प्रारंभिक सेटअप जारी है..."

                // Seed Courses
                for (course in SeedData.courses) {
                    firestore.collection("courses").document(course.id).set(
                        hashMapOf(
                            "id" to course.id,
                            "title" to course.title,
                            "hindiTitle" to course.hindiTitle,
                            "order" to 1
                        )
                    ).await()
                }

                // Seed Chapters
                for (ch in SeedData.getInitialChapters()) {
                    firestore.collection("courses")
                        .document(ch.courseId)
                        .collection("chapters")
                        .document(ch.id)
                        .set(
                            hashMapOf(
                                "id" to ch.id,
                                "subjectId" to ch.subjectId,
                                "courseId" to ch.courseId,
                                "chapterNumber" to ch.chapterNumber,
                                "title" to ch.title,
                                "hindiTitle" to ch.hindiTitle,
                                "authorName" to ch.authorName,
                                "authorIntro" to ch.authorIntro,
                                "authorLifeHistory" to ch.authorLifeHistory,
                                "explanation" to ch.explanation,
                                "importantPoints" to ch.importantPointsRaw.split("\n"),
                                "definitions" to ch.definitionsRaw.split("\n"),
                                "pdfUrl" to ch.pdfUrl,
                                "pageCount" to ch.pageCount,
                                "isPublished" to ch.isPublished
                            )
                        ).await()
                }

                // Seed Announcements
                for (ann in SeedData.getInitialAnnouncements()) {
                    firestore.collection("courses")
                        .document(ann.courseId)
                        .collection("announcements")
                        .document(ann.id)
                        .set(
                            hashMapOf(
                                "id" to ann.id,
                                "courseId" to ann.courseId,
                                "title" to ann.title,
                                "content" to ann.content,
                                "date" to ann.date,
                                "isImportant" to ann.isImportant,
                                "tag" to ann.tag
                            )
                        ).await()
                }

                _cloudSyncStatus.value = "क्लाउड डेटाबेस सफलतापूर्वक 2026–2027 पाठ्यक्रम से लोड हो गया!"
            }
        } catch (e: Exception) {
            Log.w("FirebaseSync", "Seeding check handled: ${e.message}")
        }
    }

    companion object {
        @Volatile
        private var INSTANCE: FirebaseSyncRepository? = null

        fun getInstance(context: Context): FirebaseSyncRepository {
            return INSTANCE ?: synchronized(this) {
                val instance = FirebaseSyncRepository(context.applicationContext)
                INSTANCE = instance
                instance
            }
        }
    }
}
