package com.example.data.repository

import com.example.data.local.entity.*
import com.example.data.model.Course
import com.example.data.model.Subject

object SeedData {

    val courses = listOf(
        Course(
            id = "class_10",
            title = "Class 10th – Matric",
            hindiTitle = "कक्षा 10वीं (मैट्रिक बोर्ड)",
            description = "बिहार बोर्ड मैट्रिक परीक्षा 2026–2027 का संपूर्ण नोट्स, VVI ऑब्जेक्टिव, सब्जेक्टिव और मॉडल टेस्ट पेपर्स।",
            session = "2026–2027",
            studentCount = "48,000+ छात्र नामांकित"
        ),
        Course(
            id = "class_12_science",
            title = "Class 12th – Science",
            hindiTitle = "कक्षा 12वीं (इंटर साइंस)",
            description = "फिजिक्स, केमिस्ट्री, बायोलॉजी, मैथ्स, हिंदी व इंग्लिश के संपूर्ण नोट्स एवं परीक्षा उपयोगी प्रश्न।",
            session = "2026–2027",
            studentCount = "36,000+ छात्र नामांकित"
        ),
        Course(
            id = "class_12_arts",
            title = "Class 12th – Arts",
            hindiTitle = "कक्षा 12वीं (इंटर आर्ट्स)",
            description = "इतिहास, राजनीति विज्ञान, भूगोल, अर्थशास्त्र, हिंदी व इंग्लिश के संपूर्ण अध्यायवार नोट्स व PYQ सीरीज।",
            session = "2026–2027",
            studentCount = "29,000+ छात्र नामांकित"
        )
    )

    fun getInitialSubjects(): List<SubjectEntity> = listOf(
        // Class 10 Subjects
        SubjectEntity("c10_science", "class_10", "Science (विज्ञान)", "भौतिकी, रसायनशास्त्र एवं जीवविज्ञान", 8, "science", 0xFF0284C7),
        SubjectEntity("c10_maths", "class_10", "Mathematics (गणित)", "सूत्र, प्रमेय एवं हल सहित संपूर्ण अध्याय", 7, "calculate", 0xFF7C3AED),
        SubjectEntity("c10_sst", "class_10", "Social Science (सामाजिक विज्ञान)", "इतिहास, भूगोल, राजनीति, अर्थशास्त्र व आपदा प्रबंधन", 6, "public", 0xFFD97706),
        SubjectEntity("c10_hindi", "class_10", "Hindi (गोधूलि व वर्णिका)", "गद्य खंड, पद्य खंड एवं लेखक परिचय", 7, "menu_book", 0xFFDC2626),
        SubjectEntity("c10_sanskrit", "class_10", "Sanskrit (पीयूषम् भाग 2)", "श्लोक अर्थ, व्याकरण एवं वस्तुनिष्ठ प्रश्न", 5, "auto_stories", 0xFF059669),
        SubjectEntity("c10_english", "class_10", "English (Panorama Part 2)", "Prose, Poetry, Grammar & Question Answers", 5, "language", 0xFF2563EB),

        // Class 12 Science Subjects
        SubjectEntity("c12s_physics", "class_12_science", "Physics (भौतिक विज्ञान)", "थ्योरी, न्यूमेरिकल्स, डेरिवेशन्स व फॉर्मूला शीट", 7, "bolt", 0xFF2563EB),
        SubjectEntity("c12s_chemistry", "class_12_science", "Chemistry (रसायन विज्ञान)", "भौतिक, कार्बनिक व अकार्बनिक रसायन", 8, "science", 0xFF059669),
        SubjectEntity("c12s_biology", "class_12_science", "Biology (जीव विज्ञान)", "सचित्र व्याख्या, आनुवंशिकी एवं मानव कल्याण", 5, "eco", 0xFF16A34A),
        SubjectEntity("c12s_maths", "class_12_science", "Mathematics (गणित)", "कैलकुलस, वेक्टर, 3D एवं त्रिकोणमिति", 6, "functions", 0xFF9333EA),
        SubjectEntity("c12s_hindi", "class_12_science", "Hindi (दिगंत भाग 2)", "काव्य खंड, गद्य खंड एवं लेखक परिचय", 5, "menu_book", 0xFFEA580C),
        SubjectEntity("c12s_english", "class_12_science", "English (Rainbow Part 2)", "Prose, Poetry, Summary & MCQs", 5, "translate", 0xFF0284C7),

        // Class 12 Arts Subjects
        SubjectEntity("c12a_history", "class_12_arts", "History (इतिहास)", "प्राचीन, मध्यकालीन एवं आधुनिक भारत का इतिहास", 4, "history_edu", 0xFFB45309),
        SubjectEntity("c12a_polsci", "class_12_arts", "Political Science (राजनीति विज्ञान)", "स्वतंत्र भारत में राजनीति एवं समकालीन विश्व", 4, "account_balance", 0xFF1D4ED8),
        SubjectEntity("c12a_geography", "class_12_arts", "Geography (भूगोल)", "मानव भूगोल के मूल सिद्धांत व भारत: लोग और अर्थव्यवस्था", 4, "terrain", 0xFF0D9488),
        SubjectEntity("c12a_economics", "class_12_arts", "Economics (अर्थशास्त्र)", "व्यष्टि एवं समष्टि अर्थशास्त्र के महत्वपूर्ण सिद्धांत", 4, "trending_up", 0xFF4F46E5),
        SubjectEntity("c12a_hindi", "class_12_arts", "Hindi (दिगंत भाग 2)", "साहित्यिक व्याख्या, प्रश्न-उत्तर एवं निबंध", 5, "menu_book", 0xFFDC2626),
        SubjectEntity("c12a_english", "class_12_arts", "English (Rainbow Part 2)", "Literature & Complete Grammar Guide", 5, "language", 0xFF0284C7)
    )

    fun getInitialChapters(): List<ChapterEntity> = listOf(
        // C10 Hindi - Ch 1
        ChapterEntity(
            id = "c10_hi_ch1",
            subjectId = "c10_hindi",
            courseId = "class_10",
            chapterNumber = 1,
            title = "श्रम विभाजन और जाति प्रथा",
            hindiTitle = "पाठ 1: श्रम विभाजन और जाति प्रथा (गद्य खंड)",
            authorName = "डॉ. भीमराव अंबेडकर",
            authorIntro = "बाबा साहेब भीमराव अंबेडकर आधुनिक भारत के महान समाज सुधारक, विधिवेत्ता तथा भारतीय संविधान के निर्माता थे। उनका जन्म 14 अप्रैल 1891 ई. को महू (मध्य प्रदेश) में एक दलित परिवार में हुआ था।",
            authorLifeHistory = "प्राथमिक शिक्षा के बाद बड़ौदा नरेश के प्रोत्साहन पर वे उच्चतर शिक्षा के लिए न्यूयॉर्क (अमेरिका) फिर लंदन (इंग्लैंड) गए। उनकी प्रमुख रचनाएँ: 'The Castes in India', 'Annihilation of Caste', 'Who are They?', 'Who are Shudras?', 'Buddha and His Dhamma'।",
            explanation = "यह पाठ बाबा साहेब के विख्यात भाषण 'Annihilation of Caste' का हिंदी रूपांतर है। लेखक का मत है कि आधुनिक सभ्य समाज कार्यकुशलता के लिए श्रम विभाजन को आवश्यक मानता है, परंतु जाति प्रथा श्रम विभाजन के साथ-साथ श्रमिक विभाजन का भी रूप लिए हुए है। आर्थिक पहलू से भी जाति प्रथा अत्यंत हानिकारक है। लेखक सच्चे लोकतंत्र के लिए 'स्वतंत्रता, समता और भ्रातृत्व' पर आधारित समाज की परिकल्पना करते हैं।",
            importantPointsRaw = "1. जाति प्रथा भारत में बेरोजगारी का एक प्रमुख व प्रत्यक्ष कारण बनी हुई है।\n2. सच्चे लोकतंत्र की मूल शर्त स्वतंत्रता, समानता और बंधुत्व की भावना है।\n3. दूध और पानी के मिश्रण की तरह भाईचारे का दूसरा नाम ही सच्चा लोकतंत्र है।\n4. जाति प्रथा पेशे का दोषपूर्ण पूर्वनिर्धारण ही नहीं करती, बल्कि मनुष्य को जीवन भर के लिए एक पेशे में बाँध देती है।",
            definitionsRaw = "श्रम विभाजन: समाज के कार्यों को विभिन्न व्यक्तियों के कौशल अनुसार व्यवस्थित करना।\nजाति प्रथा: जन्म के आधार पर सामाजिक पद एवं व्यवसाय का बाध्यकारी निर्धारण।\nसच्चा लोकतंत्र: स्वतंत्रता, समानता और बंधुता पर आधारित समाज जहाँ सभी की सहभागिता हो।",
            pdfUrl = "https://targetboardnotes.biharboard.ac.in/pdf/class10/hindi_ch1_notes.pdf",
            pageCount = 10,
            isDownloaded = true,
            isCustom = false
        ),
        // C10 Science - Ch 1
        ChapterEntity(
            id = "c10_sci_ch1",
            subjectId = "c10_science",
            courseId = "class_10",
            chapterNumber = 1,
            title = "प्रकाश का परावर्तन तथा अपवर्तन",
            hindiTitle = "पाठ 1: प्रकाश का परावर्तन तथा अपवर्तन (Physics)",
            authorName = "NCERT / Bihar Board",
            authorIntro = "बिहार विद्यालय परीक्षा समिति (BSEB) मैट्रिक पाठ्यक्रम के अंतर्गत भौतिकी का यह सर्वाधिक महत्वपूर्ण अध्याय है।",
            authorLifeHistory = "प्रकाश ऊर्जा का एक रूप है जो हमें वस्तुओं को देखने की संवेदनशीलता प्रदान करता है। निर्वात में प्रकाश की चाल 3 × 10⁸ m/s होती है।",
            explanation = "1. प्रकाश का परावर्तन: जब प्रकाश किरण किसी चिकनी या चमकदार सतह (दर्पण) से टकराकर पुनः उसी माध्यम में लौट जाती है। परावर्तन के दो नियम होते हैं: ∠i = ∠r तथा आपतित, परावर्तित व अभिलंब एक ही तल में होते हैं।\n2. दर्पण सूत्र: 1/f = 1/v + 1/u\n3. लेंस सूत्र: 1/f = 1/v - 1/u\n4. लेंस की क्षमता: P = 1/f (मीटर में), मात्रक डाइऑप्टर (D)।",
            importantPointsRaw = "1. निर्वात में प्रकाश की चाल 3 × 10⁸ मीटर प्रति सेकंड होती है।\n2. अवतल दर्पण का उपयोग हजामती दर्पण, टॉर्च, सर्चलाइट तथा सोलर कुकर में होता है।\n3. उत्तल दर्पण का उपयोग वाहनों के साइड मिरर (पश्च-दृश्य दर्पण) में होता है।\n4. लेंस की क्षमता का SI मात्रक डाइऑप्टर (D) होता है।",
            definitionsRaw = "परावर्तन: प्रकाश का सतह से टकराकर उसी माध्यम में लौटना।\nअपवर्तन: माध्यम परिवर्तन पर प्रकाश की दिशा में होने वाला विचलन।\nफोकस दूरी: दर्पण के ध्रुव से मुख्य फोकस के बीच की दूरी (f = R/2)।",
            pdfUrl = "https://targetboardnotes.biharboard.ac.in/pdf/class10/science_light_reflection.pdf",
            pageCount = 14,
            isDownloaded = true,
            isCustom = false
        ),
        // C10 Maths - Ch 1
        ChapterEntity(
            id = "c10_math_ch1",
            subjectId = "c10_maths",
            courseId = "class_10",
            chapterNumber = 1,
            title = "वास्तविक संख्याएँ (Real Numbers)",
            hindiTitle = "पाठ 1: वास्तविक संख्याएँ (Real Numbers)",
            authorName = "NCERT / BSEB Board",
            authorIntro = "वास्तविक संख्याएँ गणित की नींव हैं। इसमें यूक्लिड विभाजन प्रमेयिका, अंकगणित की आधारभूत प्रमेय का अध्ययन किया जाता है।",
            authorLifeHistory = "यूक्लिड यूनान के महान गणितज्ञ थे जिन्होंने एलिमेंट्स नामक ग्रंथ लिखा था।",
            explanation = "1. यूक्लिड विभाजन प्रमेयिका: a = bq + r, जहाँ 0 ≤ r < b।\n2. HCF(a, b) × LCM(a, b) = a × b।\n3. पाई (π) अपरिमेय संख्या है, 22/7 परिमेय संख्या है।\n4. शांत दशमलव प्रसार के हर का गुणनखंड 2^n × 5^m के रूप का होता है।",
            importantPointsRaw = "1. a = bq + r जहाँ 0 ≤ r < b यूक्लिड विभाजन सूत्र है।\n2. पाई (π) एक अपरिमेय संख्या है।\n3. दो लगातार अभाज्य संख्याओं का म.स. (HCF) सदैव 1 होता है।\n4. सबसे छोटी अभाज्य संख्या 2 है।",
            definitionsRaw = "परिमेय संख्या: वह संख्या जिसे p/q (q ≠ 0) के रूप में लिखा जा सके।\nअपरिमेय संख्या: वह संख्या जिसका दशमलव प्रसार अशांत अनावर्ती हो।",
            pdfUrl = "https://targetboardnotes.biharboard.ac.in/pdf/class10/maths_ch1_real_numbers.pdf",
            pageCount = 12,
            isDownloaded = false,
            isCustom = false
        ),
        // C12 Science Physics - Ch 1
        ChapterEntity(
            id = "c12s_phy_ch1",
            subjectId = "c12s_physics",
            courseId = "class_12_science",
            chapterNumber = 1,
            title = "विद्युत आवेश तथा क्षेत्र (Electric Charges & Fields)",
            hindiTitle = "अध्याय 1: विद्युत आवेश तथा क्षेत्र (Electrostatics)",
            authorName = "NCERT / BSEB Board",
            authorIntro = "स्थिर वैद्युतिकी (Electrostatics) के अंतर्गत विराम अवस्था में स्थित आवेशों, विद्युत क्षेत्र व गाउस प्रमेय का अध्ययन किया जाता है।",
            authorLifeHistory = "चार्ल्स ऑगस्टिन डी कूलॉम ने 1785 में बिंदु आवेशों के मध्य लगने वाले आकर्षण एवं प्रतिकर्षण बल के लिए नियम प्रतिपादित किया था।",
            explanation = "1. आवेश का क्वांटीकरण: q = ±ne, जहाँ e = 1.6 × 10⁻¹⁹ C।\n2. कूलॉम का नियम: F = (1 / 4πε₀) × (|q₁q₂| / r²)।\n3. विद्युत क्षेत्र: E = F / q₀, SI मात्रक N/C अथवा V/m।\n4. गाउस का नियम: कुल वैद्युत फ्लक्स Φ_E = q_enclosed / ε₀।",
            importantPointsRaw = "1. आवेश का SI मात्रक कूलॉम (C) तथा विमीय सूत्र [AT] होता है।\n2. विद्युत क्षेत्र की तीव्रता का SI मात्रक N/C या V/m होता है।\n3. अक्षीय स्थिति में विद्युत क्षेत्र: E = (1/4πε₀) × (2p / r³)।\n4. गाउस नियम बंद पृष्ठों के लिए ही लागू होता है।",
            definitionsRaw = "विद्युत फ्लक्स: किसी तल से अभिलंबवत गुजरने वाली कुल विद्युत बल रेखाओं की संख्या।\nविद्युत द्विध्रुव: परिमाण में समान परंतु विपरीत प्रकृति के दो बिंदु आवेश अल्प दूरी पर स्थित हों।",
            pdfUrl = "https://targetboardnotes.biharboard.ac.in/pdf/class12/physics_ch1_electric_charges.pdf",
            pageCount = 18,
            isDownloaded = true,
            isCustom = false
        ),
        // C12 Science Chemistry - Ch 1
        ChapterEntity(
            id = "c12s_chem_ch1",
            subjectId = "c12s_chemistry",
            courseId = "class_12_science",
            chapterNumber = 1,
            title = "विलयन (Solutions)",
            hindiTitle = "अध्याय 1: विलयन (Solutions)",
            authorName = "NCERT / BSEB Board",
            authorIntro = "भौतिक रसायन की यह इकाई विभिन्न प्रकार के विलयनों, हेनरी नियम, राउल्ट नियम व अणुसंख्य गुणधर्मों पर आधारित है।",
            authorLifeHistory = "फ्रांस्वा-मैरी राउल्ट ने वाष्पदाब अवनमन व विलयनों के व्यवहार पर प्रसिद्ध नियम प्रस्तुत किया था।",
            explanation = "1. राउल्ट का नियम: वाष्पशील द्रवों के विलयन में प्रत्येक घटक का आंशिक वाष्पदाब उसके मोल प्रभाज के समानुपाती होता है।\n2. अणुसंख्य गुणधर्म: परासरण दाब, क्वथनांक उन्नयन, हिमांक अवनमन, वाष्पदाब का आपेक्षिक अवनमन।\n3. वान्ट हॉफ गुणांक (i): संगुणन अथवा वियोजन की मात्रा निर्धारित करता है।",
            importantPointsRaw = "1. परासरण दाब π = CRT सर्वश्रेष्ठ अणुसंख्य गुणधर्म है।\n2. आदर्श विलयन के लिए ΔH_mix = 0 तथा ΔV_mix = 0 होता है।\n3. मोललता (m) ताप पर निर्भर नहीं करती क्योंकि यह विलायक के द्रव्यमान पर आधारित है।",
            definitionsRaw = "मोललता: 1 किग्रा विलायक में उपस्थित विलेय के मोलों की संख्या।\nमोलरता: 1 लीटर विलयन में उपस्थित विलेय के मोलों की संख्या।\nपरासरण दाब: परासरण को रोकने के लिए विलयन पर लगाया गया न्यूनतम अतिरिक्त बाह्य दाब।",
            pdfUrl = "https://targetboardnotes.biharboard.ac.in/pdf/class12/chemistry_ch1_solutions.pdf",
            pageCount = 16,
            isDownloaded = false,
            isCustom = false
        ),
        // C12 Arts History - Ch 1
        ChapterEntity(
            id = "c12a_his_ch1",
            subjectId = "c12a_history",
            courseId = "class_12_arts",
            chapterNumber = 1,
            title = "ईंटें, मनके तथा अस्थियाँ (हड़प्पा सभ्यता)",
            hindiTitle = "पाठ 1: ईंटें, मनके तथा अस्थियाँ - हड़प्पा सभ्यता",
            authorName = "NCERT / BSEB 12वीं इतिहास",
            authorIntro = "सिंधु घाटी सभ्यता (हड़प्पा सभ्यता) विश्व की प्राचीनतम कांस्य युगीन नगरीय सभ्यताओं में से एक है। इसकी खोज 1921 में दयाराम साहनी द्वारा की गई थी।",
            authorLifeHistory = "भारतीय पुरातत्व सर्वेक्षण के महानिदेशक जॉन मार्शल के नेतृत्व में 1924 में सिंधु घाटी में सभ्यता की खोज की घोषणा की गई थी।",
            explanation = "1. सुनियोजित नगर नियोजन, ग्रिड पद्धति पर आधारित सड़कें और पक्की नालियों की जल-निकासी प्रणाली।\n2. प्रमुख स्थल: मोहनजोदड़ो (विशाल स्नानागार), लोथल (प्राचीन गोदीवाड़ा/डॉकयार्ड), कालीबंगा (जुते हुए खेत)।\n3. लिपि भावचित्रात्मक थी और चर्ट पत्थर के बाट द्विआधारी प्रणाली में बनाए जाते थे।",
            importantPointsRaw = "1. हड़प्पा सभ्यता को 'कांस्य युगीन सभ्यता' कहा जाता है।\n2. मोहनजोदड़ो का अर्थ 'मृतकों का टीला' होता है।\n3. विशाल स्नानागार मोहनजोदड़ो से प्राप्त हुआ।\n4. हड़प्पा वासियों को लोहे का ज्ञान नहीं था।",
            definitionsRaw = "ग्रिड प्रणाली: सड़कें एक-दूसरे को समकोण पर काटती हुई जाल की तरह नगर को विभाजित करती थीं।\nडॉकयार्ड: जहाजों के ठहरने व माल चढ़ाने-उतारने का पक्का जलाशय।",
            pdfUrl = "https://targetboardnotes.biharboard.ac.in/pdf/class12/history_ch1_harappa.pdf",
            pageCount = 15,
            isDownloaded = false,
            isCustom = false
        ),
        // C12 Arts Pol Science - Ch 1
        ChapterEntity(
            id = "c12a_pol_ch1",
            subjectId = "c12a_polsci",
            courseId = "class_12_arts",
            chapterNumber = 1,
            title = "राष्ट्र-निर्माण की चुनौतियाँ",
            hindiTitle = "पाठ 1: राष्ट्र-निर्माण की चुनौतियाँ (Challenges of Nation-Building)",
            authorName = "NCERT / BSEB Board",
            authorIntro = "15 अगस्त 1947 को स्वतंत्रता के समय भारत के सम्मुख एकता, लोकतंत्र की स्थापना एवं समतामूलक विकास की तीन प्रमुख चुनौतियां थीं।",
            authorLifeHistory = "सरदार वल्लभभाई पटेल ने 565 से अधिक देशी रियासतों का भारतीय संघ में ऐतिहासिक विलय कराकर लौह पुरुष की उपाधि प्राप्त की।",
            explanation = "1. आजादी के समय 3 चुनौतियां: देश की एकता व सुरक्षा, लोकतांत्रिक व्यवस्था का क्रियान्वयन, और समूचे समाज का समुचित विकास।\n2. विभाजन की त्रासदी: द्वि-राष्ट्र सिद्धांत (मुस्लिम लीग), शरणार्थी समस्या, और सांप्रदायिक दंगे।\n3. देशी रियासतों का विलय: जूनागढ़, हैदराबाद (ऑपरेशन पोलो), मणिपुर और कश्मीर का विलय।\n4. राज्य पुनर्गठन आयोग (1953): भाषा के आधार पर राज्यों का पुनर्गठन (आंध्र प्रदेश पहला भाषाई राज्य)।",
            importantPointsRaw = "1. 14-15 अगस्त 1947 की मध्य रात्रि को जवाहरलाल नेहरू ने प्रसिद्ध 'भाग्यवधू से चिरप्रतीक्षित भेंट' (Tryst with Destiny) भाषण दिया।\n2. सरदार पटेल ने देशी रियासतों के विलय के लिए 'इंस्ट्रूमेंट ऑफ एक्सेशन' पत्र तैयार कराया।\n3. 1956 में राज्य पुनर्गठन अधिनियम पारित हुआ जिसके तहत 14 राज्य और 6 केंद्र शासित प्रदेश बने।",
            definitionsRaw = "द्वि-राष्ट्र सिद्धांत: भारत दो कौमों (हिंदू और मुस्लिम) का देश है, अतः मुसलमानों के लिए अलग देश होना चाहिए।\nइंस्ट्रूमेंट ऑफ एक्सेशन: देशी रियासतों द्वारा भारतीय संघ में शामिल होने हेतु हस्ताक्षरित वैधानिक सहमति पत्र।",
            pdfUrl = "https://targetboardnotes.biharboard.ac.in/pdf/class12/polsci_ch1_nation_building.pdf",
            pageCount = 14,
            isDownloaded = true,
            isCustom = false
        )
    )

    fun getInitialObjectiveQuestions(): List<ObjectiveQuestionEntity> = listOf(
        // C10 Hindi Ch 1 Questions
        ObjectiveQuestionEntity(
            id = "q_c10_hi_1",
            chapterId = "c10_hi_ch1",
            subjectId = "c10_hindi",
            courseId = "class_10",
            questionText = "बाबा साहेब भीमराव अंबेडकर का जन्म किस राज्य में हुआ था?",
            optionA = "बिहार",
            optionB = "मध्य प्रदेश",
            optionC = "उत्तर प्रदेश",
            optionD = "महाराष्ट्र",
            correctOption = 2,
            explanation = "डॉ. भीमराव अंबेडकर का जन्म 14 अप्रैल 1891 ई. को महू, मध्य प्रदेश में एक दलित परिवार में हुआ था।",
            marks = 1,
            difficulty = "आसान",
            isPreviousYear = true,
            examYear = "2024"
        ),
        ObjectiveQuestionEntity(
            id = "q_c10_hi_2",
            chapterId = "c10_hi_ch1",
            subjectId = "c10_hindi",
            courseId = "class_10",
            questionText = "श्रम विभाजन और जाति प्रथा पाठ के लेखक कौन हैं?",
            optionA = "महात्मा गांधी",
            optionB = "जवाहरलाल नेहरू",
            optionC = "डॉ. भीमराव अंबेडकर",
            optionD = "मैक्समूलर",
            correctOption = 3,
            explanation = "श्रम विभाजन और जाति प्रथा के लेखक भारतीय संविधान निर्माता डॉ. भीमराव अंबेडकर हैं।",
            marks = 1,
            difficulty = "आसान",
            isPreviousYear = true,
            examYear = "2023"
        ),
        ObjectiveQuestionEntity(
            id = "q_c10_hi_3",
            chapterId = "c10_hi_ch1",
            subjectId = "c10_hindi",
            courseId = "class_10",
            questionText = "सच्चे लोकतंत्र का दूसरा नाम क्या है?",
            optionA = "राजतंत्र",
            optionB = "तानाशाही",
            optionC = "भाईचारा",
            optionD = "सैनिक शासन",
            correctOption = 3,
            explanation = "बाबा साहेब के अनुसार लोकतंत्र का वास्तविक अर्थ समाज में दूध और पानी के मिश्रण की तरह भ्रातृत्व (भाईचारा) होना है।",
            marks = 1,
            difficulty = "मध्यम",
            isPreviousYear = true,
            examYear = "2022"
        ),

        // C10 Science Ch 1 Questions
        ObjectiveQuestionEntity(
            id = "q_c10_sci_1",
            chapterId = "c10_sci_ch1",
            subjectId = "c10_science",
            courseId = "class_10",
            questionText = "दाढ़ी बनाने (हजामती) में किस प्रकार के दर्पण का उपयोग किया जाता है?",
            optionA = "समतल दर्पण",
            optionB = "उत्तल दर्पण",
            optionC = "अवतल दर्पण",
            optionD = "इनमें से कोई नहीं",
            correctOption = 3,
            explanation = "अवतल दर्पण में जब वस्तु ध्रुव और फोकस के बीच होती है, तो उसका सीधा, आभासी और बड़ा प्रतिबिंब बनता है।",
            marks = 1,
            difficulty = "आसान",
            isPreviousYear = true,
            examYear = "2024"
        ),
        ObjectiveQuestionEntity(
            id = "q_c10_sci_2",
            chapterId = "c10_sci_ch1",
            subjectId = "c10_science",
            courseId = "class_10",
            questionText = "लेंस की क्षमता का SI मात्रक क्या होता है?",
            optionA = "मीटर",
            optionB = "डाइऑप्टर (m⁻¹)",
            optionC = "सेंटीमीटर",
            optionD = "वाट",
            correctOption = 2,
            explanation = "लेंस की क्षमता P = 1/f (मीटर में) होती है। इसका SI मात्रक डाइऑप्टर (D) है।",
            marks = 1,
            difficulty = "आसान",
            isPreviousYear = true,
            examYear = "2023"
        ),

        // C12 Science Physics Ch 1 Questions
        ObjectiveQuestionEntity(
            id = "q_c12s_phy_1",
            chapterId = "c12s_phy_ch1",
            subjectId = "c12s_physics",
            courseId = "class_12_science",
            questionText = "विद्युत क्षेत्र की तीव्रता का SI मात्रक क्या है?",
            optionA = "कूलॉम (C)",
            optionB = "न्यूटन/कूलॉम (N/C)",
            optionC = "जूल/कूलॉम (J/C)",
            optionD = "एम्पियर (A)",
            correctOption = 2,
            explanation = "विद्युत क्षेत्र E = F / q₀, अतः इसका मात्रक न्यूटन प्रति कूलॉम (N/C) अथवा वोल्ट प्रति मीटर (V/m) होता है।",
            marks = 1,
            difficulty = "मध्यम",
            isPreviousYear = true,
            examYear = "2024"
        ),
        ObjectiveQuestionEntity(
            id = "q_c12s_phy_2",
            chapterId = "c12s_phy_ch1",
            subjectId = "c12s_physics",
            courseId = "class_12_science",
            questionText = "स्थिर विद्युतिकी में गाउस का नियम क्या है?",
            optionA = "Φ = q / ε₀",
            optionB = "Φ = q × ε₀",
            optionC = "Φ = ε₀ / q",
            optionD = "Φ = E / A",
            correctOption = 1,
            explanation = "गाउस के नियम के अनुसार बंद पृष्ठ से बद्ध कुल फ्लक्स Φ = q / ε₀ होता है।",
            marks = 1,
            difficulty = "मध्यम",
            isPreviousYear = true,
            examYear = "2023"
        ),

        // C12 Arts History Ch 1 Questions
        ObjectiveQuestionEntity(
            id = "q_c12a_his_1",
            chapterId = "c12a_his_ch1",
            subjectId = "c12a_history",
            courseId = "class_12_arts",
            questionText = "हड़प्पा सभ्यता की खोज किस वर्ष हुई थी?",
            optionA = "1920",
            optionB = "1921",
            optionC = "1922",
            optionD = "1924",
            correctOption = 2,
            explanation = "हड़प्पा स्थल की खोज 1921 में रायबहादुर दयाराम साहनी द्वारा की गई थी।",
            marks = 1,
            difficulty = "आसान",
            isPreviousYear = true,
            examYear = "2024"
        ),
        ObjectiveQuestionEntity(
            id = "q_c12a_his_2",
            chapterId = "c12a_his_ch1",
            subjectId = "c12a_history",
            courseId = "class_12_arts",
            questionText = "सिंधु घाटी सभ्यता में विशाल स्नानागार के अवशेष कहाँ से मिले?",
            optionA = "हड़प्पा",
            optionB = "कालीबंगा",
            optionC = "मोहनजोदड़ो",
            optionD = "लोथल",
            correctOption = 3,
            explanation = "मोहनजोदड़ो से एक भव्य विशाल स्नानागार प्राप्त हुआ है।",
            marks = 1,
            difficulty = "आसान",
            isPreviousYear = true,
            examYear = "2023"
        )
    )

    fun getInitialSubjectiveQuestions(): List<SubjectiveQuestionEntity> = listOf(
        // C10 Hindi Subjective
        SubjectiveQuestionEntity(
            id = "sub_c10_hi_1",
            chapterId = "c10_hi_ch1",
            subjectId = "c10_hindi",
            courseId = "class_10",
            questionText = "जाति प्रथा भारत में बेरोजगारी का एक प्रमुख और प्रत्यक्ष कारण कैसे बनी हुई है? (लघु उत्तरीय प्रश्न)",
            answerText = "उत्तर: भारत में जाति प्रथा मनुष्य को जन्म के आधार पर एक निश्चित पेशे से बाँध देती है। आधुनिक युग में उद्योग-धंधों में परिवर्तन होने पर पेशा बदलने की आवश्यकता पड़ती है, परंतु जाति प्रथा पैतृक पेशे से भिन्न पेशा चुनने की अनुमति नहीं देती। इस प्रकार पेशा परिवर्तन की अनुमति न देकर जाति प्रथा भारत में बेरोजगारी का एक प्रमुख व प्रत्यक्ष कारण बन जाती है।",
            marks = 2,
            questionType = "SHORT",
            isImportant = true,
            isPreviousYear = true,
            examYear = "2024"
        ),
        SubjectiveQuestionEntity(
            id = "sub_c10_hi_2",
            chapterId = "c10_hi_ch1",
            subjectId = "c10_hindi",
            courseId = "class_10",
            questionText = "लेखक ने सच्चे लोकतंत्र की क्या विशेषताएँ बताई हैं? (दीर्घ उत्तरीय प्रश्न)",
            answerText = "उत्तर: बाबा साहेब के अनुसार लोकतंत्र मूलतः सामूहिक जीवनचर्या की एक रीति तथा समाज के सम्मिलित अनुभवों के आदान-प्रदान का नाम है। इसमें साथियों के प्रति आदर व श्रद्धा का भाव होना आवश्यक है। समाज में स्वतंत्रता, समता और भ्रातृत्व की भावना होनी चाहिए और भाईचारे का वास्तविक स्वरूप दूध और पानी के मिश्रण की तरह होना चाहिए।",
            marks = 5,
            questionType = "LONG",
            isImportant = true,
            isPreviousYear = true,
            examYear = "2023"
        ),

        // C10 Science Subjective
        SubjectiveQuestionEntity(
            id = "sub_c10_sci_1",
            chapterId = "c10_sci_ch1",
            subjectId = "c10_science",
            courseId = "class_10",
            questionText = "प्रकाश के परावर्तन से आप क्या समझते हैं? इसके नियमों को लिखें। (लघु उत्तरीय प्रश्न)",
            answerText = "उत्तर: जब प्रकाश की किरणें किसी चमकदार सतह से टकराकर पुनः उसी माध्यम में लौट जाती हैं, तो इस परिघटना को प्रकाश का परावर्तन कहते हैं। परावर्तन के दो प्रमुख नियम हैं:\n1. आपतित किरण, परावर्तित किरण तथा आपतन बिंदु पर खींचा गया अभिलंब तीनों एक ही तल में होते हैं।\n2. आपतन कोण सदैव परावर्तन कोण के बराबर होता है (∠i = ∠r)।",
            marks = 2,
            questionType = "SHORT",
            isImportant = true,
            isPreviousYear = true,
            examYear = "2024"
        ),

        // C12 Science Physics Subjective
        SubjectiveQuestionEntity(
            id = "sub_c12s_phy_1",
            chapterId = "c12s_phy_ch1",
            subjectId = "c12s_physics",
            courseId = "class_12_science",
            questionText = "गाउस के प्रमेय को लिखें एवं सिद्ध करें। (दीर्घ उत्तरीय प्रश्न - 5 अंक)",
            answerText = "उत्तर: गाउस का प्रमेय: किसी बंद काल्पनिक पृष्ठ (गाउसीय पृष्ठ) से गुजरने वाला कुल वैद्युत फ्लक्स (Φ_E), उस पृष्ठ द्वारा परिबद्ध कुल आवेश (q) का 1/ε₀ गुना होता है। अर्थात् Φ_E = ∮ E · dA = q / ε₀।\nउपपत्ति: r त्रिज्या का एक गोलीय गाउसीय पृष्ठ खींचते हैं। dA अल्पांश पर E = (1/4πε₀) × (q / r²)।\nकुल फ्लक्स Φ_E = E ∮ dA = [(1/4πε₀) × (q / r²)] × 4πr² = q / ε₀। इति सिद्धम्।",
            marks = 5,
            questionType = "LONG",
            isImportant = true,
            isPreviousYear = true,
            examYear = "2024"
        ),

        // C12 Arts History Subjective
        SubjectiveQuestionEntity(
            id = "sub_c12a_his_1",
            chapterId = "c12a_his_ch1",
            subjectId = "c12a_history",
            courseId = "class_12_arts",
            questionText = "हड़प्पा सभ्यता के नगर नियोजन की किन्हीं दो प्रमुख विशेषताओं का उल्लेख करें। (लघु उत्तरीय)",
            answerText = "उत्तर: हड़प्पा सभ्यता के नगर नियोजन की दो मुख्य विशेषताएं निम्न हैं:\n1. ग्रिड पद्धति: सड़कें एक-दूसरे को समकोण पर काटती थीं जिससे नगर आयताकार खंडों में विभाजित होता था।\n2. उन्नत जल-निकासी प्रणाली: घरों का गंदा पानी ढकी हुई पक्की नालियों के माध्यम से मुख्य सड़क की बड़ी नालियों में गिरता था।",
            marks = 2,
            questionType = "SHORT",
            isImportant = true,
            isPreviousYear = true,
            examYear = "2024"
        )
    )

    fun getInitialMockTests(): List<MockTestEntity> = listOf(
        MockTestEntity(
            id = "test_c10_full_hindi",
            courseId = "class_10",
            subjectId = "c10_hindi",
            title = "10th हिंदी - बोर्ड मॉडल पेपर 2026-27 (50 MCQs)",
            description = "बिहार विद्यालय परीक्षा समिति के नवीनतम पैटर्न पर आधारित वस्तुनिष्ठ प्रश्नों का पूर्ण अभ्यास सेट।",
            durationMinutes = 45,
            totalMarks = 50,
            totalQuestions = 3,
            passMarks = 25
        ),
        MockTestEntity(
            id = "test_c10_science_vvi",
            courseId = "class_10",
            subjectId = "c10_science",
            title = "10th विज्ञान - टॉप 50 VVI वस्तुनिष्ठ टेस्ट",
            description = "भौतिकी, रसायन एवं जीवविज्ञान के विगत 5 वर्षों के सर्वाधिक पूछे गए प्रश्न।",
            durationMinutes = 40,
            totalMarks = 40,
            totalQuestions = 2,
            passMarks = 20
        ),
        MockTestEntity(
            id = "test_c12s_phy_model",
            courseId = "class_12_science",
            subjectId = "c12s_physics",
            title = "12th फिजिक्स - इलेक्ट्रोस्टैटिक्स स्पेशल टेस्ट",
            description = "कक्षा 12वीं भौतिक विज्ञान अध्याय 1 व 2 का टाइमर-बेस्ड ऑनलाइन टेस्ट।",
            durationMinutes = 30,
            totalMarks = 35,
            totalQuestions = 2,
            passMarks = 18
        ),
        MockTestEntity(
            id = "test_c12a_his_model",
            courseId = "class_12_arts",
            subjectId = "c12a_history",
            title = "12th इतिहास - हड़प्पा सभ्यता व प्राचीन भारत",
            description = "बिहार बोर्ड 12वीं आर्ट्स के लिए इतिहास का विशेष वस्तुनिष्ठ अभ्यास पत्र।",
            durationMinutes = 30,
            totalMarks = 35,
            totalQuestions = 2,
            passMarks = 18
        )
    )

    fun getInitialAnnouncements(): List<AnnouncementEntity> = listOf(
        AnnouncementEntity(
            id = "ann_1",
            courseId = "ALL",
            title = "सत्र 2026–2027 के सभी नए नोट्स अपलोड किए गए!",
            content = "प्रिय छात्रों, बिहार बोर्ड 10वीं व 12वीं (आर्ट्स एवं साइंस) के सभी विषयों के संपूर्ण नोट्स, लेखक परिचय व VVI प्रश्न ऐप में उपलब्ध करा दिए गए हैं। सभी सामग्री 100% निःशुल्क है।",
            date = "TARGET BOARD अपडेट",
            isImportant = true,
            tag = "नवीनतम"
        ),
        AnnouncementEntity(
            id = "ann_2",
            courseId = "ALL",
            title = "रविवार स्पेशल: फ्री ऑल बिहार ऑनलाइन मॉक टेस्ट",
            content = "इस रविवार को 10वीं और 12वीं के सभी छात्रों के लिए राज्य स्तरीय लाइव मॉक टेस्ट आयोजित होगा। तुरंत भाग लें और अपनी तैयारी का आकलन करें।",
            date = "TARGET BOARD टीम द्वारा",
            isImportant = true,
            tag = "टेस्ट सीरीज"
        ),
        AnnouncementEntity(
            id = "ann_3",
            courseId = "ALL",
            title = "ऑफलाइन पीडीएफ नोट्स डाउनलोड सुविधा सक्रिय",
            content = "अब आप बिना इंटरनेट के भी अपने पसंदीदा चैप्टर के नोट्स और महत्वपूर्ण प्रश्न आसानी से कभी भी पढ़ सकते हैं।",
            date = "सिस्टम सूचना",
            isImportant = false,
            tag = "फीचर"
        )
    )
}
