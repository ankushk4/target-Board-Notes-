package com.example.data.local.dao

import androidx.room.*
import com.example.data.local.entity.*
import kotlinx.coroutines.flow.Flow

@Dao
interface TargetBoardDao {

    // Subjects
    @Query("SELECT * FROM subjects WHERE courseId = :courseId ORDER BY id ASC")
    fun getSubjectsByCourse(courseId: String): Flow<List<SubjectEntity>>

    @Query("SELECT * FROM subjects WHERE id = :subjectId LIMIT 1")
    suspend fun getSubjectById(subjectId: String): SubjectEntity?

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertSubjects(subjects: List<SubjectEntity>)

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertSubject(subject: SubjectEntity)

    @Update
    suspend fun updateSubject(subject: SubjectEntity)

    @Delete
    suspend fun deleteSubject(subject: SubjectEntity)

    // Chapters
    @Query("SELECT * FROM chapters WHERE subjectId = :subjectId ORDER BY chapterNumber ASC")
    fun getChaptersBySubject(subjectId: String): Flow<List<ChapterEntity>>

    @Query("SELECT * FROM chapters WHERE courseId = :courseId ORDER BY chapterNumber ASC")
    fun getChaptersByCourse(courseId: String): Flow<List<ChapterEntity>>

    @Query("SELECT * FROM chapters WHERE id = :chapterId LIMIT 1")
    suspend fun getChapterById(chapterId: String): ChapterEntity?

    @Query("SELECT * FROM chapters WHERE courseId = :courseId AND (title LIKE '%' || :query || '%' OR hindiTitle LIKE '%' || :query || '%')")
    suspend fun searchChaptersByCourse(courseId: String, query: String): List<ChapterEntity>

    @Query("SELECT * FROM chapters WHERE title LIKE '%' || :query || '%' OR hindiTitle LIKE '%' || :query || '%'")
    suspend fun searchChapters(query: String): List<ChapterEntity>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertChapters(chapters: List<ChapterEntity>)

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertChapter(chapter: ChapterEntity)

    @Update
    suspend fun updateChapter(chapter: ChapterEntity)

    @Delete
    suspend fun deleteChapter(chapter: ChapterEntity)

    @Query("UPDATE chapters SET isDownloaded = :downloaded WHERE id = :chapterId")
    suspend fun updateDownloadStatus(chapterId: String, downloaded: Boolean)

    @Query("UPDATE chapters SET isPublished = :isPublished WHERE id = :chapterId")
    suspend fun updateChapterPublishStatus(chapterId: String, isPublished: Boolean)

    @Query("UPDATE chapters SET explanation = :notesHindi, pdfUrl = :pdfUrl, pageCount = :pageCount WHERE id = :chapterId")
    suspend fun updateChapterNotesAndPdf(chapterId: String, notesHindi: String, pdfUrl: String, pageCount: Int)

    // Objective Questions
    @Query("SELECT * FROM objective_questions WHERE chapterId = :chapterId")
    fun getObjectiveQuestionsByChapter(chapterId: String): Flow<List<ObjectiveQuestionEntity>>

    @Query("SELECT * FROM objective_questions WHERE courseId = :courseId")
    fun getObjectiveQuestionsByCourse(courseId: String): Flow<List<ObjectiveQuestionEntity>>

    @Query("SELECT * FROM objective_questions WHERE subjectId = :subjectId")
    suspend fun getObjectiveQuestionsBySubject(subjectId: String): List<ObjectiveQuestionEntity>

    @Query("SELECT * FROM objective_questions WHERE courseId = :courseId ORDER BY RANDOM() LIMIT :limit")
    suspend fun getRandomObjectiveQuestionsByCourse(courseId: String, limit: Int): List<ObjectiveQuestionEntity>

    @Query("SELECT * FROM objective_questions ORDER BY RANDOM() LIMIT :limit")
    suspend fun getRandomObjectiveQuestions(limit: Int): List<ObjectiveQuestionEntity>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertObjectiveQuestions(questions: List<ObjectiveQuestionEntity>)

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertObjectiveQuestion(question: ObjectiveQuestionEntity)

    @Update
    suspend fun updateObjectiveQuestion(question: ObjectiveQuestionEntity)

    @Delete
    suspend fun deleteObjectiveQuestion(question: ObjectiveQuestionEntity)

    // Subjective Questions
    @Query("SELECT * FROM subjective_questions WHERE chapterId = :chapterId")
    fun getSubjectiveQuestionsByChapter(chapterId: String): Flow<List<SubjectiveQuestionEntity>>

    @Query("SELECT * FROM subjective_questions WHERE courseId = :courseId")
    fun getSubjectiveQuestionsByCourse(courseId: String): Flow<List<SubjectiveQuestionEntity>>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertSubjectiveQuestions(questions: List<SubjectiveQuestionEntity>)

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertSubjectiveQuestion(question: SubjectiveQuestionEntity)

    @Update
    suspend fun updateSubjectiveQuestion(question: SubjectiveQuestionEntity)

    @Delete
    suspend fun deleteSubjectiveQuestion(question: SubjectiveQuestionEntity)

    // Mock Tests
    @Query("SELECT * FROM mock_tests WHERE courseId = :courseId")
    fun getMockTestsByCourse(courseId: String): Flow<List<MockTestEntity>>

    @Query("SELECT * FROM mock_tests WHERE subjectId = :subjectId")
    fun getMockTestsBySubject(subjectId: String): Flow<List<MockTestEntity>>

    @Query("SELECT * FROM mock_tests WHERE chapterId = :chapterId")
    fun getMockTestsByChapter(chapterId: String): Flow<List<MockTestEntity>>

    @Query("SELECT * FROM mock_tests")
    fun getAllMockTests(): Flow<List<MockTestEntity>>

    @Query("SELECT * FROM mock_tests WHERE id = :testId LIMIT 1")
    suspend fun getMockTestById(testId: String): MockTestEntity?

    @Query("UPDATE mock_tests SET isPublished = :isPublished WHERE id = :testId")
    suspend fun updateMockTestPublishStatus(testId: String, isPublished: Boolean)

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertMockTests(tests: List<MockTestEntity>)

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertMockTest(test: MockTestEntity)

    @Update
    suspend fun updateMockTest(test: MockTestEntity)

    @Delete
    suspend fun deleteMockTest(test: MockTestEntity)

    // Announcements
    @Query("SELECT * FROM announcements WHERE courseId = :courseId OR courseId = 'ALL' ORDER BY isImportant DESC, id DESC")
    fun getAnnouncementsByCourse(courseId: String): Flow<List<AnnouncementEntity>>

    @Query("SELECT * FROM announcements ORDER BY isImportant DESC, id DESC")
    fun getAnnouncements(): Flow<List<AnnouncementEntity>>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertAnnouncements(announcements: List<AnnouncementEntity>)

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertAnnouncement(announcement: AnnouncementEntity)

    @Delete
    suspend fun deleteAnnouncement(announcement: AnnouncementEntity)

    // Bookmarks
    @Query("SELECT * FROM bookmarks WHERE courseId = :courseId ORDER BY timestamp DESC")
    fun getBookmarksByCourse(courseId: String): Flow<List<BookmarkEntity>>

    @Query("SELECT * FROM bookmarks ORDER BY timestamp DESC")
    fun getAllBookmarks(): Flow<List<BookmarkEntity>>

    @Query("SELECT EXISTS(SELECT 1 FROM bookmarks WHERE chapterId = :chapterId)")
    fun isBookmarked(chapterId: String): Flow<Boolean>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun addBookmark(bookmark: BookmarkEntity)

    @Query("DELETE FROM bookmarks WHERE chapterId = :chapterId")
    suspend fun removeBookmark(chapterId: String)
}
